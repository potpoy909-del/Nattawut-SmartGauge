# Nattawut SmartGauge Android V2 — Stage 2.1

แอป Android Kotlin สำหรับ Bluetooth Classic SPP (RFCOMM) และ firmware ESP32 ที่ส่ง CSV v1

## สร้าง APK ด้วยมือถือ
ดู `BUILD_ON_ANDROID_TH.md` — ใช้ GitHub Actions สร้าง APK บนคลาวด์ ไม่ต้องใช้คอมพิวเตอร์

## โปรโตคอล
`NATTWUT,1,RPM,TPS,ECT,IAT,BAT,O2,AFR,SPEED,INJ,IGN,MAP,STFT,LTFT`

ส่งทุก 250 ms เมื่อมี client เชื่อมต่อ `NA` คือไม่มีข้อมูลที่ยืนยันแล้ว แอปจะแสดง `--` โดยไม่สร้างค่าจำลอง

## หน้าที่มี
- Dashboard: 13 ช่อง telemetry
- Graph: เลือก RPM/TPS/ECT/BAT/SPEED และแสดงประวัติที่ได้รับจริง
- Logger: บันทึก packet ที่รับจริงและส่งออก CSV
- DTC/MAP/Control: ปิดไว้จนกว่าจะมี API ฝั่ง ESP32 ที่ผ่านการยืนยัน

## ข้อจำกัด
ต้องเป็น ESP32 ที่รองรับ Bluetooth Classic SPP (ESP32 ดั้งเดิม/CYD บางรุ่น) ไม่รองรับ ESP32-S2/S3/C3 ผ่าน SPP แบบนี้ แอปและ firmware ต้องทดสอบกับบอร์ดจริงก่อนใช้งานบนรถ

## Firmware ที่แนบ
ไฟล์ `firmware/Nattawut_SmartGauge_Bluetooth_Test.ino` คือไฟล์ Arduino ที่ผู้ใช้ส่งมาและใช้ชื่อ Bluetooth `Nattawut ECU` โปรดตรวจสอบรุ่นบอร์ด/ขา ECU ให้ตรงกับการต่อสายจริงก่อนอัปโหลด


## RAW ECU Logger V3 (development stage)

- The Android Logger page records `NATTWUT_RAW,2` events from the ESP32: K-Line TX, RX, partial RX and invalid-length RX frames, with ESP32 `millis()` timestamps and HEX bytes.
- Live telemetry rows are stored alongside raw records. `NA` values remain unavailable (`--` in the live dashboard), not fabricated zeroes.
- Export is CSV via Android's document picker. Keep a separate capture per test session and include bike/ECU conditions in the filename or notes.
- Firmware capture occurs inside `klineTransact()`: it captures transactions initiated by this firmware. It is **not** a passive electrical bus sniffer and cannot see unsolicited ECU traffic, bytes before UART framing, or wake pulse voltage waveforms.
- The current stage does not yet add remote DTC commands, MAP writing, ECU flashing, or remapping. Existing on-board controls and read-only behavior are retained.
- Capture volume depends on Bluetooth connection and app logging being enabled. Do not use the phone logger as the only safety-critical record; validate a short stationary test first.
