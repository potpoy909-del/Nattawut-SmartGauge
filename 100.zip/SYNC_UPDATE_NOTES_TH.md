# Nattawut SmartGauge — App/Board Sync Update

## Source pairing
- Firmware: `firmware/Nattawut_SmartGauge_DTC_SYNC_O2_SCALE_CANDIDATE.ino` (copied unchanged from the latest supplied firmware).
- Android app: `app/src/main/java/com/nattawut/ecu/MainActivity.kt` (only Bluetooth status interpretation, packet validation, read-error cleanup, and logger record classification were changed).

## App-side changes in this candidate
1. `NATTWUT_STATUS` no longer means Bluetooth + ECU are automatically OK. The app separately interprets `KLINE_INIT_OK` and `ECU_RESPONSE`; green is shown only when both are confirmed.
2. `NATTWUT,1` telemetry v1 is accepted only with the exact 15 CSV fields emitted by the firmware.
3. Logger no longer writes every incoming line as `BT_RAW` and then duplicates RAW/telemetry in typed records. It records telemetry as `TELEMETRY`, K-Line frames as `RAW`, and DTC/ACK/STATUS/image/BIN protocol lines as `PROTOCOL`.
4. Bluetooth read errors now clear the stale socket and restore the CONNECT button.
5. The app keeps the existing command names, CSV v1 field order, RAW/DTC/ACK/STATUS formats, image transfer, and BIN transfer formats.

## Deliberately unchanged
- Firmware source is copied byte-for-byte; no firmware logic was changed in this sync candidate.
- No ECU formulas, O2 scale, K-Line commands, DTC routines, UI layouts, menus, MAP/FLASH behavior, or storage contents were changed.
- No new ECU write/flash capability was enabled.

## Validation status
- Source-level checks only.
- Android APK compilation was not run in this environment (Gradle executable/wrapper launcher is not present in the supplied project).
- Arduino firmware compilation and physical Bluetooth/ECU testing have not been performed.
- Treat this as a source candidate for build and hardware verification, not a confirmed production release.
