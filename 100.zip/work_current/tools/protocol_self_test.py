#!/usr/bin/env python3
"""Static protocol checks for Nattawut SmartGauge app/firmware integration."""
from pathlib import Path
import base64
import re
import zlib

ROOT = Path(__file__).resolve().parents[1]
KT = (ROOT / "app/src/main/java/com/nattawut/ecu/MainActivity.kt").read_text(encoding="utf-8")
INO = (ROOT / "firmware/Nattawut_SmartGauge_x3_3_REMAP_DIALOG_FIX.ino").read_text(encoding="utf-8")

# The app and firmware must agree on the v1 telemetry schema.
keys = ["RPM", "TPS", "ECT", "IAT", "BAT", "O2", "AFR", "SPEED", "INJ", "IGN", "MAP", "STFT", "LTFT"]
for key in keys:
    assert f'"{key}"' in KT, f"Android telemetry key missing: {key}"
header = "TAG,VER,RPM,TPS,ECT,IAT,BAT,O2,AFR,SPEED,INJ,IGN,MAP,STFT,LTFT"
assert header in INO, "Firmware telemetry header changed unexpectedly"
assert 'SerialBT.print("NA,NA,NA,NA\\r\\n")' in INO, "Firmware must emit exactly four unavailable trailing fields"

# Recreate one firmware telemetry row and validate its exact field count.
row = "NATTWUT,1,1250,12,80,35,13.8,0.650,14.7,42,2.10,NA,NA,NA,NA"
parts = row.split(",")
assert len(parts) == 15, f"Expected 15 CSV fields, got {len(parts)}"
assert parts[:2] == ["NATTWUT", "1"]
assert len(parts[2:]) == len(keys)

# Verify Base64 chunk sizing used by app (72 bytes) fits firmware decoder (96 bytes).
for size in (1, 2, 3, 71, 72):
    raw = bytes((i % 256 for i in range(size)))
    encoded = base64.b64encode(raw).decode("ascii")
    assert len(encoded) <= 96
    assert base64.b64decode(encoded) == raw
assert "uint8_t decoded[96]" in INO
assert "val chunkSize = 72" in KT
assert '"ECU_BIN_READ"' in INO and 'sendBtCommand("ECU_BIN_READ")' in KT
assert '#define ECU_RX 1' in INO and '#define ECU_TX 22' in INO
# The modern five-item bottom navigation must retain access to all secondary modules.
for page in ("DASHBOARD", "GRAPH", "DTC", "ECU", "GPS", "LOGGER", "IMAGES", "BLUETOOTH", "SETTINGS", "CONTROL", "MAP"):
    assert f'"{page}"' in KT, f"App module missing: {page}"
assert 'private fun showMoreModules()' in KT and 'Triple("MORE", "⋯", "MORE")' in KT

# Cross-check the command prefixes and their fixed offsets in firmware.
for prefix, expected in (
    ("NATTWUT_BIN,PUT_BEGIN,", 22),
    ("NATTWUT_BIN,PUT_DATA,", 21),
    ("NATTWUT_BIN,PUT_END,", 20),
    ("NATTWUT_BIN,GET,", 16),
):
    assert len(prefix) == expected
    assert f'strncmp(cmd,"{prefix}",{expected})==0' in INO

# Standard CRC32 check vector used by both upload/download verification.
assert zlib.crc32(b"123456789") & 0xFFFFFFFF == 0xCBF43926
assert "CRC32().apply { update(bytes) }.value" in KT
assert "imageCrc32Update" in INO

# Exercise the full maximum-size BIN transfer framing and image frame chunking.
payload = bytes((i * 37 + 11) & 0xFF for i in range(512 * 1024))
offset = 0
reassembled = bytearray()
while offset < len(payload):
    chunk = payload[offset:offset + 72]
    encoded = base64.b64encode(chunk)
    decoded = base64.b64decode(encoded)
    assert len(decoded) <= 96
    reassembled.extend(decoded)
    offset += len(decoded)
assert bytes(reassembled) == payload
assert zlib.crc32(reassembled) & 0xFFFFFFFF == zlib.crc32(payload) & 0xFFFFFFFF
image_bytes = 320 * 240 * 2
image_chunks = (image_bytes + 255) // 256
assert image_bytes == 153600 and image_chunks == 600

# App must treat NA as missing rather than displaying fabricated numeric zero.
assert 'raw.equals("NA", true)' in KT
assert 'raw.equals("N/A", true)' in KT

print("PASS: telemetry schema, NA semantics, max-size BIN framing/CRC32, image chunk sizing, ECU read command, Bluetooth permission scope, remote display settings, and K-Line/GPS pin mapping")
