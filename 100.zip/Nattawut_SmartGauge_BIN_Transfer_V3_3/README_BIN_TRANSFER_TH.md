NATTAWUT SMARTGAUGE V3.3 — BIN FILE TRANSFER

ชุดนี้ใช้โปรเจกต์ Android จาก 100.zip และใช้เฟิร์มแวร์ล่าสุด
Nattawut_SmartGauge_x3_3_REMAP_DIALOG_FIX.ino ที่อยู่นอก ZIP เดิม
ไม่มีการนำไฟล์ .ino เก่าจาก 100.zip มาใช้

สิ่งที่เพิ่ม:
- แอป: ส่งไฟล์ .BIN จากโทรศัพท์ไป LittleFS ของ ESP32 ผ่าน Bluetooth SPP
- แอป: ขอรายการไฟล์ BIN บน ESP32 และรับไฟล์กลับมาบันทึกในโทรศัพท์
- ตรวจสอบ CRC32 และ offset ของข้อมูลที่รับส่ง
- เฟิร์มแวร์: คำสั่ง NATTWUT_BIN สำหรับ PUT / LIST / GET
- รองรับขนาดไฟล์สูงสุด 512 KB ในระบบโอนย้ายไฟล์ (พื้นที่ LittleFS จริงอาจจำกัดกว่านี้)
- ใช้ LittleFS ร่วมกับระบบภาพเดิม ห้าม format LittleFS ระหว่างใช้งาน

การสร้างแอป:
ใช้ Android Studio หรือ GitHub Actions จากโฟลเดอร์โปรเจกต์นี้
ไฟล์ MainActivity.kt อยู่ที่ app/src/main/java/com/nattawut/ecu/MainActivity.kt

เฟิร์มแวร์:
ใช้ไฟล์เดียวใน firmware/ ชื่อ Nattawut_SmartGauge_x3_3_REMAP_DIALOG_FIX.ino

ข้อควรทราบ:
ชุดนี้เป็น source code ที่เพิ่ม protocol รับส่ง BIN แต่ยังไม่ได้คอมไพล์ด้วย
Arduino ESP32 toolchain หรือทดสอบ Bluetooth กับบอร์ดจริงในสภาพแวดล้อมนี้
ต้องทดสอบการรับส่งและตรวจ CRC ก่อนใช้งานกับไฟล์ที่จะนำไปเขียน ECU
การส่งไฟล์ BIN เข้า ESP32 เป็นเพียงการจัดเก็บไฟล์ ไม่ได้สั่งเขียน ECU อัตโนมัติ
