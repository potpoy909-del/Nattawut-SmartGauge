# Nattawut SmartGauge — Cyber Neon UI

This revision redesigns the Android app presentation only.

## UI changes
- Cyber Neon dark palette with cyan/blue accents and outlined cards.
- Compact brand/status header and prominent ESP32 connect button.
- Fixed bottom navigation: Home, Live, DTC, ECU, More.
- More menu keeps MAP, CONTROL, GPS, IMAGES, BLUETOOTH, SETTINGS and LOGGER accessible.
- Existing page implementations and their controls are retained.

## Scope protection
- No firmware file was edited.
- No Bluetooth SPP UUID, command strings, CSV schema, RAW/DTC/ACK/STATUS protocol code, ECU/K-Line code, telemetry formulas, or file-transfer logic was intentionally changed.
- Only `app/src/main/java/com/nattawut/ecu/MainActivity.kt` UI theme/navigation/layout-shell styling was edited.

## Build
Open this project in Android Studio or import into a compatible Android Gradle environment. Build/installation and device testing have not yet been verified in this environment.
