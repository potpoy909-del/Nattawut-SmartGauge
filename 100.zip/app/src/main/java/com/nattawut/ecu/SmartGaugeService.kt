package com.nattawut.ecu

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.IBinder
import android.os.Looper
import android.bluetooth.BluetoothSocket
import java.util.Locale

/** Shared live SPP connection. MainActivity creates it; this foreground service keeps it alive. */
object SmartGaugeRuntime {
    @Volatile var socket: BluetoothSocket? = null
}

class SmartGaugeService : Service() {
    companion object {
        const val ACTION_START = "com.nattawut.ecu.action.START_GPS_BRIDGE"
        private const val CHANNEL_ID = "smartgauge_running"
        private const val NOTIFICATION_ID = 2206
    }

    private var manager: LocationManager? = null
    private var listener: LocationListener? = null
    private var lastSpeed = "0.0"

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_START || intent == null) {
            startForeground(NOTIFICATION_ID, buildNotification("กำลังเชื่อมต่อ GPS มือถือ…"))
            beginLocationUpdates()
        }
        return START_STICKY
    }

    private fun beginLocationUpdates() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            updateNotification("ต้องอนุญาต Location ในแอป")
            return
        }
        try {
            val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            manager = lm
            if (!lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                updateNotification("รอเปิด GPS มือถือ")
                return
            }
            if (listener == null) {
                listener = object : LocationListener {
                    override fun onLocationChanged(location: Location) {
                        if (location.hasAccuracy() && location.accuracy <= 50f) {
                            val kmh = (location.speed * 3.6f).coerceIn(0f, 400f)
                            lastSpeed = String.format(Locale.US, "%.1f", kmh)
                            sendLine("SPEED,$lastSpeed")
                            updateNotification("PHONE GPS • $lastSpeed km/h")
                        }
                    }
                    override fun onProviderEnabled(provider: String) { }
                    override fun onProviderDisabled(provider: String) {
                        if (provider == LocationManager.GPS_PROVIDER) {
                            lastSpeed = "0.0"
                            sendLine("SPEED,NA")
                            updateNotification("รอเปิด GPS มือถือ")
                        }
                    }
                }
            }
            lm.removeUpdates(listener!!)
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, listener!!, Looper.getMainLooper())
            updateNotification("PHONE GPS • รอสัญญาณดาวเทียม")
        } catch (_: SecurityException) {
            updateNotification("ไม่มีสิทธิ์เข้าถึง GPS")
        } catch (e: Exception) {
            updateNotification("GPS error: ${e.message ?: "unknown"}")
        }
    }

    private fun sendLine(line: String) {
        val active = SmartGaugeRuntime.socket ?: return
        try {
            synchronized(active) {
                active.outputStream.write((line + "\n").toByteArray(Charsets.UTF_8))
                active.outputStream.flush()
            }
        } catch (_: Exception) {
            updateNotification("Bluetooth หลุด • เปิดแอปเพื่อเชื่อมต่อใหม่")
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "SmartGauge background connection", NotificationManager.IMPORTANCE_LOW)
            channel.description = "Keeps Phone GPS speed streaming to ESP32 while the app is closed"
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(message: String): Notification {
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_ID)
            else Notification.Builder(this)
        return builder
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentTitle("NATTAWUT SMARTGAUGE RUNNING")
            .setContentText(message)
            .setOngoing(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .build()
    }

    private fun updateNotification(message: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, buildNotification(message))
    }

    override fun onDestroy() {
        try { listener?.let { manager?.removeUpdates(it) } } catch (_: Exception) { }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
