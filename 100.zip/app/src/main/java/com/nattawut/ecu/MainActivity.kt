package com.nattawut.ecu

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.graphics.Canvas
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.RectF
import android.net.Uri
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.*
import android.view.ViewGroup
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.UUID
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.zip.CRC32
import kotlin.concurrent.thread
import kotlin.math.max

class MainActivity : Activity() {
    private val sppUuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private var socket: BluetoothSocket? = null
    private var readerThread: Thread? = null
    private var logging = false
    private val logRows = mutableListOf<String>()
    private val samples = mutableListOf<Float>()
    private val histories = mutableMapOf<String, MutableList<Float>>()
    private var receivedPackets = 0L
    private var lastPacketAt = 0L
    private val mainHandler = Handler(Looper.getMainLooper())
    private var telemetryTimedOut = true
    private val telemetry = linkedMapOf(
        "RPM" to "--", "TPS" to "--", "ECT" to "--", "IAT" to "--",
        "BAT" to "--", "O2" to "--", "AFR" to "--", "SPEED" to "--",
        "INJ" to "--", "IGN" to "--", "MAP" to "--", "STFT" to "--", "LTFT" to "--"
    )
    private var latestRawFrame = "ยังไม่ได้รับ RAW DATA จาก ECU"
    private var rawDataView: TextView? = null
    private val units = mapOf("RPM" to "rpm", "TPS" to "%", "ECT" to "°C", "IAT" to "°C",
        "BAT" to "V", "O2" to "V", "AFR" to "AFR", "SPEED" to "km/h",
        "INJ" to "ms", "IGN" to "deg", "MAP" to "kPa", "STFT" to "%", "LTFT" to "%")
    private lateinit var root: LinearLayout
    private lateinit var body: LinearLayout
    private lateinit var status: TextView
    private lateinit var connectBtn: Button
    private lateinit var graph: LiveGraph
    private var activePage = "DASHBOARD"
    private val gpsPrefs by lazy { getSharedPreferences("nattawut_gps", MODE_PRIVATE) }
    private var gpsSource = "BOARD"
    private var phoneGpsSpeed: Int? = null
    private var phoneLatitude: Double? = null
    private var phoneLongitude: Double? = null
    private var locationManager: LocationManager? = null
    private var gpsSpeedView: TextView? = null
    private var gpsSourceView: TextView? = null
    private var gpsPositionView: TextView? = null
    private val phoneLocationListener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            if (gpsSource != "PHONE") return
            phoneLatitude = location.latitude
            phoneLongitude = location.longitude
            if (!location.hasSpeed()) {
                updateGpsPageValues()
                return
            }
            val speed = (location.speed * 3.6f).toInt().coerceIn(0, 350)
            phoneGpsSpeed = speed
            sendBtCommand("PHONE_SPEED,$speed")
            updateGpsPageValues()
        }
        override fun onProviderEnabled(provider: String) { }
        override fun onProviderDisabled(provider: String) {
            if (provider == LocationManager.GPS_PROVIDER) runOnUiThread { toast("กรุณาเปิด Location/GPS ของโทรศัพท์") }
        }
    }

    private val bg = Color.rgb(8, 12, 21)
    private val panel = Color.rgb(20, 29, 44)
    private val cyan = Color.rgb(43, 220, 235)
    private val white = Color.WHITE
    private val muted = Color.rgb(155, 170, 190)
    private var accent = Color.rgb(0, 160, 255)
    private var themeColor = Color.rgb(0, 160, 255)
    private var selectedMetric = "RPM"
    private var ecuInfoText = "ECU: ยังไม่ได้รับข้อมูลระบุตัวตนจาก ECU"

    // V3.1 multi-image boot-logo management over the existing Bluetooth Classic SPP link.
    private data class BoardImage(val slot: Int, val bytes: Long, val selected: Boolean)
    private val imageResponses = LinkedBlockingQueue<String>()
    private val selectedImageUris = mutableListOf<Uri>()
    private val boardImages = mutableListOf<BoardImage>()
    private var imageListContainer: LinearLayout? = null
    private var imageStorageView: TextView? = null
    private var imageSelectionView: TextView? = null
    private var imageProgressView: TextView? = null
    private var imagePreviewView: ImageView? = null
    @Volatile private var imageTransferBusy = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = Color.BLACK
        buildShell()
        gpsSource = gpsPrefs.getString("source", "BOARD") ?: "BOARD"
        locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
        requestBtPermission()
        showPage("DASHBOARD")
        startTelemetryWatchdog()
    }

    private fun startTelemetryWatchdog() {
        mainHandler.post(object : Runnable {
            override fun run() {
                val stale = lastPacketAt == 0L ||
                    System.currentTimeMillis() - lastPacketAt > 1500L
                if (stale && !telemetryTimedOut) {
                    telemetryTimedOut = true
                    synchronized(telemetry) { telemetry.keys.forEach { telemetry[it] = "--" } }
                    if (activePage == "DASHBOARD") updateDashboardValues()
                    if (socket != null) {
                        status.text = "● CONNECTED • NO TELEMETRY"
                        status.setTextColor(Color.YELLOW)
                    }
                }
                mainHandler.postDelayed(this, 300L)
            }
        })
    }

    private fun rounded(color: Int, stroke: Int = Color.TRANSPARENT, radius: Float = 14f): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radius.toInt()).toFloat(); if (stroke != Color.TRANSPARENT) setStroke(dp(1), stroke) }

    private fun styledButton(textValue: String, color: Int = Color.rgb(0, 105, 230), onClick: () -> Unit): Button =
        Button(this).apply {
            text = textValue; textSize = 12f; setTextColor(Color.WHITE); isAllCaps = false
            background = rounded(color, Color.rgb(70, 155, 255), 12f)
            setPadding(dp(8), dp(8), dp(8), dp(8)); setOnClickListener { onClick() }
        }

    private fun sectionTitle(textValue: String): TextView = label(textValue, 18f, white, true).apply {
        setPadding(dp(4), dp(12), dp(4), dp(8)); includeFontPadding = false
    }

    private fun panelBox(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(12), dp(12), dp(12))
        background = rounded(Color.rgb(13, 22, 36), Color.rgb(35, 91, 145), 16f)
    }

    private fun buildShell() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, dp(12), dp(24))
            setBackgroundColor(bg)
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(10), 0, dp(8)) }
        root.setOnApplyWindowInsetsListener { view, insets ->
            header.setPadding(0, insets.systemWindowInsetTop + dp(8), 0, dp(8)); insets
        }
        header.addView(label("NATTAWUT SMARTGAUGE V3", 23f, cyan, true))
        header.addView(label("RACING ECU DASHBOARD  •  HONDA PGM-FI  •  BLUETOOTH SPP", 9f, muted, true))
        status = label("● DISCONNECTED", 12f, Color.rgb(255, 70, 75), true).apply { setPadding(0, dp(8), 0, dp(8)) }
        header.addView(status)
        root.addView(header)
        connectBtn = styledButton("CONNECT TO ESP32", Color.rgb(55, 65, 82)) { if (socket == null) showPairedDevices() else disconnect() }
        root.addView(connectBtn, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(8) })

        val navScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("DASHBOARD", "GRAPH", "DTC", "ECU", "MAP", "CONTROL", "GPS", "IMAGES", "BLUETOOTH", "SETTINGS", "LOGGER").forEach { page ->
            val caption = when(page) { "DASHBOARD"->"HOME"; "BLUETOOTH"->"BT"; else->page }
            val b = styledButton(caption, Color.rgb(28, 43, 65)) { showPage(page) }
            nav.addView(b, LinearLayout.LayoutParams(dp(104), dp(42)).apply { setMargins(dp(3), dp(2), dp(3), dp(5)) })
        }
        navScroll.addView(nav); root.addView(navScroll)
        val scroll = ScrollView(this).apply { isFillViewport = true }
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(8), 0, dp(12)) }
        scroll.addView(body); root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(label("READ-ONLY ECU TELEMETRY  •  ECU WRITE / REMAP DISABLED", 9f, muted, false).apply { gravity = Gravity.CENTER; setPadding(0, dp(7), 0, dp(4)) })
        setContentView(root)
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            this.text = text; textSize = size; setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun showPage(page: String) {
        activePage = page
        body.removeAllViews()
        when (page) {
            "DASHBOARD" -> dashboard()
            "GRAPH" -> graphPage()
            "LOGGER" -> loggerPage()
            "DTC" -> dtcPage()
            "ECU" -> ecuPage()
            "MAP" -> mapPage()
            "CONTROL" -> controlPage()
            "GPS" -> gpsPage()
            "IMAGES" -> imagesPage()
            "BLUETOOTH" -> bluetoothPage()
            "SETTINGS" -> settingsPage()
        }
    }

    // Convert dp to physical pixels. LayoutParams dimensions are pixels, not dp.
    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density + 0.5f).toInt()

    private fun card(key: String): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(8), dp(12), dp(8), dp(5))
            setBackgroundColor(panel)
            minimumHeight = dp(116)
        }

        // Keep the title in its own top row so it cannot collide with the value.
        val title = label(key, 13f, cyan, true).apply {
            gravity = Gravity.CENTER
            includeFontPadding = false
        }
        box.addView(title, LinearLayout.LayoutParams(-1, dp(25)))

        // The value receives the remaining card height and is vertically centered.
        val value = label(telemetry[key] ?: "--", 28f, white, true).apply {
            tag = "value:$key"
            gravity = Gravity.CENTER
            maxLines = 1
            includeFontPadding = false
            isSingleLine = true
        }
        box.addView(value, LinearLayout.LayoutParams(-1, 0, 1f))

        val unit = label(units[key] ?: "", 10f, muted, false).apply {
            gravity = Gravity.CENTER
            includeFontPadding = false
        }
        box.addView(unit, LinearLayout.LayoutParams(-1, dp(17)))
        return box
    }

    private fun rawDataPanel(): LinearLayout {
        val panelBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(10, 9, 10, 9)
            setBackgroundColor(panel)
        }
        panelBox.addView(label("RAW ECU DATA", 13f, cyan, true))
        val raw = label(latestRawFrame, 10f, white, false).apply {
            tag = "latest_raw_data"
            setTextIsSelectable(true)
            maxLines = 5
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        rawDataView = raw
        panelBox.addView(raw, LinearLayout.LayoutParams(-1, -2))
        return panelBox
    }

    private fun dashboard() {
        body.addView(sectionTitle("LIVE ENGINE DASHBOARD"))
        val hero = panelBox()
        hero.addView(label("ENGINE RPM", 12f, cyan, true).apply { gravity = Gravity.CENTER })
        val rpmGauge = RpmGauge(this).apply { tag = "rpm_gauge" }
        hero.addView(rpmGauge, LinearLayout.LayoutParams(-1, dp(188)))
        hero.addView(label("RPM  •  LIVE ECU DATA", 10f, muted, true).apply { gravity = Gravity.CENTER })
        val speedRow = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, dp(4)) }
        speedRow.addView(label("SPEED  ", 13f, muted, true))
        speedRow.addView(label(telemetry["SPEED"] ?: "--", 30f, cyan, true).apply { tag = "value:SPEED" })
        speedRow.addView(label("  km/h", 12f, muted, false)); hero.addView(speedRow)
        body.addView(hero)

        body.addView(sectionTitle("ENGINE PARAMETERS"))
        val keys = listOf("TPS", "ECT", "IAT", "BAT", "AFR", "O2", "MAP", "INJ", "IGN", "STFT", "LTFT")
        keys.chunked(3).forEach { group ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            group.forEach { key ->
                val c = card(key)
                c.background = rounded(panel, Color.rgb(29, 75, 115), 12f)
                row.addView(c, LinearLayout.LayoutParams(0, dp(104), 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) })
            }
            repeat(3-group.size) { row.addView(View(this), LinearLayout.LayoutParams(0, dp(104), 1f)) }
            body.addView(row)
        }
        body.addView(sectionTitle("QUICK ACCESS"))
        val quick = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("GRAPH" to "กราฟเรียลไทม์", "DTC" to "อ่านรหัสขัดข้อง", "LOGGER" to "บันทึกข้อมูลดิบ").forEach { (page, title) ->
            quick.addView(styledButton(title, Color.rgb(0, 92, 190)) { showPage(page) }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        }
        body.addView(quick)
        body.addView(sectionTitle("LATEST ECU FRAME")); body.addView(rawDataPanel())
        body.addView(label("ค่าที่ ECU ไม่ส่งจะแสดงเป็น -- และจะไม่สร้างค่าจำลอง", 10f, muted, false).apply { setPadding(dp(4), dp(8), dp(4), dp(4)) })
    }

    private fun graphPage() {
        body.addView(sectionTitle("LIVE GRAPH ANALYZER"))
        val picker = Spinner(this)
        val options = arrayOf("RPM", "TPS", "ECT", "IAT", "BAT", "SPEED", "MAP", "AFR", "O2")
        picker.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, options)
        body.addView(picker)
        graph = LiveGraph(this).apply { metric = selectedMetric; background = rounded(Color.rgb(8, 13, 22), Color.rgb(35, 91, 145), 14f) }
        body.addView(graph, LinearLayout.LayoutParams(-1, dp(270)).apply { topMargin = dp(8) })
        picker.setSelection(options.indexOf(selectedMetric).coerceAtLeast(0))
        picker.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) { selectedMetric = options[position]; graph.metric = selectedMetric; graph.invalidate() }
        }
        body.addView(label("ข้อมูลกราฟมาจาก telemetry ที่ได้รับจริงผ่าน Bluetooth เท่านั้น", 11f, muted, false).apply { setPadding(0, dp(8), 0, 0) })
    }

    private fun loggerPage() {
        body.addView(sectionTitle("RAW ECU LOGGER"))
        body.addView(label("บันทึกทุกบรรทัดที่ ESP32 ส่งผ่าน Bluetooth รวม telemetry และเฟรม RAW ที่เปิดใช้ใน Firmware", 12f, muted, false))
        val stats = panelBox()
        stats.addView(label("SESSION RECORDS", 10f, cyan, true))
        val count = label("${synchronized(logRows) { logRows.size }} RECORDS", 28f, white, true).apply { tag = "logger_count" }
        stats.addView(count); body.addView(stats)
        body.addView(sectionTitle("LATEST RAW FRAME")); body.addView(rawDataPanel())
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val start = styledButton(if (logging) "STOP CAPTURE" else "START CAPTURE", if (logging) Color.rgb(150,45,45) else Color.rgb(0,130,65)) { logging = !logging; showPage("LOGGER"); toast(if (logging) "เริ่มบันทึกข้อมูลแล้ว" else "หยุดบันทึกแล้ว") }
        val export = styledButton("EXPORT CSV", Color.rgb(0,100,200)) {
            if (logRows.isEmpty()) toast("ยังไม่มีข้อมูล กรุณาเชื่อมต่อและเริ่มบันทึก") else {
                val csv = buildString { append("record_type,time_ms,raw_table,raw_length,raw_hex,"); append(telemetry.keys.joinToString(",")).append('\n'); synchronized(logRows) { logRows.forEach { append(it).append('\n') } } }
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "text/csv"; putExtra(Intent.EXTRA_TITLE, "Nattawut_RAW_ECU_Log.csv") }; pendingCsv = csv; startActivityForResult(intent,77)
            }
        }
        actions.addView(start, LinearLayout.LayoutParams(0, dp(48), 1f).apply { setMargins(0, dp(8), dp(4), 0) }); actions.addView(export, LinearLayout.LayoutParams(0, dp(48), 1f).apply { setMargins(dp(4), dp(8), 0, 0) }); body.addView(actions)
        body.addView(label("หมายเหตุ: บันทึกข้อมูลที่ผ่าน Serial/Bluetooth API ของ Firmware ไม่ใช่การดักจับสัญญาณ K-Line แบบ passive", 10f, Color.YELLOW, false).apply { setPadding(0, dp(10), 0, 0) })
    }

    private fun updateLoggerCount() { body.findViewWithTag<TextView>("logger_count")?.text = "${synchronized(logRows) { logRows.size }} RECORDS" }

    private fun infoRow(title: String, value: String): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(8), 0, dp(8)) }
        row.addView(label(title, 12f, muted, false), LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(label(value, 12f, white, true), LinearLayout.LayoutParams(0, -2, 1f)); return row
    }

    private fun dtcPage() {
        body.addView(sectionTitle("DTC DIAGNOSTICS"))
        val box = panelBox(); box.addView(label("HONDA PGM-FI  •  ECU S4", 13f, cyan, true))
        box.addView(label("ระบบอ่าน/ลบรหัสขัดข้องผ่านแอปยังรอคำสั่ง Bluetooth API ที่ผ่านการตรวจสอบกับ Firmware V8 และ ECU จริง", 12f, muted, false).apply { setPadding(0, dp(8), 0, dp(8)) })
        box.addView(label("ไม่มีการสร้างรหัส DTC ตัวอย่างหรือแสดงผลปลอม", 11f, Color.YELLOW, true)); body.addView(box)
        val read = styledButton("SCAN STORED / CURRENT DTC", Color.rgb(0,100,190)) { toast("Firmware ที่ใช้อยู่ยังไม่เปิด API DTC ผ่าน Bluetooth — ยังไม่ส่งคำสั่งไป ECU") }
        val clear = styledButton("CLEAR DTC  •  LOCKED", Color.rgb(140,40,45)) { toast("การลบ DTC ยังล็อกไว้จนกว่าจะยืนยันคำสั่งและผลตอบกลับจาก ECU") }
        body.addView(read, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(10) }); body.addView(clear, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(8) })
    }

    private fun ecuPage() {
        body.addView(sectionTitle("ECU INFORMATION")); val box = panelBox()
        listOf("Motorcycle" to "Honda Wave 110i 2009", "ECU family" to "Keihin S4 (user supplied)", "Protocol" to "K-Line / ISO 14230-4", "Baud rate" to "10400", "Bluetooth" to if (socket != null) "CONNECTED" else "DISCONNECTED", "Telemetry packets" to receivedPackets.toString(), "ECU identity" to "ยังไม่ได้อ่านจาก ECU ใน session นี้", "Write / Flash / Remap" to "DISABLED").forEach { box.addView(infoRow(it.first, it.second)) }
        body.addView(box); body.addView(styledButton("REFRESH LINK STATUS", Color.rgb(0,100,190)) { showPage("ECU") })
    }

    private fun mapPage() {
        body.addView(sectionTitle("MAP FILE MANAGER")); val box = panelBox()
        box.addView(label("MAP FILE WORKSPACE", 13f, cyan, true)); box.addView(label("เลือกไฟล์ .map จากมือถือเพื่อจัดเก็บและเตรียมวิเคราะห์ได้ แต่การอัปโหลดเข้า ECU/SD ของบอร์ดยังไม่เปิด เพราะ Firmware ยังไม่มี MAP transfer API ที่ยืนยันแล้ว", 12f, muted, false).apply { setPadding(0, dp(8), 0, dp(8)) }); body.addView(box)
        body.addView(styledButton("SELECT MAP FILE", Color.rgb(0,100,190)) { val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }; startActivityForResult(i, 78) }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(10) })
        body.addView(label("ECU MAP WRITE / FLASH: DISABLED", 11f, Color.YELLOW, true).apply { setPadding(0, dp(10), 0, 0) })
    }

    private fun controlPage() {
        body.addView(sectionTitle("REMOTE CONTROL PANEL")); val box = panelBox()
        box.addView(label("LOCAL APP CONTROLS", 13f, cyan, true)); box.addView(label("ปุ่มด้านล่างเป็นการนำทางและตั้งค่าภายในแอปเท่านั้น ยังไม่ส่งคำสั่งควบคุม ECU หรือฮาร์ดแวร์จนกว่าจะมี API ที่รองรับ", 12f, muted, false).apply { setPadding(0, dp(8), 0, dp(8)) }); body.addView(box)
        listOf("Dashboard" to "DASHBOARD", "Live Graph" to "GRAPH", "RAW Logger" to "LOGGER", "DTC Diagnostics" to "DTC", "Bluetooth" to "BLUETOOTH").forEach { (t,p) -> body.addView(styledButton(t, Color.rgb(0,90,175)) { showPage(p) }, LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(6) }) }
    }

    private fun gpsPage() {
        body.addView(sectionTitle("GPS SOURCE / SPEED"))
        val box = panelBox()
        box.addView(label("ACTIVE SPEED", 12f, cyan, true).apply { gravity = Gravity.CENTER })
        gpsSpeedView = label("${telemetry["SPEED"] ?: "--"} km/h", 34f, white, true).apply {
            gravity = Gravity.CENTER; setPadding(0, dp(8), 0, dp(8))
        }
        box.addView(gpsSpeedView)
        gpsSourceView = label("แหล่ง GPS: ${if (gpsSource == "PHONE") "โทรศัพท์" else "GPS บนบอร์ด"}", 14f, cyan, true).apply { gravity = Gravity.CENTER }
        box.addView(gpsSourceView)
        gpsPositionView = label("ตำแหน่งโทรศัพท์: --", 11f, muted, false).apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, 0) }
        box.addView(gpsPositionView)
        body.addView(box)

        body.addView(sectionTitle("เลือกแหล่งความเร็ว GPS"))
        body.addView(styledButton(if (gpsSource == "BOARD") "✓ GPS MODULE บนบอร์ด (UART)" else "ใช้ GPS MODULE บนบอร์ด", Color.rgb(0, 105, 170)) {
            selectGpsSource("BOARD")
        }, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(4) })
        body.addView(styledButton(if (gpsSource == "PHONE") "✓ GPS จากโทรศัพท์ Android" else "ใช้ GPS จากโทรศัพท์ Android", Color.rgb(0, 125, 85)) {
            selectGpsSource("PHONE")
        }, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(8) })
        body.addView(label("โหมดบอร์ดอ่าน NMEA จาก GPS Module ผ่าน UART เดิม ส่วนโหมดโทรศัพท์ใช้ Location ของ Android และส่งความเร็วผ่าน Bluetooth SPP", 11f, muted, false).apply { setPadding(0, dp(10), 0, 0) })
        updateGpsPageValues()
    }

    private fun selectGpsSource(source: String) {
        gpsSource = source
        gpsPrefs.edit().putString("source", source).apply()
        if (source == "BOARD") {
            stopPhoneLocation()
            sendBtCommand("GPS_SOURCE,BOARD")
            toast("เลือก GPS Module บนบอร์ดแล้ว")
            showPage("GPS")
        } else {
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 42)
                return
            }
            sendBtCommand("GPS_SOURCE,PHONE")
            startPhoneLocation()
            toast("เลือก GPS โทรศัพท์แล้ว")
            showPage("GPS")
        }
    }

    private fun startPhoneLocation() {
        if (gpsSource != "PHONE") return
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return
        try {
            val manager = locationManager ?: return
            if (!manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                toast("กรุณาเปิด Location/GPS ของโทรศัพท์")
                return
            }
            manager.removeUpdates(phoneLocationListener)
            manager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, phoneLocationListener, Looper.getMainLooper())
            manager.getLastKnownLocation(LocationManager.GPS_PROVIDER)?.let { phoneLocationListener.onLocationChanged(it) }
        } catch (e: SecurityException) {
            toast("ยังไม่ได้รับสิทธิ์ Location")
        } catch (e: Exception) {
            toast("เริ่ม GPS โทรศัพท์ไม่สำเร็จ: ${e.message}")
        }
    }

    private fun stopPhoneLocation() {
        try { locationManager?.removeUpdates(phoneLocationListener) } catch (_: Exception) { }
    }

    private fun updateGpsPageValues() {
        runOnUiThread {
            gpsSourceView?.text = "แหล่ง GPS: ${if (gpsSource == "PHONE") "โทรศัพท์ Android" else "GPS Module บนบอร์ด"}"
            val speed = if (gpsSource == "PHONE") phoneGpsSpeed?.toString() ?: "--" else telemetry["SPEED"] ?: "--"
            gpsSpeedView?.text = "$speed km/h"
            gpsPositionView?.text = if (phoneLatitude != null && phoneLongitude != null)
                "ตำแหน่งโทรศัพท์: %.5f, %.5f".format(phoneLatitude, phoneLongitude) else "ตำแหน่งโทรศัพท์: --"
        }
    }

    private fun sendBtCommand(command: String) {
        val activeSocket = socket ?: return
        try {
            synchronized(activeSocket) {
                activeSocket.outputStream.write((command + "\n").toByteArray(Charsets.UTF_8))
                activeSocket.outputStream.flush()
            }
        } catch (e: Exception) {
            runOnUiThread { toast("ส่งคำสั่ง Bluetooth ไม่สำเร็จ: ${e.message}") }
        }
    }

    private fun bluetoothPage() {
        body.addView(sectionTitle("BLUETOOTH MANAGER")); val box = panelBox()
        box.addView(label("NATTAWUT ECU", 22f, cyan, true).apply { gravity = Gravity.CENTER })
        box.addView(label(if (socket != null) "● CONNECTED" else "● DISCONNECTED", 16f, if (socket != null) Color.GREEN else Color.RED, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, dp(8)) })
        box.addView(label("Bluetooth Classic SPP / RFCOMM", 11f, muted, false).apply { gravity = Gravity.CENTER }); body.addView(box)
        body.addView(styledButton(if (socket == null) "CONNECT PAIRED DEVICE" else "DISCONNECT", Color.rgb(0,105,200)) { if (socket == null) showPairedDevices() else disconnect() }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(10) })
        body.addView(label("จับคู่ชื่ออุปกรณ์ Nattawut ECU ในการตั้งค่า Bluetooth ของ Android ก่อนเชื่อมต่อ", 11f, muted, false).apply { setPadding(0, dp(8), 0, 0) })
    }

    private fun imagesPage() {
        body.addView(sectionTitle("BOOT LOGO / FLASH IMAGE MANAGER"))
        val intro = panelBox()
        intro.addView(label("เลือกภาพหลายภาพจากโทรศัพท์ แล้วส่งเก็บใน Flash ภายใน ESP32-CYD", 13f, white, true))
        intro.addView(label("ภาพจะถูกปรับเป็น 320×240 RGB565 ก่อนส่งผ่าน Bluetooth Classic SPP • ไม่ต้องใช้ microSD", 11f, muted, false).apply {
            setPadding(0, dp(7), 0, dp(4))
        })
        imagePreviewView = ImageView(this).apply {
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.BLACK)
            minimumHeight = dp(150)
            maxHeight = dp(190)
        }
        intro.addView(imagePreviewView, LinearLayout.LayoutParams(-1, dp(170)))
        imageSelectionView = label(if (selectedImageUris.isEmpty()) "ยังไม่ได้เลือกภาพ" else "เลือกแล้ว ${selectedImageUris.size} ภาพ", 12f, cyan, false).apply {
            setPadding(0, dp(8), 0, dp(4))
        }
        intro.addView(imageSelectionView)
        selectedImageUris.firstOrNull()?.let { uri ->
            try { imagePreviewView?.setImageBitmap(createScreenPreview(uri)) } catch (_: Exception) { }
        }
        body.addView(intro)

        body.addView(styledButton("SELECT MULTIPLE PHOTOS", Color.rgb(0, 105, 190)) {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "image/*"
                putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            }
            startActivityForResult(intent, 79)
        }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(8) })

        body.addView(styledButton("SEND SELECTED PHOTOS TO ESP32", Color.rgb(0, 125, 75)) {
            uploadSelectedImages()
        }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(8) })

        imageProgressView = label("รอการส่งภาพ", 11f, muted, false).apply { setPadding(dp(4), dp(8), dp(4), dp(8)) }
        body.addView(imageProgressView)
        imageStorageView = label("ยังไม่ได้อ่านสถานะ Flash", 11f, cyan, false).apply { setPadding(dp(4), dp(2), dp(4), dp(8)) }
        body.addView(imageStorageView)
        body.addView(styledButton("REFRESH ESP32 IMAGE LIST", Color.rgb(38, 66, 95)) {
            refreshImageList()
        }, LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(4) })
        body.addView(styledButton("INITIALIZE EMPTY FLASH STORAGE", Color.rgb(105, 75, 25)) {
            AlertDialog.Builder(this)
                .setTitle("Initialize LittleFS storage?")
                .setMessage("ใช้เฉพาะเมื่อบอร์ดแจ้งว่า Flash storage ยังไม่พร้อม การทำรายการนี้จะ format เฉพาะ partition LittleFS และลบไฟล์ทั้งหมดใน partition นั้น หากมีข้อมูลเดิมอยู่")
                .setNegativeButton("ยกเลิก", null)
                .setPositiveButton("ยืนยันเริ่มต้น") { _, _ -> initializeImageStorage() }
                .show()
        }, LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(6) })
        body.addView(sectionTitle("IMAGES STORED ON ESP32"))
        imageListContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        body.addView(imageListContainer)
        renderBoardImages()
        refreshImageList()
    }

    private fun updateImageProgress(message: String) {
        runOnUiThread { imageProgressView?.text = message }
    }

    private fun writeImageCommand(active: BluetoothSocket, command: String) {
        synchronized(active) {
            active.outputStream.write((command + "\n").toByteArray(Charsets.UTF_8))
            active.outputStream.flush()
        }
    }

    private fun nextImageResponse(timeoutSeconds: Long = 10L): String {
        val response = imageResponses.poll(timeoutSeconds, TimeUnit.SECONDS)
            ?: throw IllegalStateException("ESP32 ไม่ตอบกลับภายใน ${timeoutSeconds} วินาที")
        if (response.startsWith("NATTWUT_IMG,ERR,")) {
            throw IllegalStateException(response.substringAfterLast(','))
        }
        return response
    }

    private fun fetchBoardImages(active: BluetoothSocket): Pair<List<BoardImage>, String> {
        imageResponses.clear()
        writeImageCommand(active, "IMG_LIST")
        val found = mutableListOf<BoardImage>()
        var storage = ""
        val deadline = System.currentTimeMillis() + 15000L
        while (System.currentTimeMillis() < deadline) {
            val remaining = ((deadline - System.currentTimeMillis()) / 1000L).coerceAtLeast(1L)
            val line = nextImageResponse(remaining)
            val fields = line.split(',')
            when (fields.getOrNull(1)) {
                "ITEM" -> {
                    val slot = fields.getOrNull(2)?.toIntOrNull() ?: continue
                    val bytes = fields.getOrNull(3)?.toLongOrNull() ?: 0L
                    val selected = fields.getOrNull(4) == "1"
                    found.add(BoardImage(slot, bytes, selected))
                }
                "LIST_END" -> {
                    val total = fields.getOrNull(2)?.toLongOrNull() ?: 0L
                    val used = fields.getOrNull(3)?.toLongOrNull() ?: 0L
                    val free = fields.getOrNull(4)?.toLongOrNull() ?: 0L
                    storage = "LittleFS: ใช้ ${(used / 1024)} KB / ${(total / 1024)} KB • ว่าง ${(free / 1024)} KB • รองรับสูงสุด 8 ช่อง"
                    return Pair(found.sortedBy { it.slot }, storage)
                }
            }
        }
        throw IllegalStateException("ไม่ได้รับรายการภาพจาก ESP32")
    }

    private fun refreshImageList() {
        val active = socket
        if (active == null) {
            imageStorageView?.text = "กรุณาเชื่อมต่อ Bluetooth กับ Nattawut ECU ก่อน"
            return
        }
        if (imageTransferBusy) return
        imageTransferBusy = true
        updateImageProgress("กำลังอ่านรายการภาพจากบอร์ด…")
        thread {
            try {
                val result = fetchBoardImages(active)
                runOnUiThread {
                    boardImages.clear()
                    boardImages.addAll(result.first)
                    imageStorageView?.text = result.second
                    renderBoardImages()
                    imageProgressView?.text = "อ่านรายการภาพสำเร็จ • ${boardImages.size} ภาพ"
                }
            } catch (e: Exception) {
                updateImageProgress("อ่านรายการภาพไม่สำเร็จ: ${e.message}")
            } finally {
                imageTransferBusy = false
            }
        }
    }

    private fun initializeImageStorage() {
        val active = socket ?: run { toast("กรุณาเชื่อมต่อ Bluetooth ก่อน"); return }
        if (imageTransferBusy) return
        imageTransferBusy = true
        updateImageProgress("กำลังเริ่มต้น LittleFS…")
        thread {
            try {
                imageResponses.clear()
                writeImageCommand(active, "IMG_FORMAT_CONFIRM")
                val response = nextImageResponse(20L)
                if (!response.startsWith("NATTWUT_IMG,FORMAT,OK,")) throw IllegalStateException(response)
                val result = fetchBoardImages(active)
                runOnUiThread {
                    boardImages.clear(); boardImages.addAll(result.first)
                    imageStorageView?.text = result.second
                    renderBoardImages()
                    imageProgressView?.text = "เริ่มต้น Flash storage สำเร็จ"
                }
            } catch (e: Exception) {
                updateImageProgress("เริ่มต้น Flash storage ไม่สำเร็จ: ${e.message}")
            } finally {
                imageTransferBusy = false
            }
        }
    }

    private fun renderBoardImages() {
        val container = imageListContainer ?: return
        container.removeAllViews()
        if (boardImages.isEmpty()) {
            container.addView(label("ยังไม่มีภาพใน Flash หรือยังไม่ได้เชื่อมต่อบอร์ด", 12f, muted, false).apply {
                setPadding(dp(8), dp(8), dp(8), dp(12))
            })
            return
        }
        boardImages.forEach { item ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(10), dp(8), dp(10), dp(8))
                background = rounded(Color.rgb(20, 29, 44), Color.rgb(45, 75, 110), 12f)
            }
            row.addView(label("ช่อง ${item.slot + 1} • ${item.bytes / 1024} KB${if (item.selected) " • โลโก้เปิดเครื่อง + พื้นหลังปัจจุบัน" else ""}",
                12f, if (item.selected) Color.GREEN else white, true))
            val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            actions.addView(styledButton(if (item.selected) "BOOT + BACKGROUND" else "USE AT BOOT + BG", Color.rgb(0, 105, 160)) {
                performImageAction("IMG_SELECT,${item.slot}", "SELECT")
            }, LinearLayout.LayoutParams(0, dp(42), 1f).apply { setMargins(0, dp(6), dp(4), 0) })
            actions.addView(styledButton("DELETE", Color.rgb(130, 45, 48)) {
                AlertDialog.Builder(this).setTitle("ลบภาพช่อง ${item.slot + 1}?")
                    .setMessage("ภาพนี้จะถูกลบจาก Flash ภายใน ESP32")
                    .setNegativeButton("ยกเลิก", null)
                    .setPositiveButton("ลบ") { _, _ -> performImageAction("IMG_DELETE,${item.slot}", "DELETE") }
                    .show()
            }, LinearLayout.LayoutParams(0, dp(42), 1f).apply { setMargins(dp(4), dp(6), 0, 0) })
            row.addView(actions)
            container.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        }
    }

    private fun performImageAction(command: String, expectedAction: String) {
        val active = socket ?: run { toast("กรุณาเชื่อมต่อ Bluetooth ก่อน"); return }
        if (imageTransferBusy) return
        imageTransferBusy = true
        updateImageProgress("กำลังส่งคำสั่งไปยังบอร์ด…")
        thread {
            try {
                imageResponses.clear()
                writeImageCommand(active, command)
                val response = nextImageResponse(8L)
                if (!response.contains(",${expectedAction},OK,")) throw IllegalStateException(response)
                val result = fetchBoardImages(active)
                runOnUiThread {
                    boardImages.clear(); boardImages.addAll(result.first)
                    imageStorageView?.text = result.second
                    renderBoardImages()
                    imageProgressView?.text = if (expectedAction == "SELECT") "ตั้งภาพเป็นโลโก้เปิดเครื่องและพื้นหลังเรียบร้อยแล้ว" else "ดำเนินการสำเร็จ"
                }
            } catch (e: Exception) {
                updateImageProgress("ดำเนินการไม่สำเร็จ: ${e.message}")
            } finally {
                imageTransferBusy = false
            }
        }
    }

    /** Open SAF/gallery URIs through both AssetFileDescriptor and InputStream paths.
     * Some Android document providers return a usable file descriptor but a null
     * openInputStream(), so do not assume every content:// URI behaves identically.
     */
    private fun openImageInputStream(uri: Uri): java.io.InputStream {
        var firstError: Exception? = null
        try {
            val afd = contentResolver.openAssetFileDescriptor(uri, "r")
            if (afd != null) return afd.createInputStream()
        } catch (e: Exception) { firstError = e }
        try {
            val stream = contentResolver.openInputStream(uri)
            if (stream != null) return stream
        } catch (e: Exception) {
            if (firstError == null) firstError = e else firstError?.addSuppressed(e)
        }
        val detail = firstError?.message?.takeIf { it.isNotBlank() } ?: "ผู้ให้บริการไฟล์ไม่คืนข้อมูล"
        throw IllegalStateException("Android เปิด URI ภาพไม่ได้ ($detail)", firstError)
    }

    private fun decodeSampledImage(uri: Uri, maxWidth: Int, maxHeight: Int): Bitmap {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        openImageInputStream(uri).use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
            throw IllegalStateException("ไฟล์นี้ไม่ใช่ภาพที่อ่านได้ หรือภาพยังอยู่บน Cloud: ${uri.lastPathSegment ?: uri}")
        }
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= maxWidth && bounds.outHeight / (sample * 2) >= maxHeight) sample *= 2
        val options = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.RGB_565
            inDither = true
        }
        return openImageInputStream(uri).use { input ->
            BitmapFactory.decodeStream(input, null, options)
                ?: throw IllegalStateException("ถอดรหัสภาพไม่ได้ (${bounds.outWidth}x${bounds.outHeight})")
        }
    }

    private fun createScreenPreview(uri: Uri): Bitmap {
        val source = decodeSampledImage(uri, 640, 480)
        val output = Bitmap.createBitmap(320, 240, Bitmap.Config.RGB_565)
        val canvas = Canvas(output)
        canvas.drawColor(Color.BLACK)
        val scale = max(320f / source.width.toFloat(), 240f / source.height.toFloat())
        val width = source.width * scale
        val height = source.height * scale
        val left = (320f - width) / 2f
        val top = (240f - height) / 2f
        val paint = Paint(Paint.FILTER_BITMAP_FLAG)
        canvas.drawBitmap(source, null, RectF(left, top, left + width, top + height), paint)
        source.recycle()
        return output
    }

    private fun decodeUriToRgb565(uri: Uri): ByteArray {
        val output = createScreenPreview(uri)
        val pixels = IntArray(320 * 240)
        output.getPixels(pixels, 0, 320, 0, 0, 320, 240)
        val bytes = ByteArray(320 * 240 * 2)
        var offset = 0
        pixels.forEach { color ->
            val r = Color.red(color)
            val g = Color.green(color)
            val b = Color.blue(color)
            val rgb565 = ((r shr 3) shl 11) or ((g shr 2) shl 5) or (b shr 3)
            bytes[offset++] = (rgb565 and 0xFF).toByte()
            bytes[offset++] = ((rgb565 shr 8) and 0xFF).toByte()
        }
        output.recycle()
        return bytes
    }

    private fun uploadSelectedImages() {
        val active = socket ?: run { toast("กรุณาเชื่อมต่อ Bluetooth กับ ESP32 ก่อน"); return }
        if (selectedImageUris.isEmpty()) { toast("กรุณาเลือกภาพก่อน"); return }
        if (imageTransferBusy) return
        imageTransferBusy = true
        val uris = selectedImageUris.toList()
        thread {
            var binaryChunkInFlight = false
            try {
                var stored = fetchBoardImages(active).first.toMutableList()
                var completed = 0
                for (uri in uris) {
                    val freeSlot = (0 until 8).firstOrNull { slot -> stored.none { it.slot == slot } }
                        ?: throw IllegalStateException("ช่องเก็บภาพเต็มแล้ว (สูงสุด 8 ช่อง)")
                    updateImageProgress("กำลังเตรียมภาพ ${completed + 1}/${uris.size}…")
                    val payload = decodeUriToRgb565(uri)
                    val crc = CRC32().apply { update(payload) }.value
                    imageResponses.clear()
                    writeImageCommand(active, "IMG_BEGIN,$freeSlot,${payload.size},$crc")
                    val ready = nextImageResponse(12L)
                    if (!ready.startsWith("NATTWUT_IMG,READY,")) throw IllegalStateException(ready)

                    var offset = 0
                    val chunkSize = 256
                    while (offset < payload.size) {
                        val length = minOf(chunkSize, payload.size - offset)
                        binaryChunkInFlight = true
                        synchronized(active) {
                            active.outputStream.write(("IMG_CHUNK,$length\n").toByteArray(Charsets.UTF_8))
                            active.outputStream.write(payload, offset, length)
                            active.outputStream.flush()
                        }
                        val ack = nextImageResponse(12L)
                        binaryChunkInFlight = false
                        val acknowledged = ack.substringAfterLast(',').toIntOrNull()
                        val expected = offset + length
                        if (!ack.startsWith("NATTWUT_IMG,ACK,") || acknowledged != expected) {
                            throw IllegalStateException("ยืนยันข้อมูลไม่ตรงกันที่ $expected bytes: $ack")
                        }
                        offset += length
                        val overall = ((completed * payload.size + offset) * 100L / (uris.size * payload.size)).toInt()
                        updateImageProgress("กำลังส่งภาพ ${completed + 1}/${uris.size}: $overall% (${offset / 1024} / ${payload.size / 1024} KB)")
                    }
                    writeImageCommand(active, "IMG_END")
                    val done = nextImageResponse(15L)
                    if (!done.startsWith("NATTWUT_IMG,DONE,$freeSlot")) throw IllegalStateException(done)
                    stored.add(BoardImage(freeSlot, payload.size.toLong(), false))
                    completed++
                    updateImageProgress("บันทึกภาพ ${completed}/${uris.size} สำเร็จ")
                }
                val result = fetchBoardImages(active)
                runOnUiThread {
                    boardImages.clear(); boardImages.addAll(result.first)
                    imageStorageView?.text = result.second
                    renderBoardImages()
                    imageProgressView?.text = "ส่งภาพครบ ${completed} ภาพแล้ว • เลือก USE AT BOOT + BG เพื่อใช้ภาพเดียวกันเป็นโลโก้และพื้นหลัง"
                }
            } catch (e: Exception) {
                if (binaryChunkInFlight) {
                    // The ESP32 is waiting for exact binary payload length; close the
                    // link so firmware can safely discard the incomplete temp file.
                    try { active.close() } catch (_: Exception) { }
                    runOnUiThread {
                        if (socket === active) {
                            socket = null
                            status.text = "● DISCONNECTED • IMAGE TRANSFER INTERRUPTED"
                            status.setTextColor(Color.RED)
                            connectBtn.text = "CONNECT TO ESP32"
                            connectBtn.isEnabled = true
                        }
                    }
                } else {
                    try { writeImageCommand(active, "IMG_ABORT") } catch (_: Exception) { }
                }
                updateImageProgress("ส่งภาพไม่สำเร็จ: ${e.message}")
            } finally {
                imageTransferBusy = false
            }
        }
    }

    private fun settingsPage() {
        body.addView(sectionTitle("SMARTGAUGE SETTINGS")); val box = panelBox()
        box.addView(label("ACCENT COLOR", 12f, cyan, true))
        val colors = listOf(Color.rgb(0,160,255), Color.RED, Color.GREEN, Color.MAGENTA, Color.YELLOW)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        colors.forEach { c -> val b = View(this).apply { background = rounded(c, Color.WHITE, 30f); setOnClickListener { accent = c; themeColor = c; toast("เปลี่ยนสีเน้นของแอปแล้ว"); showPage("SETTINGS") } }; row.addView(b, LinearLayout.LayoutParams(dp(42), dp(42)).apply { setMargins(dp(8), dp(10), dp(8), dp(10)) }) }
        box.addView(row); box.addView(infoRow("Telemetry protocol", "NATTWUT,1 CSV")); box.addView(infoRow("Bluetooth", "Classic SPP")); box.addView(infoRow("Missing ECU values", "-- / NA")); body.addView(box)
        body.addView(styledButton("DISCONNECT BLUETOOTH", Color.rgb(130,40,45)) { disconnect() }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(10) })
    }

    private fun requestBtPermission() {
    if (Build.VERSION.SDK_INT >= 31) {
        val permissions = mutableListOf<String>()

        if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            permissions.add(Manifest.permission.BLUETOOTH_CONNECT)
        }

        if (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
            permissions.add(Manifest.permission.BLUETOOTH_SCAN)
        }

        if (permissions.isNotEmpty()) {
            requestPermissions(permissions.toTypedArray(), 41)
        }
    }
}

    override fun onRequestPermissionsResult(
    requestCode: Int,
    permissions: Array<out String>,
    grantResults: IntArray
) {
    super.onRequestPermissionsResult(requestCode, permissions, grantResults)

    if (requestCode == 41 && Build.VERSION.SDK_INT >= 31) {
        val connectGranted =
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

        val scanGranted =
            checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED

        if (!connectGranted || !scanGranted) {
            toast("กรุณาอนุญาต Nearby devices / Bluetooth")
        } else {
            toast("อนุญาต Bluetooth แล้ว กรุณากด CONNECT อีกครั้ง")
        }
    }
    if (requestCode == 42) {
        val granted = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (granted) {
            sendBtCommand("GPS_SOURCE,PHONE")
            startPhoneLocation()
            showPage("GPS")
        } else {
            gpsSource = "BOARD"
            gpsPrefs.edit().putString("source", "BOARD").apply()
            sendBtCommand("GPS_SOURCE,BOARD")
            toast("ไม่ได้รับสิทธิ์ Location จึงกลับไปใช้ GPS บนบอร์ด")
            showPage("GPS")
        }
    }
}

    private fun showPairedDevices() {
        if (Build.VERSION.SDK_INT >= 31 &&
    (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED ||
     checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED)
) {
            requestBtPermission(); return
        }
        val adapter = BluetoothAdapter.getDefaultAdapter()
        if (adapter == null) { toast("โทรศัพท์ไม่รองรับ Bluetooth Classic"); return }
        if (!adapter.isEnabled) { toast("กรุณาเปิด Bluetooth ก่อน"); return }
        val devices = adapter.bondedDevices?.toList().orEmpty()
        if (devices.isEmpty()) { toast("จับคู่ ESP32 ชื่อ Nattawut ECU ใน Settings > Bluetooth ก่อน"); return }
        val names = devices.map { "${it.name ?: "Unknown"} (${it.address})" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("เลือกอุปกรณ์ SmartGauge").setItems(names) { _, which -> connect(devices[which]) }
            .setNegativeButton("ยกเลิก", null).show()
    }
private fun connect(device: BluetoothDevice) {
    if (Build.VERSION.SDK_INT >= 31 &&
    (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED ||
     checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED)
) {
    requestBtPermission()
    return
}

    connectBtn.isEnabled = false
    status.text = "● CONNECTING..."
    status.setTextColor(Color.YELLOW)

    thread {
        var newSocket: BluetoothSocket? = null

        try {

            val connectedSocket =
                device.createRfcommSocketToServiceRecord(sppUuid)

            newSocket = connectedSocket
            connectedSocket.connect()

            socket = connectedSocket
            connectedSocket.outputStream.write(("PING\nSTATUS\nGPS_SOURCE,$gpsSource\n").toByteArray(Charsets.UTF_8))
            connectedSocket.outputStream.flush()
            if (gpsSource == "PHONE") runOnUiThread { startPhoneLocation() }

            runOnUiThread {
                status.text = "● CONNECTED • WAITING DATA"
                status.setTextColor(Color.GREEN)
                connectBtn.text = "DISCONNECT"
                connectBtn.isEnabled = true
            }

            readLoop(connectedSocket)

        } catch (e: Exception) {
            try {
                newSocket?.close()
            } catch (_: Exception) {
            }

            socket = null

            runOnUiThread {
                status.text = "● CONNECT FAILED: ${e.message}"
                status.setTextColor(Color.RED)
                connectBtn.text = "CONNECT"
                connectBtn.isEnabled = true
            }
        }
    }
}


    
private fun readLoop(s: BluetoothSocket) {
    readerThread = thread {
        try {
            runOnUiThread {
                if (socket === s) {
                    status.text = "● CONNECTED • WAITING DATA"
                    status.setTextColor(Color.YELLOW)
                }
            }

            val reader = BufferedReader(
                InputStreamReader(s.inputStream, Charsets.UTF_8)
            )

            while (!Thread.currentThread().isInterrupted) {
                val line = reader.readLine() ?: break

                if (line.isNotBlank()) {
                    parsePacket(line)
                }
            }

        } catch (e: Exception) {
            runOnUiThread {
                if (socket === s) {
                    status.text = "● READ ERROR: ${e.message}"
                    status.setTextColor(Color.RED)
                }
            }
            return@thread
        }

        runOnUiThread {
            if (socket === s) {
                socket = null
                status.text = "● DISCONNECTED"
                status.setTextColor(Color.RED)
                connectBtn.text = "CONNECT"
                connectBtn.isEnabled = true
            }
        }
    }
 }

    

    
private fun parsePacket(line: String) {

    val cleanLine = line.trim().removePrefix("\uFEFF")
    if (cleanLine.isEmpty()) return

    // Preserve every complete line received over Bluetooth while logging.
    if (logging) {
        val stamp = System.currentTimeMillis().toString()
        val escaped = cleanLine.replace("\\", "\\\\").replace("\"", "\"\"")
        val emptyTelemetry = telemetry.keys.joinToString(",") { "" }
        synchronized(logRows) {
            logRows.add(listOf("BT_RAW", stamp, "", "", "\"$escaped\"").joinToString(",") + "," + emptyTelemetry)
        }
    }
    latestRawFrame = cleanLine
    val p = cleanLine.split(',').map { it.trim() }

    if (p.firstOrNull() == "NATTWUT_IMG") {
        imageResponses.offer(cleanLine)
        return
    }

    if (p.firstOrNull() == "NATTWUT_ACK" || p.firstOrNull() == "NATTWUT_STATUS") {
        runOnUiThread {
            rawDataView?.text = latestRawFrame
            updateLoggerCount()
            if (p.firstOrNull() == "NATTWUT_STATUS") {
                status.text = "● LINK OK • ${p.drop(2).joinToString(" • ")}"
                status.setTextColor(Color.GREEN)
            }
        }
        return
    }

    // RAW frame sent separately by ESP32; keep it in the same session CSV.
    if (p.size >= 6 && p[0] == "NATTWUT_RAW" && p[1] == "1") {
        val timeMs = p[2].toLongOrNull() ?: System.currentTimeMillis()
        val table = p[3]
        val length = p[4]
        val hex = p.drop(5).joinToString(" ")
        latestRawFrame = "t=$timeMs ms | table=$table | len=$length\n$hex"
        if (logging) synchronized(logRows) {
            val emptyTelemetry = telemetry.keys.joinToString(",") { "" }
            logRows.add(listOf("RAW", timeMs.toString(), table, length, ("\"" + hex + "\"")).joinToString(",") + "," + emptyTelemetry)
        }
        runOnUiThread {
            rawDataView?.text = latestRawFrame
            updateLoggerCount()
        }
        return
    }

    // รับข้อมูลตั้งแต่ 15 ช่องขึ้นไป
    if (p.size < 15 || p[0] != "NATTWUT" || p[1] != "1") {
        runOnUiThread {
            status.text = "● INVALID PACKET: ${cleanLine.take(55)}"
            status.setTextColor(Color.RED)
        }
        return
    }

    val keys = listOf(
        "RPM", "TPS", "ECT", "IAT", "BAT",
        "O2", "AFR", "SPEED", "INJ", "IGN",
        "MAP", "STFT", "LTFT"
    )

    val row = mutableMapOf<String, String>()

    keys.forEachIndexed { i, key ->
        row[key] = if (p[i + 2] == "NA" || p[i + 2].isBlank()) "--" else p[i + 2]
    }

    synchronized(telemetry) {
        row.forEach { (k, v) -> telemetry[k] = v }
    }

    synchronized(this) {
        receivedPackets++
        lastPacketAt = System.currentTimeMillis()
        telemetryTimedOut = false
    }

    synchronized(histories) {
        keys.forEach { key ->
            val value = row[key]?.toFloatOrNull() ?: return@forEach
            val list = histories.getOrPut(key) { mutableListOf() }
            list.add(value)
            while (list.size > 120) list.removeAt(0)
        }
    }

    val rpm = row["RPM"]?.toFloatOrNull()
    if (rpm != null) {
        synchronized(samples) {
            samples.add(rpm)
            while (samples.size > 100) samples.removeAt(0)
        }
    }

    if (logging) {
        val stamp = System.currentTimeMillis().toString()
        synchronized(logRows) {
            logRows.add(
                listOf("TELEMETRY", stamp, "", "", "").joinToString(",") + "," +
                keys.joinToString(",") { key -> if (p[keys.indexOf(key) + 2] == "NA") "NA" else (row[key] ?: "0") }
            )
        }
        runOnUiThread { updateLoggerCount() }
    }

    runOnUiThread {
        status.text = "● DATA RECEIVED • #$receivedPackets"
        status.setTextColor(Color.GREEN)

        if (activePage == "DASHBOARD") {
            updateDashboardValues()
        } else if (activePage == "GRAPH") {
            graph.invalidate()
        } else if (activePage == "GPS" && gpsSource == "BOARD") {
            updateGpsPageValues()
        }
    }
}

    private fun updateDashboardValues() {
        fun walk(v: View) {
            if (v is TextView && v.tag is String && (v.tag as String).startsWith("value:")) {
                val key = (v.tag as String).substringAfter("value:")
                v.text = telemetry[key] ?: "--"
            }
            if (v is android.view.ViewGroup) for (i in 0 until v.childCount) walk(v.getChildAt(i))
        }
        walk(body)
        body.findViewWithTag<View>("rpm_gauge")?.invalidate()
    }

    private var pendingCsv: String? = null
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 78 && resultCode == RESULT_OK && data?.data != null) {
            toast("เลือกไฟล์ MAP แล้ว: ${data.data?.lastPathSegment ?: "ไฟล์"} — ยังไม่ส่งเข้า ECU")
        }
        if (requestCode == 79 && resultCode == RESULT_OK && data != null) {
            selectedImageUris.clear()
            val clip = data.clipData
            if (clip != null) {
                for (i in 0 until clip.itemCount) {
                    clip.getItemAt(i).uri?.let { if (!selectedImageUris.contains(it)) selectedImageUris.add(it) }
                }
            } else {
                data.data?.let { selectedImageUris.add(it) }
            }
            val grantedFlags = data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            selectedImageUris.forEach { uri ->
                try {
                    // Persist the exact read grant returned by the system picker when supported.
                    if ((grantedFlags and Intent.FLAG_GRANT_READ_URI_PERMISSION) != 0) {
                        contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                } catch (_: SecurityException) {
                    // A few OEM/document providers issue temporary grants only; the URI
                    // remains usable for this app session, so continue and report read errors later.
                } catch (_: Exception) { }
            }
            imageSelectionView?.text = "เลือกแล้ว ${selectedImageUris.size} ภาพ"
            selectedImageUris.firstOrNull()?.let { uri ->
                try {
                    imagePreviewView?.setImageBitmap(createScreenPreview(uri))
                } catch (e: Exception) {
                    imagePreviewView?.setImageDrawable(null)
                    imageProgressView?.text = "อ่านภาพตัวอย่างไม่ได้: ${e.message}"
                }
            }
        }
        if (requestCode == 77 && resultCode == RESULT_OK && data?.data != null) {
            try {
                contentResolver.openOutputStream(data.data!!)?.bufferedWriter()?.use { it.write(pendingCsv ?: "") }
                toast("ส่งออก CSV สำเร็จ")
            } catch (e: Exception) { toast("บันทึกไฟล์ไม่สำเร็จ: ${e.message}") }
        }
    }

    private fun disconnect() {
        stopPhoneLocation()
        try {
            socket?.let { active -> synchronized(active) { active.outputStream.write("GPS_SOURCE,BOARD\n".toByteArray(Charsets.UTF_8)); active.outputStream.flush() } }
            readerThread?.interrupt(); socket?.close()
        } catch (_: Exception) { }
        socket = null
        lastPacketAt = 0L
        telemetryTimedOut = true
        synchronized(telemetry) { telemetry.keys.forEach { telemetry[it] = "--" } }
        if (activePage == "DASHBOARD") updateDashboardValues()
        status.text = "● DISCONNECTED"; status.setTextColor(Color.RED)
        connectBtn.text = "CONNECT"; connectBtn.isEnabled = true
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    override fun onDestroy() { disconnect(); super.onDestroy() }

    inner class RpmGauge(context: android.content.Context) : View(context) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val cx = width / 2f; val cy = height * 0.78f
            val radius = minOf(width * 0.40f, height * 0.68f)
            val rect = android.graphics.RectF(cx-radius, cy-radius, cx+radius, cy+radius)
            p.style = Paint.Style.STROKE; p.strokeWidth = dp(9).toFloat(); p.strokeCap = Paint.Cap.ROUND
            p.color = Color.rgb(0, 155, 255); canvas.drawArc(rect, 135f, 150f, false, p)
            p.color = Color.rgb(255, 190, 0); canvas.drawArc(rect, 285f, 55f, false, p)
            p.color = Color.rgb(245, 55, 55); canvas.drawArc(rect, 340f, 65f, false, p)
            p.strokeWidth = dp(2).toFloat(); p.color = Color.WHITE
            for (i in 0..10) {
                val a = Math.toRadians((135.0 + i * 27.0)); val inner = radius - dp(17); val outer = radius - dp(5)
                canvas.drawLine(cx + kotlin.math.cos(a).toFloat()*inner, cy + kotlin.math.sin(a).toFloat()*inner,
                    cx + kotlin.math.cos(a).toFloat()*outer, cy + kotlin.math.sin(a).toFloat()*outer, p)
            }
            val rpm = telemetry["RPM"]?.toFloatOrNull() ?: 0f
            val angle = Math.toRadians(135.0 + (rpm.coerceIn(0f, 10000f) / 10000f) * 270.0)
            p.style = Paint.Style.STROKE; p.strokeWidth = dp(4).toFloat(); p.color = Color.WHITE
            canvas.drawLine(cx, cy, cx + kotlin.math.cos(angle).toFloat()*(radius-dp(24)), cy + kotlin.math.sin(angle).toFloat()*(radius-dp(24)), p)
            p.style = Paint.Style.FILL; p.color = cyan; canvas.drawCircle(cx, cy, dp(7).toFloat(), p)
            p.color = white; p.textAlign = Paint.Align.CENTER; p.typeface = Typeface.DEFAULT_BOLD; p.textSize = sp(31f)
            canvas.drawText(telemetry["RPM"] ?: "--", cx, cy-dp(19), p)
            p.textSize = sp(12f); p.color = muted; canvas.drawText("RPM x1000", cx, cy+dp(10), p)
        }
    }

    private fun sp(value: Float): Float = value * resources.displayMetrics.scaledDensity

    inner class LiveGraph(context: android.content.Context) : View(context) {
        var metric = "RPM"
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            canvas.drawColor(panel)
            paint.color = muted; paint.strokeWidth = 1f; paint.style = Paint.Style.STROKE
            for (i in 1..4) canvas.drawLine(20f, height * i / 5f, width - 12f, height * i / 5f, paint)
            val vals = synchronized(histories) { histories[metric]?.toList().orEmpty() }
            if (vals.size > 1) {
                val maxV = max(1000f, vals.maxOrNull() ?: 1000f)
                paint.color = cyan; paint.strokeWidth = 3f
                for (i in 1 until vals.size) {
                    val x1 = 20f + (width - 40f) * (i - 1) / (vals.size - 1)
                    val x2 = 20f + (width - 40f) * i / (vals.size - 1)
                    val y1 = height - 15f - (height - 30f) * vals[i - 1] / maxV
                    val y2 = height - 15f - (height - 30f) * vals[i] / maxV
                    canvas.drawLine(x1, y1, x2, y2, paint)
                }
            } else {
                paint.style = Paint.Style.FILL; paint.color = muted; paint.textSize = 13f
                canvas.drawText("Waiting for $metric telemetry…", 24f, height / 2f, paint)
            }
        }
    }
}
