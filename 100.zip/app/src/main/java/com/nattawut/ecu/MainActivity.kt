package com.nattawut.ecu

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.graphics.Canvas
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.RectF
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Base64
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.*
import android.view.ViewGroup
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.UUID
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.zip.CRC32
import kotlin.concurrent.thread
import kotlin.math.max

class MainActivity : Activity() {
    private val sppUuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private var socket: BluetoothSocket? = null
    private var readerThread: Thread? = null
    private var logging = false
    private val logRows = mutableListOf<String>()
    private val samples = mutableListOf<Float>()
    private val histories = mutableMapOf<String, MutableList<Float>>()
    private var receivedPackets = 0L
    private var lastPacketAt = 0L
    private val mainHandler = Handler(Looper.getMainLooper())
    private var telemetryTimedOut = true
    private val telemetry = linkedMapOf(
        "RPM" to "--", "TPS" to "--", "ECT" to "--", "IAT" to "--",
        "BAT" to "--", "O2" to "--", "AFR" to "--", "SPEED" to "--",
        "INJ" to "--", "IGN" to "--", "MAP" to "--", "STFT" to "--", "LTFT" to "--"
    )
    private var latestRawFrame = "ยังไม่ได้รับ RAW DATA จาก ECU"
    private var rawDataView: TextView? = null
    private val units = mapOf("RPM" to "rpm", "TPS" to "%", "ECT" to "°C", "IAT" to "°C",
        "BAT" to "V", "O2" to "V", "AFR" to "AFR", "SPEED" to "km/h",
        "INJ" to "ms", "IGN" to "deg", "MAP" to "kPa", "STFT" to "%", "LTFT" to "%")
    private lateinit var root: LinearLayout
    private lateinit var body: LinearLayout
    private lateinit var status: TextView
    private lateinit var connectBtn: Button
    private lateinit var navItems: LinearLayout
    private lateinit var graph: LiveGraph
    private var activePage = "DASHBOARD"
    private val gpsPrefs by lazy { getSharedPreferences("nattawut_gps", MODE_PRIVATE) }
    private var gpsSource = "BOARD"
    private var phoneGpsSpeed: Int? = null
    private var phoneLatitude: Double? = null
    private var phoneLongitude: Double? = null
    private var locationManager: LocationManager? = null
    private var gpsSpeedView: TextView? = null
    private var gpsSourceView: TextView? = null
    private var gpsPositionView: TextView? = null
    private val phoneLocationListener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            if (gpsSource != "PHONE") return
            phoneLatitude = location.latitude
            phoneLongitude = location.longitude
            if (!location.hasSpeed()) {
                updateGpsPageValues()
                return
            }
            val speed = (location.speed * 3.6f).toInt().coerceIn(0, 350)
            phoneGpsSpeed = speed
            sendBtCommand("PHONE_SPEED,$speed")
            updateGpsPageValues()
        }
        override fun onProviderEnabled(provider: String) { }
        override fun onProviderDisabled(provider: String) {
            if (provider == LocationManager.GPS_PROVIDER) runOnUiThread { toast("กรุณาเปิด Location/GPS ของโทรศัพท์") }
        }
    }

    private val bg = Color.rgb(8, 12, 21)
    private val panel = Color.rgb(20, 29, 44)
    private val cyan = Color.rgb(43, 220, 235)
    private val white = Color.WHITE
    private val muted = Color.rgb(155, 170, 190)
    private var accent = Color.rgb(0, 160, 255)
    private var themeColor = Color.rgb(0, 160, 255)
    private var selectedMetric = "RPM"
    private var ecuInfoText = "ECU: ยังไม่ได้รับข้อมูลระบุตัวตนจาก ECU"

    // V3.1 multi-image boot-logo management over the existing Bluetooth Classic SPP link.
    private data class BoardImage(val slot: Int, val bytes: Long, val selected: Boolean)
    private val imageResponses = LinkedBlockingQueue<String>()
    private val binResponses = LinkedBlockingQueue<String>()
    // DTC results are received from the same ECU scan used by the ESP32 display.
    private val dtcItems = mutableListOf<String>()
    @Volatile private var dtcScanStatus = "ยังไม่ได้ตรวจสอบ"
    @Volatile private var dtcExpectedCount = 0
    private var dtcStatusView: TextView? = null
    private var dtcResultsView: TextView? = null
    private var selectedBinUri: Uri? = null
    private var binTransferStatusView: TextView? = null
    private var pendingBinDownload: ByteArray? = null
    private var pendingBinDownloadName: String = "ECU_READ.BIN"
    @Volatile private var binTransferBusy = false
    private val selectedImageUris = mutableListOf<Uri>()
    private val boardImages = mutableListOf<BoardImage>()
    private var imageListContainer: LinearLayout? = null
    private var imageStorageView: TextView? = null
    private var imageSelectionView: TextView? = null
    private var imageProgressView: TextView? = null
    private var imagePreviewView: ImageView? = null
    @Volatile private var imageTransferBusy = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = Color.BLACK
        buildShell()
        gpsSource = gpsPrefs.getString("source", "BOARD") ?: "BOARD"
        locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
        requestBtPermission()
        showPage("DASHBOARD")
        startTelemetryWatchdog()
    }

    private fun startTelemetryWatchdog() {
        mainHandler.post(object : Runnable {
            override fun run() {
                val stale = lastPacketAt == 0L ||
                    System.currentTimeMillis() - lastPacketAt > 1500L
                if (stale && !telemetryTimedOut) {
                    telemetryTimedOut = true
                    synchronized(telemetry) { telemetry.keys.forEach { telemetry[it] = "--" } }
                    if (activePage == "DASHBOARD") updateDashboardValues()
                    if (socket != null) {
                        status.text = "● CONNECTED • NO TELEMETRY"
                        status.setTextColor(Color.YELLOW)
                    }
                }
                mainHandler.postDelayed(this, 300L)
            }
        })
    }

    private fun rounded(color: Int, stroke: Int = Color.TRANSPARENT, radius: Float = 14f): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radius.toInt()).toFloat(); if (stroke != Color.TRANSPARENT) setStroke(dp(1), stroke) }

    private fun styledButton(textValue: String, color: Int = Color.rgb(0, 105, 230), onClick: () -> Unit): Button =
        Button(this).apply {
            text = textValue; textSize = 12f; setTextColor(Color.WHITE); isAllCaps = false
            background = rounded(color, Color.rgb(70, 155, 255), 12f)
            setPadding(dp(8), dp(8), dp(8), dp(8)); setOnClickListener { onClick() }
        }

    private fun sectionTitle(textValue: String): TextView = label(textValue, 18f, white, true).apply {
        setPadding(dp(4), dp(12), dp(4), dp(8)); includeFontPadding = false
    }

    private fun panelBox(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(12), dp(12), dp(12))
        background = rounded(Color.rgb(13, 22, 36), Color.rgb(35, 91, 145), 16f)
    }


    // V3.9 visual system: editorial headings, instrument strips and terminal rows.
    private fun pageHeader(kicker: String, title: String, detail: String, color: Int = cyan): LinearLayout {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(2), dp(7), dp(2), dp(14)) }
        box.addView(label(kicker.uppercase(), 10f, color, true).apply { letterSpacing = .18f })
        box.addView(label(title, 29f, white, true).apply { setPadding(0, dp(3), 0, dp(2)); includeFontPadding = false })
        box.addView(label(detail, 11f, muted, false))
        return box
    }

    private fun slab(color: Int = Color.rgb(13, 19, 29), stroke: Int = Color.rgb(42, 58, 76)): LinearLayout =
        LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(13), dp(12), dp(13), dp(12)); background = rounded(color, stroke, 13f) }

    private fun eyebrow(textValue: String, color: Int = muted): TextView = label(textValue.uppercase(), 9f, color, true).apply { letterSpacing = .12f }

    private fun statLine(name: String, value: String, unit: String = "", color: Int = white): LinearLayout {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(8), 0, dp(8)) }
        row.addView(label(name, 11f, muted, true), LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(label(value, 17f, color, true))
        if (unit.isNotBlank()) row.addView(label("  $unit", 9f, muted, false))
        return row
    }

    private fun accentRule(color: Int = cyan): View = View(this).apply { setBackgroundColor(color); layoutParams = LinearLayout.LayoutParams(-1, dp(2)).apply { topMargin = dp(8); bottomMargin = dp(8) } }

    private fun actionTile(icon: String, title: String, detail: String, color: Int, action: () -> Unit): View {
        val tile = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(12), dp(12), dp(12)); background = rounded(Color.rgb(16, 24, 36), Color.rgb(44, 58, 76), 12f); isClickable = true; isFocusable = true; setOnClickListener { action() } }
        tile.addView(label(icon, 23f, color, true))
        tile.addView(label(title, 12f, white, true).apply { setPadding(0, dp(7), 0, dp(3)) })
        tile.addView(label(detail, 9f, muted, false))
        return tile
    }

    private fun buildShell() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, dp(12), dp(5))
            setBackgroundColor(Color.rgb(5, 9, 15))
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(8), 0, dp(8)) }
        root.setOnApplyWindowInsetsListener { _, insets ->
            header.setPadding(0, insets.systemWindowInsetTop + dp(7), 0, dp(8)); insets
        }
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        brand.addView(label("NATTAWUT", 17f, cyan, true).apply { letterSpacing = .15f })
        brand.addView(label("SMARTGAUGE  /  ECU WORKSTATION", 8f, muted, true))
        header.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        status = label("● OFFLINE", 9f, Color.rgb(255, 90, 95), true).apply { gravity = Gravity.CENTER; setPadding(dp(7), dp(7), dp(7), dp(7)); background = rounded(Color.rgb(30, 18, 23), Color.rgb(110, 42, 48), 20f) }
        header.addView(status)
        root.addView(header)

        val connection = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, 0, 0, dp(8)) }
        connection.addView(label("HONDA WAVE 110i  /  KEIHIN S4", 9f, muted, true), LinearLayout.LayoutParams(0, -2, 1f))
        connectBtn = styledButton("CONNECT  +", Color.rgb(0, 91, 128)) { if (socket == null) showPairedDevices() else disconnect() }
        connectBtn.textSize = 10f
        connection.addView(connectBtn, LinearLayout.LayoutParams(dp(112), dp(38)))
        root.addView(connection)

        val scroll = ScrollView(this).apply { isFillViewport = true; clipToPadding = false }
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(4), 0, dp(16)) }
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val navScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; overScrollMode = View.OVER_SCROLL_NEVER; background = rounded(Color.rgb(12, 18, 27), Color.rgb(36, 48, 64), 16f) }
        navItems = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(3), dp(4), dp(3), dp(4)) }
        val entries = listOf("DASHBOARD" to "⌂", "GRAPH" to "⌁", "DTC" to "⚠", "ECU" to "▤", "MAP" to "⌗", "CONTROL" to "◈", "GPS" to "◎", "IMAGES" to "▧", "BLUETOOTH" to "ᛒ", "LOGGER" to "◉", "SETTINGS" to "⚙")
        entries.forEach { (page, glyph) ->
            val item = LinearLayout(this).apply { tag = page; orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(8), dp(4), dp(8), dp(4)); background = rounded(if (page == activePage) Color.rgb(0, 72, 91) else Color.TRANSPARENT, if (page == activePage) cyan else Color.TRANSPARENT, 10f); isClickable = true; isFocusable = true; setOnClickListener { showPage(page) } }
            item.addView(label(glyph, 19f, if (page == activePage) cyan else muted, true).apply { gravity = Gravity.CENTER })
            val caption = when(page) { "DASHBOARD" -> "HOME"; "BLUETOOTH" -> "BT"; "CONTROL" -> "TOOLS"; "SETTINGS" -> "SET"; else -> page }
            item.addView(label(caption, 7f, if (page == activePage) white else muted, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(2), 0, 0) })
            navItems.addView(item, LinearLayout.LayoutParams(dp(64), dp(54)).apply { setMargins(dp(2), 0, dp(2), 0) })
        }
        navScroll.addView(navItems)
        root.addView(navScroll, LinearLayout.LayoutParams(-1, dp(64)).apply { topMargin = dp(5); bottomMargin = dp(3) })
        setContentView(root)
    }


    private fun label(text: String, size: Float, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            this.text = text; textSize = size; setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun showPage(page: String) {
        activePage = page
        if (::navItems.isInitialized) {
            for (i in 0 until navItems.childCount) {
                val item = navItems.getChildAt(i) as? LinearLayout ?: continue
                val selected = item.tag == page
                item.background = rounded(if (selected) Color.rgb(0, 72, 91) else Color.TRANSPARENT, if (selected) cyan else Color.TRANSPARENT, 10f)
                (item.getChildAt(0) as? TextView)?.setTextColor(if (selected) cyan else muted)
                (item.getChildAt(1) as? TextView)?.setTextColor(if (selected) white else muted)
            }
        }
        body.removeAllViews()
        when (page) {
            "DASHBOARD" -> dashboard()
            "GRAPH" -> graphPage()
            "LOGGER" -> loggerPage()
            "DTC" -> dtcPage()
            "ECU" -> ecuPage()
            "MAP" -> mapPage()
            "CONTROL" -> controlPage()
            "GPS" -> gpsPage()
            "IMAGES" -> imagesPage()
            "BLUETOOTH" -> bluetoothPage()
            "SETTINGS" -> settingsPage()
        }
    }

    // Convert dp to physical pixels. LayoutParams dimensions are pixels, not dp.
    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density + 0.5f).toInt()

    private fun card(key: String): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(8), dp(12), dp(8), dp(5))
            setBackgroundColor(panel)
            minimumHeight = dp(116)
        }

        // Keep the title in its own top row so it cannot collide with the value.
        val title = label(key, 13f, cyan, true).apply {
            gravity = Gravity.CENTER
            includeFontPadding = false
        }
        box.addView(title, LinearLayout.LayoutParams(-1, dp(25)))

        // The value receives the remaining card height and is vertically centered.
        val value = label(telemetry[key] ?: "--", 28f, white, true).apply {
            tag = "value:$key"
            gravity = Gravity.CENTER
            maxLines = 1
            includeFontPadding = false
            isSingleLine = true
        }
        box.addView(value, LinearLayout.LayoutParams(-1, 0, 1f))

        val unit = label(units[key] ?: "", 10f, muted, false).apply {
            gravity = Gravity.CENTER
            includeFontPadding = false
        }
        box.addView(unit, LinearLayout.LayoutParams(-1, dp(17)))
        return box
    }

    private fun rawDataPanel(): LinearLayout {
        val panelBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(10, 9, 10, 9)
            setBackgroundColor(panel)
        }
        panelBox.addView(label("RAW ECU DATA", 13f, cyan, true))
        val raw = label(latestRawFrame, 10f, white, false).apply {
            tag = "latest_raw_data"
            setTextIsSelectable(true)
            maxLines = 5
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        rawDataView = raw
        panelBox.addView(raw, LinearLayout.LayoutParams(-1, -2))
        return panelBox
    }

    private fun dashboard() {
        body.addView(pageHeader("01 / ENGINE MONITOR", "RACE DECK", "Live instrumentation • values are sourced from ECU telemetry"))
        val hero = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; background = rounded(Color.rgb(10, 18, 29), Color.rgb(30, 70, 88), 18f); setPadding(dp(12), dp(12), dp(12), dp(12)) }
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; layoutParams = LinearLayout.LayoutParams(0, -2, 1.35f) }
        left.addView(eyebrow("ENGINE SPEED", cyan).apply { gravity = Gravity.CENTER })
        val gauge = RpmGauge(this).apply { tag = "rpm_gauge" }
        left.addView(gauge, LinearLayout.LayoutParams(-1, dp(178)))
        left.addView(label("RPM  /  LIVE", 9f, muted, true).apply { gravity = Gravity.CENTER })
        val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(8), dp(12), 0, dp(12)) }
        right.addView(eyebrow("ROAD SPEED", Color.rgb(255, 171, 72)))
        right.addView(label(telemetry["SPEED"] ?: "--", 38f, Color.rgb(255, 184, 86), true).apply { tag = "value:SPEED"; gravity = Gravity.CENTER; includeFontPadding = false })
        right.addView(label("km/h", 10f, muted, true).apply { gravity = Gravity.CENTER })
        right.addView(accentRule(Color.rgb(255, 171, 72)))
        right.addView(eyebrow("THROTTLE", muted))
        right.addView(label("${telemetry["TPS"] ?: "--"}%", 22f, white, true).apply { tag = "value:TPS" })
        hero.addView(left, LinearLayout.LayoutParams(0, -2, 1.35f)); hero.addView(right, LinearLayout.LayoutParams(0, -1, 1f)); body.addView(hero)

        body.addView(label("ENGINE TELEMETRY / 12 CHANNELS", 10f, cyan, true).apply { setPadding(dp(3), dp(16), 0, dp(6)); letterSpacing = .1f })
        val keys = listOf("ECT", "IAT", "BAT", "AFR", "O2", "MAP", "INJ", "IGN", "STFT", "LTFT")
        keys.chunked(2).forEachIndexed { index, pair ->
            val strip = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(10), dp(8), dp(10), dp(8)); background = rounded(if (index % 2 == 0) Color.rgb(15, 23, 34) else Color.rgb(10, 16, 25), Color.rgb(32, 44, 59), 8f) }
            pair.forEach { key ->
                val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(4), 0, dp(4), 0) }
                col.addView(eyebrow(key))
                col.addView(label(telemetry[key] ?: "--", 19f, white, true).apply { tag = "value:$key" })
                col.addView(label(units[key] ?: "", 8f, muted, false))
                strip.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
            }
            body.addView(strip, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(4) })
        }
        body.addView(label("SHORTCUTS", 10f, cyan, true).apply { setPadding(dp(3), dp(15), 0, dp(7)) })
        val shortcuts = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(Triple("⌁", "SCOPE", "GRAPH"), Triple("⚠", "FAULTS", "DTC"), Triple("◉", "RECORD", "LOGGER")).forEach { item ->
            shortcuts.addView(actionTile(item.first, item.second, "OPEN MODULE", cyan) { showPage(item.third) }, LinearLayout.LayoutParams(0, dp(100), 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        }
        body.addView(shortcuts)
        body.addView(label("LAST RECEIVED FRAME", 9f, muted, true).apply { setPadding(dp(3), dp(15), 0, dp(6)) })
        body.addView(rawDataPanel())
    }


    private fun graphPage() {
        body.addView(pageHeader("02 / SIGNAL ANALYSIS", "OSCILLOSCOPE", "Live channel trace • no simulated samples"))
        val top = slab(Color.rgb(4, 12, 18), Color.rgb(0, 92, 105))
        top.addView(eyebrow("CHANNEL SELECTOR / LIVE TRACE", cyan))
        val picker = Spinner(this)
        val options = arrayOf("RPM", "TPS", "ECT", "IAT", "BAT", "SPEED", "MAP", "AFR", "O2")
        picker.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, options)
        top.addView(picker, LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(7) })
        graph = LiveGraph(this).apply { metric = selectedMetric; background = rounded(Color.rgb(1, 8, 13), Color.rgb(0, 115, 127), 5f) }
        top.addView(graph, LinearLayout.LayoutParams(-1, dp(255)).apply { topMargin = dp(8) })
        picker.setSelection(options.indexOf(selectedMetric).coerceAtLeast(0))
        picker.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) { selectedMetric = options[position]; graph.metric = selectedMetric; graph.invalidate() }
        }
        body.addView(top)
        val readout = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(9), 0, 0) }
        listOf("CURRENT" to (telemetry[selectedMetric] ?: "--"), "UNIT" to (units[selectedMetric] ?: "--"), "PACKETS" to receivedPackets.toString()).forEach { (k,v) ->
            val cell = slab(Color.rgb(13, 20, 30), Color.rgb(35, 51, 66)); cell.addView(eyebrow(k)); cell.addView(label(v, 17f, cyan, true).apply { tag = if (k == "CURRENT") "graph_current" else null })
            readout.addView(cell, LinearLayout.LayoutParams(0, dp(72), 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        }
        body.addView(readout)
        body.addView(label("Trace updates only when a valid telemetry frame arrives. Select another channel above to inspect its history.", 10f, muted, false).apply { setPadding(dp(4), dp(10), dp(4), 0) })
    }


    private fun loggerPage() {
        body.addView(pageHeader("03 / DATA ACQUISITION", "BLACK BOX", "Capture the Bluetooth stream received from the ESP32" , Color.rgb(255, 170, 75)))
        val count = synchronized(logRows) { logRows.size }
        val counter = slab(Color.rgb(22, 17, 15), Color.rgb(105, 66, 34))
        counter.addView(eyebrow("SESSION BUFFER", Color.rgb(255, 170, 75)))
        counter.addView(label(count.toString().padStart(6, '0'), 42f, Color.rgb(255, 184, 90), true).apply { tag = "logger_count"; typeface = Typeface.MONOSPACE; includeFontPadding = false })
        counter.addView(label(if (logging) "● CAPTURE ACTIVE" else "○ CAPTURE STANDBY", 10f, if (logging) Color.GREEN else muted, true))
        body.addView(counter)
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(10), 0, dp(8)) }
        actions.addView(styledButton(if (logging) "■  STOP" else "●  RECORD", if (logging) Color.rgb(155, 48, 43) else Color.rgb(0, 120, 80)) { logging = !logging; showPage("LOGGER"); toast(if (logging) "เริ่มบันทึกข้อมูลแล้ว" else "หยุดบันทึกแล้ว") }, LinearLayout.LayoutParams(0, dp(54), 1f).apply { setMargins(0, 0, dp(4), 0) })
        actions.addView(styledButton("⇩  EXPORT CSV", Color.rgb(34, 75, 115)) {
            if (logRows.isEmpty()) toast("ยังไม่มีข้อมูล กรุณาเชื่อมต่อและเริ่มบันทึก") else {
                val csv = buildString { append("record_type,time_ms,raw_table,raw_length,raw_hex,"); append(telemetry.keys.joinToString(",")).append('\n'); synchronized(logRows) { logRows.forEach { append(it).append('\n') } } }
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "text/csv"; putExtra(Intent.EXTRA_TITLE, "Nattawut_RAW_ECU_Log.csv") }; pendingCsv = csv; startActivityForResult(intent,77)
            }
        }, LinearLayout.LayoutParams(0, dp(54), 1f).apply { setMargins(dp(4), 0, 0, 0) })
        body.addView(actions)
        body.addView(eyebrow("LATEST FRAME / RAW STREAM"))
        val terminal = slab(Color.rgb(2, 8, 12), Color.rgb(49, 66, 73)); terminal.addView(label("> ECU_STREAM", 10f, Color.GREEN, true).apply { typeface = Typeface.MONOSPACE }); terminal.addView(rawDataPanel())
        body.addView(terminal)
        body.addView(label("CAPTURE SCOPE", 9f, Color.rgb(255, 170, 75), true).apply { setPadding(0, dp(14), 0, dp(5)) })
        body.addView(label("Records are collected from the ESP32 Bluetooth API. This is not a passive K-Line bus recorder.", 10f, muted, false))
    }


    private fun updateLoggerCount() { body.findViewWithTag<TextView>("logger_count")?.text = "${synchronized(logRows) { logRows.size }} RECORDS" }

    private fun infoRow(title: String, value: String): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(8), 0, dp(8)) }
        row.addView(label(title, 12f, muted, false), LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(label(value, 12f, white, true), LinearLayout.LayoutParams(0, -2, 1f)); return row
    }

    private fun dtcPage() {
        body.addView(pageHeader("04 / FAULT INVESTIGATION", "DIAGNOSTIC BAY", "Honda PGM-FI • Keihin S4 • stored/current DTC", Color.rgb(255, 90, 90)))
        val alert = slab(Color.rgb(26, 12, 17), Color.rgb(122, 42, 54))
        alert.addView(eyebrow("SCAN STATUS", Color.rgb(255, 100, 110)))
        dtcStatusView = label(dtcScanStatus.uppercase(), 17f, Color.YELLOW, true).apply { setPadding(0, dp(6), 0, dp(3)) }
        alert.addView(dtcStatusView)
        alert.addView(label("KEIHIN / S4 / K-LINE", 9f, muted, true))
        body.addView(alert)
        body.addView(label("FAULT REGISTER", 10f, Color.rgb(255, 100, 110), true).apply { setPadding(dp(2), dp(16), 0, dp(6)) })
        val terminal = slab(Color.rgb(7, 12, 19), Color.rgb(67, 46, 57))
        terminal.addView(label("INDEX     CODE / DESCRIPTION", 9f, muted, true).apply { typeface = Typeface.MONOSPACE })
        terminal.addView(accentRule(Color.rgb(160, 55, 67)))
        dtcResultsView = label(dtcDisplayText(), 12f, white, false).apply { setPadding(0, dp(7), 0, dp(7)); typeface = Typeface.MONOSPACE; setTextIsSelectable(true) }
        terminal.addView(dtcResultsView)
        body.addView(terminal)
        body.addView(styledButton("⌕   SCAN ECU FAULT MEMORY", Color.rgb(0, 94, 130)) {
            if (socket == null) toast("กรุณาเชื่อมต่อ Bluetooth กับบอร์ดก่อน") else { dtcScanStatus = "กำลังอ่านข้อมูลจาก ECU..."; refreshDtcViews(); sendBtCommand("DTC_READ") }
        }, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(12) })
        body.addView(styledButton("×   CLEAR DTC MEMORY", Color.rgb(130, 37, 48)) {
            if (socket == null) toast("กรุณาเชื่อมต่อ Bluetooth กับบอร์ดก่อน") else AlertDialog.Builder(this).setTitle("ยืนยันการลบรหัส DTC").setMessage("ส่งคำสั่งลบ DTC Memory 01 ไปยัง ECU Honda Keihin S4 หรือไม่? หลังลบจะอ่านรหัสซ้ำเพื่อยืนยันผล").setNegativeButton("ยกเลิก", null).setPositiveButton("ยืนยันลบ") { _, _ -> dtcScanStatus = "กำลังลบรหัสและตรวจสอบซ้ำ..."; refreshDtcViews(); sendBtCommand("DTC_CLEAR") }.show()
        }, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(7) })
        body.addView(label("Clear is an ECU command. Use only after recording the fault list.", 9f, muted, false).apply { setPadding(0, dp(9), 0, 0) })
    }


    private fun dtcDisplayText(): String = synchronized(dtcItems) {
        if (dtcItems.isEmpty()) "ยังไม่มีรายการรหัส DTC จาก ECU" else dtcItems.mapIndexed { i, item -> "${i + 1}. $item" }.joinToString("\n")
    }

    private fun refreshDtcViews() {
        runOnUiThread {
            dtcStatusView?.text = "สถานะ: $dtcScanStatus"
            dtcResultsView?.text = dtcDisplayText()
            dtcStatusView?.setTextColor(if (dtcScanStatus.contains("NO FAULT", true) || dtcScanStatus.contains("VERIFIED", true)) Color.GREEN else Color.YELLOW)
        }
    }

    private fun ecuPage() {
        body.addView(pageHeader("05 / ECU STORAGE", "FILE VAULT", "Transfer BIN files between Android and ESP32 storage", Color.rgb(177, 135, 255)))
        val identity = slab(Color.rgb(18, 14, 29), Color.rgb(83, 58, 126))
        identity.addView(eyebrow("TARGET ECU", Color.rgb(185, 145, 255)))
        identity.addView(label("HONDA WAVE 110i", 18f, white, true))
        identity.addView(label("2009  /  KEIHIN S4  /  K-LINE", 9f, muted, true))
        identity.addView(accentRule(Color.rgb(125, 85, 185)))
        identity.addView(statLine("Bluetooth link", if (socket != null) "CONNECTED" else "OFFLINE", "", if (socket != null) Color.GREEN else Color.RED))
        identity.addView(statLine("Telemetry packets", receivedPackets.toString()))
        identity.addView(statLine("ECU write / flash", "NOT ENABLED", "", Color.YELLOW))
        body.addView(identity)
        body.addView(label("TRANSFER OPERATIONS", 10f, Color.rgb(185, 145, 255), true).apply { setPadding(dp(2), dp(16), 0, dp(7)) })
        val selected = slab(Color.rgb(11, 17, 26), Color.rgb(53, 64, 83))
        selected.addView(eyebrow("PHONE SOURCE FILE"))
        selected.addView(label(selectedBinUri?.let { displayName(it) } ?: "NO BIN SELECTED", 13f, cyan, true).apply { setPadding(0, dp(5), 0, dp(5)) })
        binTransferStatusView = label("READY • waiting for operation", 10f, muted, false)
        selected.addView(binTransferStatusView)
        body.addView(selected)
        body.addView(styledButton("01  /  CHOOSE BIN FROM PHONE", Color.rgb(65, 47, 102)) {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"; addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION) }; startActivityForResult(intent, 80)
        }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(8) })
        body.addView(styledButton("02  /  SEND BIN TO ESP32", Color.rgb(0, 105, 75)) { uploadSelectedBin() }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(7) })
        val pair = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        pair.addView(styledButton("LIST FILES", Color.rgb(42, 67, 100)) { refreshBoardBinList() }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { setMargins(0, dp(7), dp(4), 0) })
        pair.addView(styledButton("DOWNLOAD", Color.rgb(76, 55, 111)) { refreshBoardBinList(chooseForDownload = true) }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { setMargins(dp(4), dp(7), 0, 0) })
        body.addView(pair)
        body.addView(label("BIN storage transfer is available through the existing ESP32 API. This does not read or flash the ECU ROM.", 9f, muted, false).apply { setPadding(dp(2), dp(10), dp(2), 0) })
    }


    private fun refreshBoardBinList(chooseForDownload: Boolean = false) {
        val active = socket ?: run { toast("กรุณาเชื่อมต่อ Bluetooth กับ ESP32 ก่อน"); return }
        if (binTransferBusy || imageTransferBusy) { toast("มีการถ่ายโอนไฟล์อื่นกำลังทำงาน"); return }
        binTransferBusy = true
        thread {
            try {
                binResponses.clear()
                writeBinCommand(active, "NATTWUT_BIN,LIST")
                val files = mutableListOf<Pair<String, Long>>()
                val deadline = System.currentTimeMillis() + 15000L
                var ended = false
                while (System.currentTimeMillis() < deadline) {
                    val line = nextBinResponse(15L)
                    val p = line.split(',')
                    when (p.getOrNull(1)) {
                        "ITEM" -> if (p.size >= 4) {
                            val name = p[2]
                            val size = p[3].toLongOrNull() ?: 0L
                            if (name.endsWith(".bin", true) && size > 0) files.add(name to size)
                        }
                        "LIST_END" -> { ended = true; break }
                        "GET_ERROR" -> throw IllegalStateException(line)
                    }
                }
                if (!ended) throw IllegalStateException("หมดเวลารอรายการไฟล์ BIN")
                runOnUiThread {
                    binTransferBusy = false
                    if (files.isEmpty()) {
                        binTransferStatusView?.text = "ไม่พบไฟล์ BIN ใน LittleFS ของบอร์ด"
                        toast("ไม่พบไฟล์ BIN บน ESP32")
                    } else {
                        binTransferStatusView?.text = "พบไฟล์ BIN ${files.size} ไฟล์บน ESP32"
                        if (chooseForDownload) showBinDownloadChooser(files)
                        else showBinFileList(files)
                    }
                }
            } catch (e: Exception) {
                binTransferBusy = false
                updateBinProgress("อ่านรายการ BIN ไม่สำเร็จ: ${e.message}")
            }
        }
    }

    private fun showBinFileList(files: List<Pair<String, Long>>) {
        val rows = files.map { "${it.first}  •  ${it.second} bytes" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("BIN FILES ON ESP32").setItems(rows, null)
            .setPositiveButton("ปิด", null).show()
    }

    private fun showBinDownloadChooser(files: List<Pair<String, Long>>) {
        val rows = files.map { "${it.first}  •  ${it.second / 1024} KB" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("เลือกไฟล์ BIN ที่ต้องการดาวน์โหลด")
            .setItems(rows) { _, which -> downloadBinFromBoard(files[which].first, files[which].second) }
            .setNegativeButton("ยกเลิก", null).show()
    }

    private fun downloadBinFromBoard(name: String, expectedSize: Long) {
        val active = socket ?: run { toast("Bluetooth หลุดการเชื่อมต่อ"); return }
        if (binTransferBusy || imageTransferBusy) { toast("มีการถ่ายโอนไฟล์อื่นกำลังทำงาน"); return }
        if (expectedSize <= 0 || expectedSize > 512L * 1024L) { toast("ขนาดไฟล์ไม่ถูกต้องหรือเกิน 512 KB"); return }
        binTransferBusy = true
        thread {
            try {
                binResponses.clear()
                writeBinCommand(active, "NATTWUT_BIN,GET,$name")
                val begin = nextBinResponse(20L).split(',')
                if (begin.size < 4 || begin[1] != "GET_BEGIN" || begin[2] != name) throw IllegalStateException("หัวข้อมูลดาวน์โหลดไม่ถูกต้อง")
                val total = begin[3].toLongOrNull() ?: throw IllegalStateException("ขนาดไฟล์ไม่ถูกต้อง")
                if (total != expectedSize || total > 512L * 1024L) throw IllegalStateException("ขนาดไฟล์เปลี่ยนแปลงหรือเกินกำหนด")
                val out = java.io.ByteArrayOutputStream(total.toInt())
                var expectedOffset = 0L
                var finalCrc: Long? = null
                while (true) {
                    val line = nextBinResponse(30L)
                    val p = line.split(',')
                    when (p.getOrNull(1)) {
                        "GET_DATA" -> {
                            if (p.size < 4) throw IllegalStateException("ข้อมูล BIN ไม่ครบ")
                            val offset = p[2].toLongOrNull() ?: -1L
                            if (offset != expectedOffset) throw IllegalStateException("ตำแหน่งข้อมูลไม่ต่อเนื่อง")
                            val chunk = Base64.decode(p[3], Base64.DEFAULT)
                            if (chunk.isEmpty() || expectedOffset + chunk.size > total) throw IllegalStateException("ขนาดข้อมูลผิดปกติ")
                            out.write(chunk)
                            expectedOffset += chunk.size
                            updateBinProgress("กำลังรับ BIN จาก ESP32: ${expectedOffset * 100 / total}%")
                        }
                        "GET_DONE" -> {
                            if (p.size < 5 || p[2] != name) throw IllegalStateException("ข้อมูลปิดท้ายไม่ถูกต้อง")
                            val doneSize = p[3].toLongOrNull() ?: -1L
                            finalCrc = p[4].toLongOrNull(16) ?: -1L
                            if (doneSize != total || expectedOffset != total) throw IllegalStateException("จำนวนไบต์ไม่ครบ")
                            break
                        }
                        "GET_ERROR" -> throw IllegalStateException(line)
                    }
                }
                val bytes = out.toByteArray()
                val actualCrc = CRC32().apply { update(bytes) }.value
                if (finalCrc == null || finalCrc != actualCrc) throw IllegalStateException("CRC32 ไม่ตรงกัน ไฟล์อาจเสียหาย")
                runOnUiThread {
                    pendingBinDownload = bytes
                    pendingBinDownloadName = name
                    binTransferBusy = false
                    val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "application/octet-stream"
                        putExtra(Intent.EXTRA_TITLE, name)
                    }
                    startActivityForResult(intent, 81)
                    binTransferStatusView?.text = "รับไฟล์ครบแล้ว ตรวจสอบ CRC32 ผ่าน • เลือกตำแหน่งบันทึกในโทรศัพท์"
                }
            } catch (e: Exception) {
                binTransferBusy = false
                updateBinProgress("ดาวน์โหลด BIN ไม่สำเร็จ: ${e.message}")
            }
        }
    }

    private fun displayName(uri: Uri): String {
        var name = uri.lastPathSegment ?: "firmware.bin"
        try { contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) name = c.getString(0) ?: name } } catch (_: Exception) { }
        return name
    }

    private fun nextBinResponse(timeoutSeconds: Long = 15L): String {
        val line = binResponses.poll(timeoutSeconds, TimeUnit.SECONDS)
            ?: throw IllegalStateException("บอร์ดไม่ตอบกลับภายใน ${timeoutSeconds} วินาที")
        if (line.startsWith("NATTWUT_BIN,PUT_ERROR,")) throw IllegalStateException(line.substringAfterLast(','))
        return line
    }

    private fun writeBinCommand(active: BluetoothSocket, command: String) {
        synchronized(active) {
            active.outputStream.write((command + "\n").toByteArray(Charsets.UTF_8))
            active.outputStream.flush()
        }
    }

    private fun uploadSelectedBin() {
        val active = socket ?: run { toast("กรุณาเชื่อมต่อ Bluetooth กับ ESP32 ก่อน"); return }
        val uri = selectedBinUri ?: run { toast("กรุณาเลือกไฟล์ BIN ก่อน"); return }
        if (binTransferBusy || imageTransferBusy) { toast("มีการถ่ายโอนไฟล์อื่นกำลังทำงาน"); return }
        binTransferBusy = true
        thread {
            var started = false
            try {
                val bytes = contentResolver.openInputStream(uri)?.use { input ->
                    val out = java.io.ByteArrayOutputStream()
                    val buffer = ByteArray(8192)
                    while (true) {
                        val n = input.read(buffer); if (n < 0) break
                        out.write(buffer, 0, n)
                        if (out.size() > 512 * 1024) throw IllegalArgumentException("ไฟล์เกินขนาดสูงสุด 512 KB")
                    }
                    out.toByteArray()
                } ?: throw IllegalStateException("อ่านไฟล์จากโทรศัพท์ไม่ได้")
                if (bytes.isEmpty()) throw IllegalArgumentException("ไฟล์ว่าง")
                val original = displayName(uri).substringAfterLast('/')
                if (!original.lowercase().endsWith(".bin")) throw IllegalArgumentException("กรุณาเลือกไฟล์นามสกุล .bin เท่านั้น")
                var safeName = original.replace(Regex("[^A-Za-z0-9_.-]"), "_").trim('.', '_', '-')
                if (safeName.isBlank()) safeName = "ECU_FIRMWARE.bin"
                if (!safeName.lowercase().endsWith(".bin")) safeName += ".bin"
                if (safeName.length > 39) safeName = safeName.take(35) + ".bin"
                val crc = CRC32().apply { update(bytes) }.value
                val crcText = String.format(java.util.Locale.US, "%08X", crc)
                binResponses.clear()
                updateBinProgress("กำลังเริ่มส่ง ${safeName} • ${bytes.size} bytes (${bytes.size / 1024.0} KB)")
                started = true
                writeBinCommand(active, "NATTWUT_BIN,PUT_BEGIN,$safeName,${bytes.size},$crcText")
                val ready = nextBinResponse(20L)
                if (!ready.startsWith("NATTWUT_BIN,PUT_READY,")) throw IllegalStateException("ตอบกลับไม่ถูกต้อง: $ready")
                val chunkSize = 72 // Base64 line remains below the ESP32 160-byte command buffer.
                var offset = 0
                while (offset < bytes.size) {
                    val length = minOf(chunkSize, bytes.size - offset)
                    val chunk = bytes.copyOfRange(offset, offset + length)
                    val encoded = Base64.encodeToString(chunk, Base64.NO_WRAP)
                    binResponses.clear()
                    writeBinCommand(active, "NATTWUT_BIN,PUT_DATA,$offset,$encoded")
                    val ack = nextBinResponse(20L)
                    val acknowledged = ack.substringAfterLast(',').toLongOrNull()
                    val expected = offset + length
                    if (!ack.startsWith("NATTWUT_BIN,PUT_ACK,") || acknowledged != expected.toLong()) {
                        throw IllegalStateException("ยืนยันข้อมูลไม่ตรงกัน: $ack")
                    }
                    offset = expected
                    val percent = offset * 100 / bytes.size
                    updateBinProgress("กำลังส่ง BIN: $percent% • ${offset / 1024} / ${bytes.size / 1024} KB")
                }
                binResponses.clear()
                writeBinCommand(active, "NATTWUT_BIN,PUT_END,$crcText")
                val done = nextBinResponse(30L)
                if (!done.startsWith("NATTWUT_BIN,PUT_DONE,$safeName,")) throw IllegalStateException("บันทึกไฟล์ไม่สำเร็จ: $done")
                updateBinProgress("บันทึกลงบอร์ดสำเร็จ: $safeName • ${bytes.size / 1024.0} KB • CRC32 $crcText")
            } catch (e: Exception) {
                if (started) try { writeBinCommand(active, "NATTWUT_BIN,PUT_ABORT") } catch (_: Exception) { }
                updateBinProgress("ส่ง BIN ไม่สำเร็จ: ${e.message}")
            } finally { binTransferBusy = false }
        }
    }

    private fun updateBinProgress(message: String) {
        runOnUiThread { binTransferStatusView?.text = message }
    }

    private fun mapPage() {
        body.addView(pageHeader("06 / CALIBRATION WORKSPACE", "MAP BENCH", "Inspect and stage calibration files • ECU write remains locked", Color.rgb(92, 202, 160)))
        val work = slab(Color.rgb(8, 22, 22), Color.rgb(39, 105, 87))
        work.addView(eyebrow("MAP FILE WORKSPACE", Color.rgb(92, 202, 160)))
        work.addView(label("CALIBRATION DATA", 21f, white, true).apply { setPadding(0, dp(5), 0, dp(2)) })
        work.addView(label("Select a .MAP file from device storage for local staging and inspection.", 10f, muted, false))
        work.addView(accentRule(Color.rgb(50, 151, 118)))
        work.addView(statLine("Selected file", "NOT SELECTED"))
        work.addView(statLine("File transfer API", "NOT AVAILABLE", "", Color.YELLOW))
        body.addView(work)
        val grid = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(10), 0, dp(6)) }
        grid.addView(actionTile("▤", "OPEN MAP", "DEVICE STORAGE", Color.rgb(92, 202, 160)) {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }; startActivityForResult(i, 78)
        }, LinearLayout.LayoutParams(0, dp(116), 1f).apply { setMargins(0, 0, dp(4), 0) })
        grid.addView(actionTile("⌗", "COMPARE", "NOT IMPLEMENTED", muted) { toast("เครื่องมือเปรียบเทียบ MAP จะเปิดใช้เมื่อมี parser ที่รองรับรูปแบบไฟล์") }, LinearLayout.LayoutParams(0, dp(116), 1f).apply { setMargins(dp(4), 0, 0, 0) })
        body.addView(grid)
        body.addView(label("PROTECTION / ECU MAP WRITE & FLASH DISABLED", 9f, Color.YELLOW, true).apply { setPadding(0, dp(12), 0, dp(3)) })
        body.addView(label("ไม่ส่งคำสั่งเขียน MAP ไปยัง ECU หรือ SD เพราะเฟิร์มแวร์ปัจจุบันยังไม่มี API ที่ตรวจสอบยืนยันแล้ว", 10f, muted, false))
    }


    private fun controlPage() {
        body.addView(pageHeader("07 / WORKSHOP LAUNCHER", "TOOL MATRIX", "Jump directly into diagnostic and data modules", Color.rgb(255, 191, 77)))
        val matrix = listOf(
            Triple("⌁", "LIVE SCOPE", "GRAPH"), Triple("⚠", "FAULT SCAN", "DTC"),
            Triple("▤", "ECU FILE VAULT", "ECU"), Triple("◉", "BLACK BOX", "LOGGER"),
            Triple("◎", "GPS TRACK", "GPS"), Triple("ᛒ", "LINK STATION", "BLUETOOTH"),
            Triple("▧", "FLASH GALLERY", "IMAGES"), Triple("⚙", "SYSTEM SETUP", "SETTINGS")
        )
        matrix.chunked(2).forEach { pair ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            pair.forEach { item -> row.addView(actionTile(item.first, item.second, "OPEN WORKSPACE", Color.rgb(255, 191, 77)) { showPage(item.third) }, LinearLayout.LayoutParams(0, dp(116), 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3) ) }) }
            body.addView(row)
        }
        body.addView(label("LOCAL APP CONTROL ONLY", 9f, Color.YELLOW, true).apply { setPadding(dp(3), dp(13), 0, dp(4)) })
        body.addView(label("This launcher opens modules. It does not issue undocumented commands to the ECU or hardware.", 10f, muted, false))
    }


    private fun gpsPage() {
        body.addView(pageHeader("08 / POSITION & MOTION", "TRACK MODE", "Speed source and location telemetry", Color.rgb(255, 185, 76)))
        val speedPanel = slab(Color.rgb(22, 17, 10), Color.rgb(117, 79, 34))
        speedPanel.gravity = Gravity.CENTER_HORIZONTAL
        speedPanel.addView(eyebrow("LIVE GROUND SPEED", Color.rgb(255, 185, 76)).apply { gravity = Gravity.CENTER })
        gpsSpeedView = label("${if (gpsSource == "PHONE") phoneGpsSpeed?.toString() ?: "--" else telemetry["SPEED"] ?: "--"}", 64f, Color.rgb(255, 193, 92), true).apply { gravity = Gravity.CENTER; includeFontPadding = false }
        speedPanel.addView(gpsSpeedView)
        speedPanel.addView(label("KILOMETRES PER HOUR", 9f, muted, true).apply { gravity = Gravity.CENTER })
        speedPanel.addView(accentRule(Color.rgb(183, 115, 38)))
        gpsSourceView = label("SOURCE / ${if (gpsSource == "PHONE") "ANDROID PHONE" else "BOARD GPS MODULE"}", 10f, cyan, true).apply { gravity = Gravity.CENTER }
        speedPanel.addView(gpsSourceView)
        gpsPositionView = label("POSITION  /  --", 10f, white, false).apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, 0) }
        speedPanel.addView(gpsPositionView)
        body.addView(speedPanel)
        body.addView(label("SELECT NAVIGATION SOURCE", 10f, Color.rgb(255, 185, 76), true).apply { setPadding(dp(2), dp(15), 0, dp(6)) })
        val sources = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        sources.addView(styledButton(if (gpsSource == "BOARD") "✓ BOARD UART" else "BOARD UART", Color.rgb(54, 78, 103)) { selectGpsSource("BOARD") }, LinearLayout.LayoutParams(0, dp(52), 1f).apply { setMargins(0, 0, dp(4), 0) })
        sources.addView(styledButton(if (gpsSource == "PHONE") "✓ PHONE GPS" else "PHONE GPS", Color.rgb(112, 76, 30)) { selectGpsSource("PHONE") }, LinearLayout.LayoutParams(0, dp(52), 1f).apply { setMargins(dp(4), 0, 0, 0) })
        body.addView(sources)
        body.addView(label("Board mode reads the GPS module through the existing UART firmware. Phone mode uses Android location and forwards speed over the current Bluetooth link.", 10f, muted, false).apply { setPadding(dp(3), dp(10), dp(3), 0) })
        updateGpsPageValues()
    }


    private fun selectGpsSource(source: String) {
        gpsSource = source
        gpsPrefs.edit().putString("source", source).apply()
        if (source == "BOARD") {
            stopPhoneLocation()
            sendBtCommand("GPS_SOURCE,BOARD")
            toast("เลือก GPS Module บนบอร์ดแล้ว")
            showPage("GPS")
        } else {
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 42)
                return
            }
            sendBtCommand("GPS_SOURCE,PHONE")
            startPhoneLocation()
            toast("เลือก GPS โทรศัพท์แล้ว")
            showPage("GPS")
        }
    }

    private fun startPhoneLocation() {
        if (gpsSource != "PHONE") return
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return
        try {
            val manager = locationManager ?: return
            if (!manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                toast("กรุณาเปิด Location/GPS ของโทรศัพท์")
                return
            }
            manager.removeUpdates(phoneLocationListener)
            manager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, phoneLocationListener, Looper.getMainLooper())
            manager.getLastKnownLocation(LocationManager.GPS_PROVIDER)?.let { phoneLocationListener.onLocationChanged(it) }
        } catch (e: SecurityException) {
            toast("ยังไม่ได้รับสิทธิ์ Location")
        } catch (e: Exception) {
            toast("เริ่ม GPS โทรศัพท์ไม่สำเร็จ: ${e.message}")
        }
    }

    private fun stopPhoneLocation() {
        try { locationManager?.removeUpdates(phoneLocationListener) } catch (_: Exception) { }
    }

    private fun updateGpsPageValues() {
        runOnUiThread {
            gpsSourceView?.text = "แหล่ง GPS: ${if (gpsSource == "PHONE") "โทรศัพท์ Android" else "GPS Module บนบอร์ด"}"
            val speed = if (gpsSource == "PHONE") phoneGpsSpeed?.toString() ?: "--" else telemetry["SPEED"] ?: "--"
            gpsSpeedView?.text = "$speed km/h"
            gpsPositionView?.text = if (phoneLatitude != null && phoneLongitude != null)
                "ตำแหน่งโทรศัพท์: %.5f, %.5f".format(phoneLatitude, phoneLongitude) else "ตำแหน่งโทรศัพท์: --"
        }
    }

    private fun sendBtCommand(command: String) {
        val activeSocket = socket ?: return
        try {
            synchronized(activeSocket) {
                activeSocket.outputStream.write((command + "\n").toByteArray(Charsets.UTF_8))
                activeSocket.outputStream.flush()
            }
        } catch (e: Exception) {
            runOnUiThread { toast("ส่งคำสั่ง Bluetooth ไม่สำเร็จ: ${e.message}") }
        }
    }

    private fun bluetoothPage() {
        body.addView(pageHeader("09 / WIRELESS TRANSPORT", "LINK STATION", "Bluetooth Classic SPP / RFCOMM", Color.rgb(75, 190, 255)))
        val station = slab(Color.rgb(6, 18, 29), Color.rgb(30, 104, 145))
        station.gravity = Gravity.CENTER_HORIZONTAL
        station.addView(label("ᛒ", 54f, Color.rgb(75, 190, 255), true).apply { gravity = Gravity.CENTER })
        station.addView(label("NATTAWUT ECU", 20f, white, true).apply { gravity = Gravity.CENTER })
        station.addView(label(if (socket != null) "● LINK ESTABLISHED" else "○ NO ACTIVE LINK", 12f, if (socket != null) Color.GREEN else Color.RED, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, dp(5)) })
        station.addView(accentRule(Color.rgb(30, 104, 145)))
        station.addView(statLine("Transport", "CLASSIC SPP"))
        station.addView(statLine("Received packets", receivedPackets.toString()))
        station.addView(statLine("Telemetry age", if (lastPacketAt == 0L) "NO DATA" else "${(System.currentTimeMillis() - lastPacketAt).coerceAtLeast(0)} ms"))
        body.addView(station)
        body.addView(styledButton(if (socket == null) "＋  CONNECT PAIRED DEVICE" else "×  DISCONNECT DEVICE", if (socket == null) Color.rgb(0, 100, 150) else Color.rgb(130, 42, 50)) { if (socket == null) showPairedDevices() else disconnect() }, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(12) })
        body.addView(styledButton("↻  REQUEST LINK STATUS", Color.rgb(38, 65, 91)) { sendBtCommand("STATUS") }, LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(7) })
        body.addView(label("Pair the device named Nattawut ECU in Android Bluetooth settings before connecting.", 10f, muted, false).apply { setPadding(dp(3), dp(10), dp(3), 0) })
    }


    private fun imagesPage() {
        body.addView(pageHeader("10 / DISPLAY ASSET STORAGE", "FLASH GALLERY", "Preview, upload, select and remove images stored on ESP32", Color.rgb(104, 220, 190)))
        val intro = panelBox()
        intro.addView(label("เลือกภาพหลายภาพจากโทรศัพท์ แล้วส่งเก็บใน Flash ภายใน ESP32-CYD", 13f, white, true))
        intro.addView(label("ภาพจะถูกปรับเป็น 320×240 RGB565 ก่อนส่งผ่าน Bluetooth Classic SPP • ไม่ต้องใช้ microSD", 11f, muted, false).apply {
            setPadding(0, dp(7), 0, dp(4))
        })
        imagePreviewView = ImageView(this).apply {
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.BLACK)
            minimumHeight = dp(150)
            maxHeight = dp(190)
        }
        intro.addView(imagePreviewView, LinearLayout.LayoutParams(-1, dp(170)))
        imageSelectionView = label(if (selectedImageUris.isEmpty()) "ยังไม่ได้เลือกภาพ" else "เลือกแล้ว ${selectedImageUris.size} ภาพ", 12f, cyan, false).apply {
            setPadding(0, dp(8), 0, dp(4))
        }
        intro.addView(imageSelectionView)
        selectedImageUris.firstOrNull()?.let { uri ->
            try { imagePreviewView?.setImageBitmap(createScreenPreview(uri)) } catch (_: Exception) { }
        }
        body.addView(intro)

        val galleryActions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        galleryActions.addView(styledButton("＋  SELECT", Color.rgb(0, 105, 190)) {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "image/*"
                putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            }
            startActivityForResult(intent, 79)
        }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { topMargin = dp(8); setMargins(0, 0, dp(4), 0) })

        galleryActions.addView(styledButton("↑  UPLOAD", Color.rgb(0, 125, 75)) {
            uploadSelectedImages()
        }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { topMargin = dp(8); setMargins(dp(4), 0, 0, 0) })
        body.addView(galleryActions)

        imageProgressView = label("รอการส่งภาพ", 11f, muted, false).apply { setPadding(dp(4), dp(8), dp(4), dp(8)) }
        body.addView(imageProgressView)
        imageStorageView = label("ยังไม่ได้อ่านสถานะ Flash", 11f, cyan, false).apply { setPadding(dp(4), dp(2), dp(4), dp(8)) }
        body.addView(imageStorageView)
        body.addView(styledButton("REFRESH ESP32 IMAGE LIST", Color.rgb(38, 66, 95)) {
            refreshImageList()
        }, LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(4) })
        body.addView(styledButton("INITIALIZE EMPTY FLASH STORAGE", Color.rgb(105, 75, 25)) {
            AlertDialog.Builder(this)
                .setTitle("Initialize LittleFS storage?")
                .setMessage("ใช้เฉพาะเมื่อบอร์ดแจ้งว่า Flash storage ยังไม่พร้อม การทำรายการนี้จะ format เฉพาะ partition LittleFS และลบไฟล์ทั้งหมดใน partition นั้น หากมีข้อมูลเดิมอยู่")
                .setNegativeButton("ยกเลิก", null)
                .setPositiveButton("ยืนยันเริ่มต้น") { _, _ -> initializeImageStorage() }
                .show()
        }, LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(6) })
        body.addView(sectionTitle("IMAGES STORED ON ESP32"))
        imageListContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        body.addView(imageListContainer)
        renderBoardImages()
        refreshImageList()
    }

    private fun updateImageProgress(message: String) {
        runOnUiThread { imageProgressView?.text = message }
    }

    private fun writeImageCommand(active: BluetoothSocket, command: String) {
        synchronized(active) {
            active.outputStream.write((command + "\n").toByteArray(Charsets.UTF_8))
            active.outputStream.flush()
        }
    }

    private fun nextImageResponse(timeoutSeconds: Long = 10L): String {
        val response = imageResponses.poll(timeoutSeconds, TimeUnit.SECONDS)
            ?: throw IllegalStateException("ESP32 ไม่ตอบกลับภายใน ${timeoutSeconds} วินาที")
        if (response.startsWith("NATTWUT_IMG,ERR,")) {
            throw IllegalStateException(response.substringAfterLast(','))
        }
        return response
    }

    private fun fetchBoardImages(active: BluetoothSocket): Pair<List<BoardImage>, String> {
        imageResponses.clear()
        writeImageCommand(active, "IMG_LIST")
        val found = mutableListOf<BoardImage>()
        var storage = ""
        val deadline = System.currentTimeMillis() + 15000L
        while (System.currentTimeMillis() < deadline) {
            val remaining = ((deadline - System.currentTimeMillis()) / 1000L).coerceAtLeast(1L)
            val line = nextImageResponse(remaining)
            val fields = line.split(',')
            when (fields.getOrNull(1)) {
                "ITEM" -> {
                    val slot = fields.getOrNull(2)?.toIntOrNull() ?: continue
                    val bytes = fields.getOrNull(3)?.toLongOrNull() ?: 0L
                    val selected = fields.getOrNull(4) == "1"
                    found.add(BoardImage(slot, bytes, selected))
                }
                "LIST_END" -> {
                    val total = fields.getOrNull(2)?.toLongOrNull() ?: 0L
                    val used = fields.getOrNull(3)?.toLongOrNull() ?: 0L
                    val free = fields.getOrNull(4)?.toLongOrNull() ?: 0L
                    storage = "LittleFS: ใช้ ${(used / 1024)} KB / ${(total / 1024)} KB • ว่าง ${(free / 1024)} KB • รองรับสูงสุด 8 ช่อง"
                    return Pair(found.sortedBy { it.slot }, storage)
                }
            }
        }
        throw IllegalStateException("ไม่ได้รับรายการภาพจาก ESP32")
    }

    private fun refreshImageList() {
        val active = socket
        if (active == null) {
            imageStorageView?.text = "กรุณาเชื่อมต่อ Bluetooth กับ Nattawut ECU ก่อน"
            return
        }
        if (imageTransferBusy || binTransferBusy) return
        imageTransferBusy = true
        updateImageProgress("กำลังอ่านรายการภาพจากบอร์ด…")
        thread {
            try {
                val result = fetchBoardImages(active)
                runOnUiThread {
                    boardImages.clear()
                    boardImages.addAll(result.first)
                    imageStorageView?.text = result.second
                    renderBoardImages()
                    imageProgressView?.text = "อ่านรายการภาพสำเร็จ • ${boardImages.size} ภาพ"
                }
            } catch (e: Exception) {
                updateImageProgress("อ่านรายการภาพไม่สำเร็จ: ${e.message}")
            } finally {
                imageTransferBusy = false
            }
        }
    }

    private fun initializeImageStorage() {
        val active = socket ?: run { toast("กรุณาเชื่อมต่อ Bluetooth ก่อน"); return }
        if (imageTransferBusy || binTransferBusy) return
        imageTransferBusy = true
        updateImageProgress("กำลังเริ่มต้น LittleFS…")
        thread {
            try {
                imageResponses.clear()
                writeImageCommand(active, "IMG_FORMAT_CONFIRM")
                val response = nextImageResponse(20L)
                if (!response.startsWith("NATTWUT_IMG,FORMAT,OK,")) throw IllegalStateException(response)
                val result = fetchBoardImages(active)
                runOnUiThread {
                    boardImages.clear(); boardImages.addAll(result.first)
                    imageStorageView?.text = result.second
                    renderBoardImages()
                    imageProgressView?.text = "เริ่มต้น Flash storage สำเร็จ"
                }
            } catch (e: Exception) {
                updateImageProgress("เริ่มต้น Flash storage ไม่สำเร็จ: ${e.message}")
            } finally {
                imageTransferBusy = false
            }
        }
    }

    private fun renderBoardImages() {
        val container = imageListContainer ?: return
        container.removeAllViews()
        if (boardImages.isEmpty()) {
            container.addView(label("ยังไม่มีภาพใน Flash หรือยังไม่ได้เชื่อมต่อบอร์ด", 12f, muted, false).apply {
                setPadding(dp(8), dp(8), dp(8), dp(12))
            })
            return
        }
        boardImages.forEach { item ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(10), dp(8), dp(10), dp(8))
                background = rounded(Color.rgb(20, 29, 44), Color.rgb(45, 75, 110), 12f)
            }
            row.addView(label("ช่อง ${item.slot + 1} • ${item.bytes / 1024} KB${if (item.selected) " • โลโก้เปิดเครื่อง + พื้นหลังปัจจุบัน" else ""}",
                12f, if (item.selected) Color.GREEN else white, true))
            val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            actions.addView(styledButton(if (item.selected) "BOOT + BACKGROUND" else "USE AT BOOT + BG", Color.rgb(0, 105, 160)) {
                performImageAction("IMG_SELECT,${item.slot}", "SELECT")
            }, LinearLayout.LayoutParams(0, dp(42), 1f).apply { setMargins(0, dp(6), dp(4), 0) })
            actions.addView(styledButton("DELETE", Color.rgb(130, 45, 48)) {
                AlertDialog.Builder(this).setTitle("ลบภาพช่อง ${item.slot + 1}?")
                    .setMessage("ภาพนี้จะถูกลบจาก Flash ภายใน ESP32")
                    .setNegativeButton("ยกเลิก", null)
                    .setPositiveButton("ลบ") { _, _ -> performImageAction("IMG_DELETE,${item.slot}", "DELETE") }
                    .show()
            }, LinearLayout.LayoutParams(0, dp(42), 1f).apply { setMargins(dp(4), dp(6), 0, 0) })
            row.addView(actions)
            container.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        }
    }

    private fun performImageAction(command: String, expectedAction: String) {
        val active = socket ?: run { toast("กรุณาเชื่อมต่อ Bluetooth ก่อน"); return }
        if (imageTransferBusy || binTransferBusy) return
        imageTransferBusy = true
        updateImageProgress("กำลังส่งคำสั่งไปยังบอร์ด…")
        thread {
            try {
                imageResponses.clear()
                writeImageCommand(active, command)
                val response = nextImageResponse(8L)
                if (!response.contains(",${expectedAction},OK,")) throw IllegalStateException(response)
                val result = fetchBoardImages(active)
                runOnUiThread {
                    boardImages.clear(); boardImages.addAll(result.first)
                    imageStorageView?.text = result.second
                    renderBoardImages()
                    imageProgressView?.text = if (expectedAction == "SELECT") "ตั้งภาพเป็นโลโก้เปิดเครื่องและพื้นหลังเรียบร้อยแล้ว" else "ดำเนินการสำเร็จ"
                }
            } catch (e: Exception) {
                updateImageProgress("ดำเนินการไม่สำเร็จ: ${e.message}")
            } finally {
                imageTransferBusy = false
            }
        }
    }

    /** Open SAF/gallery URIs through both AssetFileDescriptor and InputStream paths.
     * Some Android document providers return a usable file descriptor but a null
     * openInputStream(), so do not assume every content:// URI behaves identically.
     */
    private fun openImageInputStream(uri: Uri): java.io.InputStream {
        var firstError: Exception? = null
        try {
            val afd = contentResolver.openAssetFileDescriptor(uri, "r")
            if (afd != null) return afd.createInputStream()
        } catch (e: Exception) { firstError = e }
        try {
            val stream = contentResolver.openInputStream(uri)
            if (stream != null) return stream
        } catch (e: Exception) {
            if (firstError == null) firstError = e else firstError?.addSuppressed(e)
        }
        val detail = firstError?.message?.takeIf { it.isNotBlank() } ?: "ผู้ให้บริการไฟล์ไม่คืนข้อมูล"
        throw IllegalStateException("Android เปิด URI ภาพไม่ได้ ($detail)", firstError)
    }

    private fun decodeSampledImage(uri: Uri, maxWidth: Int, maxHeight: Int): Bitmap {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        openImageInputStream(uri).use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
            throw IllegalStateException("ไฟล์นี้ไม่ใช่ภาพที่อ่านได้ หรือภาพยังอยู่บน Cloud: ${uri.lastPathSegment ?: uri}")
        }
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= maxWidth && bounds.outHeight / (sample * 2) >= maxHeight) sample *= 2
        val options = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.RGB_565
            inDither = true
        }
        return openImageInputStream(uri).use { input ->
            BitmapFactory.decodeStream(input, null, options)
                ?: throw IllegalStateException("ถอดรหัสภาพไม่ได้ (${bounds.outWidth}x${bounds.outHeight})")
        }
    }

    private fun createScreenPreview(uri: Uri): Bitmap {
        val source = decodeSampledImage(uri, 640, 480)
        val output = Bitmap.createBitmap(320, 240, Bitmap.Config.RGB_565)
        val canvas = Canvas(output)
        canvas.drawColor(Color.BLACK)
        val scale = max(320f / source.width.toFloat(), 240f / source.height.toFloat())
        val width = source.width * scale
        val height = source.height * scale
        val left = (320f - width) / 2f
        val top = (240f - height) / 2f
        val paint = Paint(Paint.FILTER_BITMAP_FLAG)
        canvas.drawBitmap(source, null, RectF(left, top, left + width, top + height), paint)
        source.recycle()
        return output
    }

    private fun decodeUriToRgb565(uri: Uri): ByteArray {
        val output = createScreenPreview(uri)
        val pixels = IntArray(320 * 240)
        output.getPixels(pixels, 0, 320, 0, 0, 320, 240)
        val bytes = ByteArray(320 * 240 * 2)
        var offset = 0
        pixels.forEach { color ->
            val r = Color.red(color)
            val g = Color.green(color)
            val b = Color.blue(color)
            val rgb565 = ((r shr 3) shl 11) or ((g shr 2) shl 5) or (b shr 3)
            bytes[offset++] = (rgb565 and 0xFF).toByte()
            bytes[offset++] = ((rgb565 shr 8) and 0xFF).toByte()
        }
        output.recycle()
        return bytes
    }

    private fun uploadSelectedImages() {
        val active = socket ?: run { toast("กรุณาเชื่อมต่อ Bluetooth กับ ESP32 ก่อน"); return }
        if (selectedImageUris.isEmpty()) { toast("กรุณาเลือกภาพก่อน"); return }
        if (imageTransferBusy || binTransferBusy) return
        imageTransferBusy = true
        val uris = selectedImageUris.toList()
        thread {
            var binaryChunkInFlight = false
            try {
                var stored = fetchBoardImages(active).first.toMutableList()
                var completed = 0
                for (uri in uris) {
                    val freeSlot = (0 until 8).firstOrNull { slot -> stored.none { it.slot == slot } }
                        ?: throw IllegalStateException("ช่องเก็บภาพเต็มแล้ว (สูงสุด 8 ช่อง)")
                    updateImageProgress("กำลังเตรียมภาพ ${completed + 1}/${uris.size}…")
                    val payload = decodeUriToRgb565(uri)
                    val crc = CRC32().apply { update(payload) }.value
                    imageResponses.clear()
                    writeImageCommand(active, "IMG_BEGIN,$freeSlot,${payload.size},$crc")
                    val ready = nextImageResponse(12L)
                    if (!ready.startsWith("NATTWUT_IMG,READY,")) throw IllegalStateException(ready)

                    var offset = 0
                    val chunkSize = 256
                    while (offset < payload.size) {
                        val length = minOf(chunkSize, payload.size - offset)
                        binaryChunkInFlight = true
                        synchronized(active) {
                            active.outputStream.write(("IMG_CHUNK,$length\n").toByteArray(Charsets.UTF_8))
                            active.outputStream.write(payload, offset, length)
                            active.outputStream.flush()
                        }
                        val ack = nextImageResponse(12L)
                        binaryChunkInFlight = false
                        val acknowledged = ack.substringAfterLast(',').toIntOrNull()
                        val expected = offset + length
                        if (!ack.startsWith("NATTWUT_IMG,ACK,") || acknowledged != expected) {
                            throw IllegalStateException("ยืนยันข้อมูลไม่ตรงกันที่ $expected bytes: $ack")
                        }
                        offset += length
                        val overall = ((completed * payload.size + offset) * 100L / (uris.size * payload.size)).toInt()
                        updateImageProgress("กำลังส่งภาพ ${completed + 1}/${uris.size}: $overall% (${offset / 1024} / ${payload.size / 1024} KB)")
                    }
                    writeImageCommand(active, "IMG_END")
                    val done = nextImageResponse(15L)
                    if (!done.startsWith("NATTWUT_IMG,DONE,$freeSlot")) throw IllegalStateException(done)
                    stored.add(BoardImage(freeSlot, payload.size.toLong(), false))
                    completed++
                    updateImageProgress("บันทึกภาพ ${completed}/${uris.size} สำเร็จ")
                }
                val result = fetchBoardImages(active)
                runOnUiThread {
                    boardImages.clear(); boardImages.addAll(result.first)
                    imageStorageView?.text = result.second
                    renderBoardImages()
                    imageProgressView?.text = "ส่งภาพครบ ${completed} ภาพแล้ว • เลือก USE AT BOOT + BG เพื่อใช้ภาพเดียวกันเป็นโลโก้และพื้นหลัง"
                }
            } catch (e: Exception) {
                if (binaryChunkInFlight) {
                    // The ESP32 is waiting for exact binary payload length; close the
                    // link so firmware can safely discard the incomplete temp file.
                    try { active.close() } catch (_: Exception) { }
                    runOnUiThread {
                        if (socket === active) {
                            socket = null
                            status.text = "● DISCONNECTED • IMAGE TRANSFER INTERRUPTED"
                            status.setTextColor(Color.RED)
                            connectBtn.text = "CONNECT TO ESP32"
                            connectBtn.isEnabled = true
                        }
                    }
                } else {
                    try { writeImageCommand(active, "IMG_ABORT") } catch (_: Exception) { }
                }
                updateImageProgress("ส่งภาพไม่สำเร็จ: ${e.message}")
            } finally {
                imageTransferBusy = false
            }
        }
    }

    private fun settingsPage() {
        body.addView(pageHeader("11 / SYSTEM PREFERENCES", "CONTROL ROOM", "Appearance and connection settings", Color.rgb(160, 175, 198)))
        val theme = slab(Color.rgb(13, 19, 29), Color.rgb(48, 61, 79))
        theme.addView(eyebrow("INTERFACE ACCENT", cyan))
        val colors = listOf(Color.rgb(0,160,255), Color.rgb(255,75,75), Color.rgb(65,220,145), Color.rgb(205,90,255), Color.rgb(255,190,55), Color.WHITE)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, dp(7), 0, dp(5)) }
        colors.forEach { c ->
            val b = View(this).apply { background = rounded(c, Color.WHITE, 30f); setOnClickListener { accent = c; themeColor = c; toast("เปลี่ยนสีเน้นของแอปแล้ว"); showPage("SETTINGS") } }
            row.addView(b, LinearLayout.LayoutParams(dp(34), dp(34)).apply { setMargins(dp(5), dp(6), dp(5), dp(6)) })
        }
        theme.addView(row); body.addView(theme)
        val diagnostics = slab(Color.rgb(9, 15, 23), Color.rgb(43, 57, 74))
        diagnostics.addView(eyebrow("SYSTEM INFORMATION"))
        diagnostics.addView(statLine("Telemetry format", "NATTWUT,1 CSV"))
        diagnostics.addView(statLine("Wireless transport", "BLUETOOTH SPP"))
        diagnostics.addView(statLine("Missing values", "-- / NA"))
        diagnostics.addView(statLine("Active session packets", receivedPackets.toString()))
        body.addView(diagnostics)
        body.addView(styledButton("DISCONNECT BLUETOOTH", Color.rgb(125, 40, 48)) { disconnect() }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(10) })
        body.addView(label("Hardware pin assignments are firmware-side and are not modified by app appearance settings.", 9f, muted, false).apply { setPadding(dp(3), dp(10), dp(3), 0) })
    }


    private fun requestBtPermission() {
    if (Build.VERSION.SDK_INT >= 31) {
        val permissions = mutableListOf<String>()

        if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            permissions.add(Manifest.permission.BLUETOOTH_CONNECT)
        }

        if (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
            permissions.add(Manifest.permission.BLUETOOTH_SCAN)
        }

        if (permissions.isNotEmpty()) {
            requestPermissions(permissions.toTypedArray(), 41)
        }
    }
}

    override fun onRequestPermissionsResult(
    requestCode: Int,
    permissions: Array<out String>,
    grantResults: IntArray
) {
    super.onRequestPermissionsResult(requestCode, permissions, grantResults)

    if (requestCode == 41 && Build.VERSION.SDK_INT >= 31) {
        val connectGranted =
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

        val scanGranted =
            checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED

        if (!connectGranted || !scanGranted) {
            toast("กรุณาอนุญาต Nearby devices / Bluetooth")
        } else {
            toast("อนุญาต Bluetooth แล้ว กรุณากด CONNECT อีกครั้ง")
        }
    }
    if (requestCode == 42) {
        val granted = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (granted) {
            sendBtCommand("GPS_SOURCE,PHONE")
            startPhoneLocation()
            showPage("GPS")
        } else {
            gpsSource = "BOARD"
            gpsPrefs.edit().putString("source", "BOARD").apply()
            sendBtCommand("GPS_SOURCE,BOARD")
            toast("ไม่ได้รับสิทธิ์ Location จึงกลับไปใช้ GPS บนบอร์ด")
            showPage("GPS")
        }
    }
}

    private fun showPairedDevices() {
        if (Build.VERSION.SDK_INT >= 31 &&
    (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED ||
     checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED)
) {
            requestBtPermission(); return
        }
        val adapter = BluetoothAdapter.getDefaultAdapter()
        if (adapter == null) { toast("โทรศัพท์ไม่รองรับ Bluetooth Classic"); return }
        if (!adapter.isEnabled) { toast("กรุณาเปิด Bluetooth ก่อน"); return }
        val devices = adapter.bondedDevices?.toList().orEmpty()
        if (devices.isEmpty()) { toast("จับคู่ ESP32 ชื่อ Nattawut ECU ใน Settings > Bluetooth ก่อน"); return }
        val names = devices.map { "${it.name ?: "Unknown"} (${it.address})" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("เลือกอุปกรณ์ SmartGauge").setItems(names) { _, which -> connect(devices[which]) }
            .setNegativeButton("ยกเลิก", null).show()
    }
private fun connect(device: BluetoothDevice) {
    if (Build.VERSION.SDK_INT >= 31 &&
    (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED ||
     checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED)
) {
    requestBtPermission()
    return
}

    connectBtn.isEnabled = false
    status.text = "● CONNECTING..."
    status.setTextColor(Color.YELLOW)

    thread {
        var newSocket: BluetoothSocket? = null

        try {

            val connectedSocket =
                device.createRfcommSocketToServiceRecord(sppUuid)

            newSocket = connectedSocket
            connectedSocket.connect()

            socket = connectedSocket
            connectedSocket.outputStream.write(("PING\nSTATUS\nGPS_SOURCE,$gpsSource\n").toByteArray(Charsets.UTF_8))
            connectedSocket.outputStream.flush()
            if (gpsSource == "PHONE") runOnUiThread { startPhoneLocation() }

            runOnUiThread {
                status.text = "● CONNECTED • WAITING DATA"
                status.setTextColor(Color.GREEN)
                connectBtn.text = "DISCONNECT"
                connectBtn.isEnabled = true
            }

            readLoop(connectedSocket)

        } catch (e: Exception) {
            try {
                newSocket?.close()
            } catch (_: Exception) {
            }

            socket = null

            runOnUiThread {
                status.text = "● CONNECT FAILED: ${e.message}"
                status.setTextColor(Color.RED)
                connectBtn.text = "CONNECT"
                connectBtn.isEnabled = true
            }
        }
    }
}


    
private fun readLoop(s: BluetoothSocket) {
    readerThread = thread {
        try {
            runOnUiThread {
                if (socket === s) {
                    status.text = "● CONNECTED • WAITING DATA"
                    status.setTextColor(Color.YELLOW)
                }
            }

            val reader = BufferedReader(
                InputStreamReader(s.inputStream, Charsets.UTF_8)
            )

            while (!Thread.currentThread().isInterrupted) {
                val line = reader.readLine() ?: break

                if (line.isNotBlank()) {
                    parsePacket(line)
                }
            }

        } catch (e: Exception) {
            runOnUiThread {
                if (socket === s) {
                    status.text = "● READ ERROR: ${e.message}"
                    status.setTextColor(Color.RED)
                }
            }
            return@thread
        }

        runOnUiThread {
            if (socket === s) {
                socket = null
                status.text = "● DISCONNECTED"
                status.setTextColor(Color.RED)
                connectBtn.text = "CONNECT"
                connectBtn.isEnabled = true
            }
        }
    }
 }

    

    
private fun parsePacket(line: String) {

    val cleanLine = line.trim().removePrefix("\uFEFF")
    if (cleanLine.isEmpty()) return

    // Preserve every complete line received over Bluetooth while logging.
    if (logging) {
        val stamp = System.currentTimeMillis().toString()
        val escaped = cleanLine.replace("\\", "\\\\").replace("\"", "\"\"")
        val emptyTelemetry = telemetry.keys.joinToString(",") { "" }
        synchronized(logRows) {
            logRows.add(listOf("BT_RAW", stamp, "", "", "\"$escaped\"").joinToString(",") + "," + emptyTelemetry)
        }
    }
    latestRawFrame = cleanLine
    val p = cleanLine.split(',').map { it.trim() }

    if (p.firstOrNull() == "NATTWUT_DTC") {
        when (p.getOrNull(1)) {
            "BEGIN" -> {
                synchronized(dtcItems) { dtcItems.clear() }
                dtcScanStatus = p.getOrNull(2) ?: "DTC RESPONSE RECEIVED"
                dtcExpectedCount = p.getOrNull(3)?.toIntOrNull() ?: 0
                refreshDtcViews()
            }
            "ITEM" -> if (p.size >= 5) {
                synchronized(dtcItems) { dtcItems.add("${p[2]} — ${p[3]} [${p[4]}]") }
                refreshDtcViews()
            }
            "END" -> {
                if (dtcItems.isEmpty() && dtcExpectedCount == 0 && !dtcScanStatus.contains("FAIL", true)) {
                    dtcScanStatus = "NO FAULT CODES"
                }
                refreshDtcViews()
                runOnUiThread { if (activePage != "DTC") toast("ได้รับผล DTC จากบอร์ด: $dtcScanStatus") }
            }
        }
        return
    }

    if (p.firstOrNull() == "NATTWUT_IMG") {
        imageResponses.offer(cleanLine)
        return
    }
    if (p.firstOrNull() == "NATTWUT_BIN") {
        binResponses.offer(cleanLine)
        return
    }

    if (p.firstOrNull() == "NATTWUT_ACK" || p.firstOrNull() == "NATTWUT_STATUS") {
        runOnUiThread {
            rawDataView?.text = latestRawFrame
            updateLoggerCount()
            if (p.firstOrNull() == "NATTWUT_STATUS") {
                status.text = "● LINK OK • ${p.drop(2).joinToString(" • ")}"
                status.setTextColor(Color.GREEN)
            }
        }
        return
    }

    // RAW frame sent separately by ESP32; keep it in the same session CSV.
    if (p.size >= 6 && p[0] == "NATTWUT_RAW" && p[1] == "1") {
        val timeMs = p[2].toLongOrNull() ?: System.currentTimeMillis()
        val table = p[3]
        val length = p[4]
        val hex = p.drop(5).joinToString(" ")
        latestRawFrame = "t=$timeMs ms | table=$table | len=$length\n$hex"
        if (logging) synchronized(logRows) {
            val emptyTelemetry = telemetry.keys.joinToString(",") { "" }
            logRows.add(listOf("RAW", timeMs.toString(), table, length, ("\"" + hex + "\"")).joinToString(",") + "," + emptyTelemetry)
        }
        runOnUiThread {
            rawDataView?.text = latestRawFrame
            updateLoggerCount()
        }
        return
    }

    // รับข้อมูลตั้งแต่ 15 ช่องขึ้นไป
    if (p.size < 15 || p[0] != "NATTWUT" || p[1] != "1") {
        runOnUiThread {
            status.text = "● INVALID PACKET: ${cleanLine.take(55)}"
            status.setTextColor(Color.RED)
        }
        return
    }

    val keys = listOf(
        "RPM", "TPS", "ECT", "IAT", "BAT",
        "O2", "AFR", "SPEED", "INJ", "IGN",
        "MAP", "STFT", "LTFT"
    )

    val row = mutableMapOf<String, String>()

    keys.forEachIndexed { i, key ->
        row[key] = if (p[i + 2] == "NA" || p[i + 2].isBlank()) "--" else p[i + 2]
    }

    synchronized(telemetry) {
        row.forEach { (k, v) -> telemetry[k] = v }
    }

    synchronized(this) {
        receivedPackets++
        lastPacketAt = System.currentTimeMillis()
        telemetryTimedOut = false
    }

    synchronized(histories) {
        keys.forEach { key ->
            val value = row[key]?.toFloatOrNull() ?: return@forEach
            val list = histories.getOrPut(key) { mutableListOf() }
            list.add(value)
            while (list.size > 120) list.removeAt(0)
        }
    }

    val rpm = row["RPM"]?.toFloatOrNull()
    if (rpm != null) {
        synchronized(samples) {
            samples.add(rpm)
            while (samples.size > 100) samples.removeAt(0)
        }
    }

    if (logging) {
        val stamp = System.currentTimeMillis().toString()
        synchronized(logRows) {
            logRows.add(
                listOf("TELEMETRY", stamp, "", "", "").joinToString(",") + "," +
                keys.joinToString(",") { key -> if (p[keys.indexOf(key) + 2] == "NA") "NA" else (row[key] ?: "0") }
            )
        }
        runOnUiThread { updateLoggerCount() }
    }

    runOnUiThread {
        status.text = "● DATA RECEIVED • #$receivedPackets"
        status.setTextColor(Color.GREEN)

        if (activePage == "DASHBOARD") {
            updateDashboardValues()
        } else if (activePage == "GRAPH") {
            body.findViewWithTag<TextView>("graph_current")?.text = telemetry[selectedMetric] ?: "--"
            graph.invalidate()
        } else if (activePage == "GPS" && gpsSource == "BOARD") {
            updateGpsPageValues()
        }
    }
}

    private fun updateDashboardValues() {
        fun walk(v: View) {
            if (v is TextView && v.tag is String && (v.tag as String).startsWith("value:")) {
                val key = (v.tag as String).substringAfter("value:")
                v.text = telemetry[key] ?: "--"
            }
            if (v is android.view.ViewGroup) for (i in 0 until v.childCount) walk(v.getChildAt(i))
        }
        walk(body)
        body.findViewWithTag<View>("rpm_gauge")?.invalidate()
    }

    private var pendingCsv: String? = null
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 78 && resultCode == RESULT_OK && data?.data != null) {
            toast("เลือกไฟล์ MAP แล้ว: ${data.data?.lastPathSegment ?: "ไฟล์"} — ยังไม่ส่งเข้า ECU")
        }
        if (requestCode == 80 && resultCode == RESULT_OK && data?.data != null) {
            selectedBinUri = data.data
            try {
                val flags = data.flags and Intent.FLAG_GRANT_READ_URI_PERMISSION
                if (flags != 0) contentResolver.takePersistableUriPermission(data.data!!, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) { }
            val name = displayName(data.data!!)
            if (activePage == "ECU") showPage("ECU")
            binTransferStatusView?.text = "เลือกแล้ว: $name"
        }
        if (requestCode == 81) {
            val bytes = pendingBinDownload
            val uri = data?.data
            if (resultCode == RESULT_OK && uri != null && bytes != null) {
                try {
                    contentResolver.openOutputStream(uri)?.use { it.write(bytes); it.flush() }
                        ?: throw IllegalStateException("เปิดไฟล์ปลายทางไม่ได้")
                    binTransferStatusView?.text = "บันทึกไฟล์ ${pendingBinDownloadName} ลงโทรศัพท์สำเร็จ (${bytes.size} bytes)"
                    toast("บันทึก ${pendingBinDownloadName} สำเร็จ")
                } catch (e: Exception) {
                    binTransferStatusView?.text = "บันทึกไฟล์ไม่สำเร็จ: ${e.message}"
                }
            } else {
                binTransferStatusView?.text = "ยกเลิกการบันทึกไฟล์ที่ดาวน์โหลด"
            }
            pendingBinDownload = null
        }
        if (requestCode == 79 && resultCode == RESULT_OK && data != null) {
            selectedImageUris.clear()
            val clip = data.clipData
            if (clip != null) {
                for (i in 0 until clip.itemCount) {
                    clip.getItemAt(i).uri?.let { if (!selectedImageUris.contains(it)) selectedImageUris.add(it) }
                }
            } else {
                data.data?.let { selectedImageUris.add(it) }
            }
            val grantedFlags = data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            selectedImageUris.forEach { uri ->
                try {
                    // Persist the exact read grant returned by the system picker when supported.
                    if ((grantedFlags and Intent.FLAG_GRANT_READ_URI_PERMISSION) != 0) {
                        contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                } catch (_: SecurityException) {
                    // A few OEM/document providers issue temporary grants only; the URI
                    // remains usable for this app session, so continue and report read errors later.
                } catch (_: Exception) { }
            }
            imageSelectionView?.text = "เลือกแล้ว ${selectedImageUris.size} ภาพ"
            selectedImageUris.firstOrNull()?.let { uri ->
                try {
                    imagePreviewView?.setImageBitmap(createScreenPreview(uri))
                } catch (e: Exception) {
                    imagePreviewView?.setImageDrawable(null)
                    imageProgressView?.text = "อ่านภาพตัวอย่างไม่ได้: ${e.message}"
                }
            }
        }
        if (requestCode == 77 && resultCode == RESULT_OK && data?.data != null) {
            try {
                contentResolver.openOutputStream(data.data!!)?.bufferedWriter()?.use { it.write(pendingCsv ?: "") }
                toast("ส่งออก CSV สำเร็จ")
            } catch (e: Exception) { toast("บันทึกไฟล์ไม่สำเร็จ: ${e.message}") }
        }
    }

    private fun disconnect() {
        stopPhoneLocation()
        try {
            socket?.let { active -> synchronized(active) { active.outputStream.write("GPS_SOURCE,BOARD\n".toByteArray(Charsets.UTF_8)); active.outputStream.flush() } }
            readerThread?.interrupt(); socket?.close()
        } catch (_: Exception) { }
        socket = null
        lastPacketAt = 0L
        telemetryTimedOut = true
        synchronized(telemetry) { telemetry.keys.forEach { telemetry[it] = "--" } }
        if (activePage == "DASHBOARD") updateDashboardValues()
        status.text = "● DISCONNECTED"; status.setTextColor(Color.RED)
        connectBtn.text = "CONNECT"; connectBtn.isEnabled = true
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    override fun onDestroy() { disconnect(); super.onDestroy() }

    inner class RpmGauge(context: android.content.Context) : View(context) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val cx = width / 2f; val cy = height * 0.78f
            val radius = minOf(width * 0.40f, height * 0.68f)
            val rect = android.graphics.RectF(cx-radius, cy-radius, cx+radius, cy+radius)
            p.style = Paint.Style.STROKE; p.strokeWidth = dp(9).toFloat(); p.strokeCap = Paint.Cap.ROUND
            p.color = Color.rgb(0, 155, 255); canvas.drawArc(rect, 135f, 150f, false, p)
            p.color = Color.rgb(255, 190, 0); canvas.drawArc(rect, 285f, 55f, false, p)
            p.color = Color.rgb(245, 55, 55); canvas.drawArc(rect, 340f, 65f, false, p)
            p.strokeWidth = dp(2).toFloat(); p.color = Color.WHITE
            for (i in 0..10) {
                val a = Math.toRadians((135.0 + i * 27.0)); val inner = radius - dp(17); val outer = radius - dp(5)
                canvas.drawLine(cx + kotlin.math.cos(a).toFloat()*inner, cy + kotlin.math.sin(a).toFloat()*inner,
                    cx + kotlin.math.cos(a).toFloat()*outer, cy + kotlin.math.sin(a).toFloat()*outer, p)
            }
            val rpm = telemetry["RPM"]?.toFloatOrNull() ?: 0f
            val angle = Math.toRadians(135.0 + (rpm.coerceIn(0f, 10000f) / 10000f) * 270.0)
            p.style = Paint.Style.STROKE; p.strokeWidth = dp(4).toFloat(); p.color = Color.WHITE
            canvas.drawLine(cx, cy, cx + kotlin.math.cos(angle).toFloat()*(radius-dp(24)), cy + kotlin.math.sin(angle).toFloat()*(radius-dp(24)), p)
            p.style = Paint.Style.FILL; p.color = cyan; canvas.drawCircle(cx, cy, dp(7).toFloat(), p)
            p.color = white; p.textAlign = Paint.Align.CENTER; p.typeface = Typeface.DEFAULT_BOLD; p.textSize = sp(31f)
            canvas.drawText(telemetry["RPM"] ?: "--", cx, cy-dp(19), p)
            p.textSize = sp(12f); p.color = muted; canvas.drawText("RPM x1000", cx, cy+dp(10), p)
        }
    }

    private fun sp(value: Float): Float = value * resources.displayMetrics.scaledDensity

    inner class LiveGraph(context: android.content.Context) : View(context) {
        var metric = "RPM"
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            canvas.drawColor(panel)
            paint.color = muted; paint.strokeWidth = 1f; paint.style = Paint.Style.STROKE
            for (i in 1..4) canvas.drawLine(20f, height * i / 5f, width - 12f, height * i / 5f, paint)
            val vals = synchronized(histories) { histories[metric]?.toList().orEmpty() }
            if (vals.size > 1) {
                val maxV = max(1000f, vals.maxOrNull() ?: 1000f)
                paint.color = cyan; paint.strokeWidth = 3f
                for (i in 1 until vals.size) {
                    val x1 = 20f + (width - 40f) * (i - 1) / (vals.size - 1)
                    val x2 = 20f + (width - 40f) * i / (vals.size - 1)
                    val y1 = height - 15f - (height - 30f) * vals[i - 1] / maxV
                    val y2 = height - 15f - (height - 30f) * vals[i] / maxV
                    canvas.drawLine(x1, y1, x2, y2, paint)
                }
            } else {
                paint.style = Paint.Style.FILL; paint.color = muted; paint.textSize = 13f
                canvas.drawText("Waiting for $metric telemetry…", 24f, height / 2f, paint)
            }
        }
    }
}
