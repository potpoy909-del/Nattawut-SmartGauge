package com.nattawut.ecu

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.UUID
import android.provider.OpenableColumns
import android.util.Base64
import java.util.zip.CRC32
import kotlin.concurrent.thread
import kotlin.math.max

class MainActivity : Activity() {
    private val sppUuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private var socket: BluetoothSocket? = null
    private var readerThread: Thread? = null
    private var logging = false
    private val logRows = mutableListOf<String>()
    private val samples = mutableListOf<Float>()
    private val histories = mutableMapOf<String, MutableList<Float>>()
    private var receivedPackets = 0L
    private var lastPacketAt = 0L
    private val telemetry = linkedMapOf(
        "RPM" to "--", "TPS" to "--", "ECT" to "--", "IAT" to "--",
        "BAT" to "--", "O2" to "--", "AFR" to "--", "SPEED" to "--",
        "INJ" to "--", "IGN" to "--", "MAP" to "--", "STFT" to "--", "LTFT" to "--"
    )
    private val units = mapOf("RPM" to "rpm", "TPS" to "%", "ECT" to "°C", "IAT" to "°C",
        "BAT" to "V", "O2" to "V", "AFR" to "AFR", "SPEED" to "km/h",
        "INJ" to "ms", "IGN" to "deg", "MAP" to "kPa", "STFT" to "%", "LTFT" to "%")
    private lateinit var root: LinearLayout
    private lateinit var body: LinearLayout
    private lateinit var status: TextView
    private lateinit var connectBtn: Button
    private lateinit var graph: LiveGraph
    private var activePage = "DASHBOARD"
    @Volatile private var binExpectedBytes = 0
    @Volatile private var binExpectedCrc = 0L
    @Volatile private var binFileName = "ECU_READ.BIN"
    private var binBuffer = java.io.ByteArrayOutputStream()
    private var pendingBin: ByteArray? = null
    private var binTransferProgress: TextView? = null
    private var binUploadProgress: TextView? = null
    private val uploadMonitor = Object()
    private val outputLock = Object()
    @Volatile private var uploadReply: String? = null

    private val bg = Color.rgb(8, 12, 21)
    private val panel = Color.rgb(20, 29, 44)
    private val cyan = Color.rgb(43, 220, 235)
    private val white = Color.WHITE
    private val muted = Color.rgb(155, 170, 190)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = Color.BLACK
        buildShell()
        requestBtPermission()
        showPage("DASHBOARD")
    }

    private fun buildShell() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 10, 12, 8)
            setBackgroundColor(bg)
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        header.addView(label("NATTWUT SMARTGAUGE", 23f, cyan, true))
        header.addView(label("HONDA PGM-FI  •  BLUETOOTH CLASSIC SPP", 10f, muted, true))
        status = label("● DISCONNECTED", 12f, Color.rgb(255, 100, 110), true)
        status.setPadding(0, 10, 0, 8)
        header.addView(status)
        root.addView(header)
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        connectBtn = Button(this).apply { text = "CONNECT"; setOnClickListener { if (socket == null) showPairedDevices() else disconnect() } }
        controls.addView(connectBtn, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(controls)
        val navScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("DASHBOARD", "GRAPH", "LOGGER", "DTC", "ECU", "MAP", "CONTROL", "SETTINGS").forEach { page ->
            val b = Button(this).apply {
                text = page
                textSize = 10f
                setOnClickListener { showPage(page) }
            }
            nav.addView(b)
        }
        navScroll.addView(nav)
        root.addView(navScroll)
        val scroll = ScrollView(this)
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 10, 0, 8) }
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(label("READ-ONLY ECU TELEMETRY  •  ECU WRITE / REMAP DISABLED", 9f, muted, false).apply {
            gravity = Gravity.CENTER; setPadding(0, 8, 0, 4)
        })
        setContentView(root)
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            this.text = text; textSize = size; setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun showPage(page: String) {
        activePage = page
        body.removeAllViews()
        when (page) {
            "DASHBOARD" -> dashboard()
            "GRAPH" -> graphPage()
            "LOGGER" -> loggerPage()
            "DTC" -> dtcPage()
            "ECU" -> ecuPage()
            "MAP" -> mapPage()
            "CONTROL" -> controlPage()
            "SETTINGS" -> settingsPage()
        }
    }

    private fun card(key: String): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 10, 10, 10)
            setBackgroundColor(panel)
        }
        box.addView(label(key, 12f, cyan, true))
        val value = label(telemetry[key] ?: "--", 28f, white, true)
        value.tag = "value:$key"
        box.addView(value)
        box.addView(label(units[key] ?: "", 10f, muted, false))
        return box
    }

    private fun dashboard() {
        body.addView(label("LIVE ENGINE DATA", 15f, white, true))
        // Three-column tile layout follows the SmartGauge phone-dashboard
        // arrangement shown in the supplied Bluetooth demonstration video.
        val keys = listOf("RPM", "TPS", "ECT", "IAT", "BAT", "AFR", "MAP", "SPEED", "INJ", "IGN", "O2", "STFT", "LTFT")
        keys.chunked(3).forEach { pair ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            pair.forEach { key ->
                row.addView(card(key), LinearLayout.LayoutParams(0, 104, 1f).apply { setMargins(3, 4, 3, 4) })
            }
            repeat(3 - pair.size) { row.addView(View(this), LinearLayout.LayoutParams(0, 104, 1f)) }
            body.addView(row)
        }
        body.addView(label("ข้อมูลที่ ECU ยังไม่ส่งหรือยังไม่ยืนยันจะแสดงเป็น --", 11f, muted, false))
    }

    private fun graphPage() {
        body.addView(label("REAL-TIME GRAPH", 16f, white, true))
        val picker = Spinner(this)
        val options = arrayOf("RPM", "TPS", "ECT", "BAT", "SPEED")
        picker.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, options)
        body.addView(picker)
        graph = LiveGraph(this)
        body.addView(graph, LinearLayout.LayoutParams(-1, 260))
        picker.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                graph.metric = options[position]; graph.invalidate()
            }
        }
    }

    private fun loggerPage() {
        body.addView(label("DATA LOGGER", 16f, white, true))
        body.addView(label("บันทึกข้อมูลที่ได้รับจริงจาก ESP32 เป็น CSV", 12f, muted, false))
        val start = Button(this).apply { text = if (logging) "STOP LOGGING" else "START LOGGING" }
        val export = Button(this).apply { text = "EXPORT CSV" }
        start.setOnClickListener { logging = !logging; start.text = if (logging) "STOP LOGGING" else "START LOGGING"; toast(if (logging) "เริ่มบันทึกแล้ว" else "หยุดบันทึกแล้ว") }
        export.setOnClickListener {
            if (logRows.isEmpty()) toast("ยังไม่มีข้อมูลสำหรับส่งออก") else {
                val csv = buildString {
                    append("timestamp,").append(telemetry.keys.joinToString(",")).append('\n')
                    logRows.forEach { append(it).append('\n') }
                }
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE); type = "text/csv"; putExtra(Intent.EXTRA_TITLE, "SmartGauge_Log.csv")
                }
                pendingCsv = csv
                startActivityForResult(intent, 77)
            }
        }
        body.addView(start); body.addView(export)
        val count = label("จำนวนตัวอย่างที่บันทึก: ${synchronized(logRows) { logRows.size }}", 13f, cyan, true)
        count.tag = "logger_count"
        body.addView(count)
    }

    private fun dtcPage() {
        body.addView(label("ECU DIAGNOSTIC TROUBLE CODES", 16f, white, true))
        body.addView(label("เฟิร์มแวร์ที่แนบมายังไม่มีคำสั่ง DTC ผ่าน Bluetooth SPP", 12f, muted, false))
        body.addView(label("DTC READ / CLEAR ถูกพักไว้จนกว่าจะเพิ่มและทดสอบคำสั่งควบคุมฝั่ง ESP32 เพื่อป้องกันการส่งคำสั่งที่ไม่รองรับ", 12f, Color.YELLOW, false))
        val read = Button(this).apply { text = "READ DTC — NOT AVAILABLE"; isEnabled = false }
        val clear = Button(this).apply { text = "CLEAR DTC — LOCKED"; isEnabled = false }
        body.addView(read); body.addView(clear)
    }

    private fun ecuPage() {
        body.addView(label("ECU INFORMATION", 16f, white, true))
        listOf("Bluetooth: Classic SPP / RFCOMM", "Device name: Nattawut ECU", "Telemetry: CSV v1", "Update interval: 250 ms",
            "ECU protocol: Honda Keihin K-Line", "ECU communication: Read-only",
            "ECU write / flash / remap: Disabled").forEach { body.addView(label("• $it", 13f, muted, false).apply { setPadding(0, 8, 0, 8) }) }
        body.addView(label("BIN TRANSFER", 15f, cyan, true).apply { setPadding(0, 14, 0, 4) })
        body.addView(label("READ BIN: รับไฟล์จากบอร์ดและบันทึกลงมือถือ • UPLOAD BIN: ส่งไฟล์จากมือถือไปเก็บใน Flash ของ ESP32", 12f, muted, false))
        binTransferProgress = label("รอรับไฟล์ BIN จาก ESP32", 13f, white, true).apply { setPadding(0, 10, 0, 6) }
        body.addView(binTransferProgress)
        val upload = Button(this).apply {
            text = "UPLOAD BIN TO ESP32 FLASH"
            setOnClickListener {
                if (socket == null || socket?.isConnected != true) { toast("กรุณาเชื่อมต่อ Nattawut ECU ก่อน"); return@setOnClickListener }
                val pick = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                    putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/octet-stream", "application/x-binary", "application/x-msdownload"))
                }
                startActivityForResult(pick, 79)
            }
        }
        body.addView(upload)
        binUploadProgress = label("ยังไม่ได้เลือกไฟล์ BIN", 13f, white, true).apply { setPadding(0, 8, 0, 10) }
        body.addView(binUploadProgress)
    }

    private fun mapPage() {
        body.addView(label("MAP FILE MANAGER", 16f, white, true))
        body.addView(label("คู่มือกำหนดการจัดการไฟล์ MAP บนตัว SmartGauge แต่เฟิร์มแวร์ SPP ที่แนบมายังไม่มี API สำหรับอ่าน/บันทึกไฟล์ผ่านมือถือ", 12f, muted, false))
        body.addView(label("ไฟล์ MAP 1–5 และการซิงก์กับ SD จะเปิดใช้หลังยืนยันรูปแบบไฟล์และเพิ่มคำสั่ง ESP32", 12f, Color.YELLOW, false))
        val locked = Button(this).apply { text = "MAP SYNC — NOT AVAILABLE"; isEnabled = false }
        body.addView(locked)
    }

    private fun controlPage() {
        body.addView(label("SMARTGAUGE REMOTE CONTROL", 16f, white, true))
        body.addView(label("โครงหน้ารีโมตเตรียมไว้แล้ว แต่ยังไม่ส่งคำสั่งไปยัง ESP32 เพราะโค้ดปัจจุบันรองรับเฉพาะ telemetry CSV v1", 12f, muted, false))
        listOf("เปลี่ยนหน้าเกจ", "ปรับความสว่าง", "เลือกสีธีม", "สั่งสแกน DTC", "จัดการไฟล์ MAP").forEach {
            val b = Button(this).apply { text = "$it — WAITING FIRMWARE API"; isEnabled = false }
            body.addView(b)
        }
    }

    private fun settingsPage() {
        body.addView(label("APP SETTINGS", 16f, white, true))
        body.addView(label("Bluetooth device: Nattawut ECU", 13f, muted, false))
        body.addView(label("Protocol: NATTWUT,1 CSV", 13f, muted, false))
        body.addView(label("Update rate: 4 Hz (250 ms)", 13f, muted, false))
        body.addView(label("ค่าที่ยังไม่ยืนยันจะไม่ถูกเติมด้วยข้อมูลจำลอง", 12f, cyan, true))
        val disconnect = Button(this).apply { text = "DISCONNECT BLUETOOTH"; setOnClickListener { disconnect() } }
        body.addView(disconnect)
    }

    private fun hasBtPermissions(): Boolean {
        if (Build.VERSION.SDK_INT < 31) return true
        return checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestBtPermission() {
        if (Build.VERSION.SDK_INT >= 31 && !hasBtPermissions()) {
            requestPermissions(
                arrayOf(
                    Manifest.permission.BLUETOOTH_CONNECT,
                    Manifest.permission.BLUETOOTH_SCAN
                ),
                41
            )
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 41) {
            if (hasBtPermissions()) {
                toast("อนุญาต Bluetooth แล้ว กด CONNECT อีกครั้ง")
            } else {
                toast("กรุณาอนุญาต Nearby devices เพื่อค้นหาและเชื่อมต่อ Nattawut ECU")
            }
        }
    }

    private fun showPairedDevices() {
        if (!hasBtPermissions()) {
            requestBtPermission()
            return
        }
        val adapter = BluetoothAdapter.getDefaultAdapter()
        if (adapter == null) { toast("โทรศัพท์ไม่รองรับ Bluetooth Classic"); return }
        if (!adapter.isEnabled) { toast("กรุณาเปิด Bluetooth ก่อน"); return }
        val devices = adapter.bondedDevices?.toList().orEmpty()
        if (devices.isEmpty()) { toast("จับคู่ ESP32 ชื่อ Nattawut ECU ใน Settings > Bluetooth ก่อน"); return }
        val names = devices.map { "${it.name ?: "Unknown"} (${it.address})" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("เลือกอุปกรณ์ SmartGauge").setItems(names) { _, which -> connect(devices[which]) }
            .setNegativeButton("ยกเลิก", null).show()
    }

    
private fun connect(device: BluetoothDevice) {
    if (Build.VERSION.SDK_INT >= 31 &&
        checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
        requestBtPermission()
        return
    }

    connectBtn.isEnabled = false
    status.text = "● CONNECTING TO ${device.name ?: "DEVICE"}..."
    status.setTextColor(Color.YELLOW)

    thread {
        var newSocket: BluetoothSocket? = null
        try {
            // This app connects only to already-paired devices. No discovery scan is
            // needed here; avoiding cancelDiscovery() prevents the SCAN permission
            // failure seen on Android 12–15.
            val connectedSocket = device.createRfcommSocketToServiceRecord(sppUuid)
            newSocket = connectedSocket
            connectedSocket.connect()
            socket = connectedSocket
            runOnUiThread {
                connectBtn.isEnabled = true
                connectBtn.text = "DISCONNECT"
                status.text = "● CONNECTED • WAITING DATA"
                status.setTextColor(Color.YELLOW)
            }
            readLoop(connectedSocket)
        } catch (e: SecurityException) {
            try { newSocket?.close() } catch (_: Exception) {}
            runOnUiThread {
                connectBtn.isEnabled = true
                connectBtn.text = "CONNECT"
                status.text = "● PERMISSION ERROR: ${e.message}"
                status.setTextColor(Color.RED)
                requestBtPermission()
            }
        } catch (e: Exception) {
            try { newSocket?.close() } catch (_: Exception) {}
            runOnUiThread {
                socket = null
                connectBtn.isEnabled = true
                connectBtn.text = "CONNECT"
                status.text = "● CONNECT FAILED: ${e.message}"
                status.setTextColor(Color.RED)
            }
        }
    }
}

private fun readLoop(s: BluetoothSocket) {
    readerThread = thread {
        try {
            runOnUiThread {
                if (socket === s) {
                    status.text = "● CONNECTED • WAITING DATA"
                    status.setTextColor(Color.YELLOW)
                }
            }

            val reader = BufferedReader(
                InputStreamReader(s.inputStream, Charsets.UTF_8)
            )

            while (!Thread.currentThread().isInterrupted) {
                val line = reader.readLine() ?: break

                if (line.isNotBlank()) {
                    parsePacket(line)
                }
            }

        } catch (e: Exception) {
            runOnUiThread {
                if (socket === s) {
                    status.text = "● READ ERROR: ${e.message}"
                    status.setTextColor(Color.RED)
                }
            }
            return@thread
        }

        runOnUiThread {
            if (socket === s) {
                socket = null
                status.text = "● DISCONNECTED"
                status.setTextColor(Color.RED)
                connectBtn.text = "CONNECT"
                connectBtn.isEnabled = true
            }
        }
    }
 }

    

    
private fun parsePacket(line: String) {

    val cleanLine = line.trim().removePrefix("\uFEFF")
    if (cleanLine.startsWith("NATTWUT_BIN,")) {
        handleBinTransferPacket(cleanLine)
        return
    }
    val p = cleanLine.split(',').map { it.trim() }

    // รับข้อมูลตั้งแต่ 15 ช่องขึ้นไป
    if (p.size < 15 || p[0] != "NATTWUT" || p[1] != "1") {
        runOnUiThread {
            status.text = "● INVALID PACKET: ${cleanLine.take(55)}"
            status.setTextColor(Color.RED)
        }
        return
    }

    val keys = listOf(
        "RPM", "TPS", "ECT", "IAT", "BAT",
        "O2", "AFR", "SPEED", "INJ", "IGN",
        "MAP", "STFT", "LTFT"
    )

    val row = mutableMapOf<String, String>()

    keys.forEachIndexed { i, key ->
        row[key] = if (p[i + 2] == "NA") "--" else p[i + 2]
    }

    synchronized(telemetry) {
        row.forEach { (k, v) -> telemetry[k] = v }
    }

    synchronized(this) {
        receivedPackets++
        lastPacketAt = System.currentTimeMillis()
    }

    synchronized(histories) {
        keys.forEach { key ->
            val value = row[key]?.toFloatOrNull() ?: return@forEach
            val list = histories.getOrPut(key) { mutableListOf() }
            list.add(value)
            while (list.size > 120) list.removeAt(0)
        }
    }

    val rpm = row["RPM"]?.toFloatOrNull()
    if (rpm != null) {
        synchronized(samples) {
            samples.add(rpm)
            while (samples.size > 100) samples.removeAt(0)
        }
    }

    if (logging) {
        val stamp = System.currentTimeMillis().toString()
        synchronized(logRows) {
            logRows.add(
                stamp + "," + keys.joinToString(",") { row[it] ?: "--" }
            )
        }
    }

    runOnUiThread {
        status.text = "● DATA RECEIVED • #$receivedPackets"
        status.setTextColor(Color.GREEN)

        if (activePage == "DASHBOARD") {
            updateDashboardValues()
        } else if (activePage == "GRAPH") {
            graph.invalidate()
        }
    }
}

    private fun handleBinTransferPacket(line: String) {
        val p = line.split(',', limit = 5)
        when (p.getOrNull(1)) {
            "BEGIN" -> {
                val size = p.getOrNull(3)?.toIntOrNull() ?: return
                val crc = p.getOrNull(4)?.toLongOrNull(16) ?: return
                if (size <= 0 || size > 512 * 1024) return
                synchronized(this) {
                    binFileName = p.getOrNull(2)?.take(80) ?: "ECU_READ.BIN"
                    binExpectedBytes = size
                    binExpectedCrc = crc
                    binBuffer = java.io.ByteArrayOutputStream(size)
                }
                runOnUiThread {
                    if (binTransferProgress != null) binTransferProgress?.text = "กำลังรับ $binFileName • 0%"
                    status.text = "● RECEIVING ECU BIN"
                    status.setTextColor(cyan)
                }
            }
            "DATA" -> {
                val offset = p.getOrNull(2)?.toIntOrNull() ?: return
                val payload = p.getOrNull(3) ?: return
                val bytes = try { Base64.decode(payload, Base64.DEFAULT) } catch (_: Exception) { return }
                var received = 0
                synchronized(this) {
                    if (binExpectedBytes <= 0 || offset != binBuffer.size()) return
                    if (binBuffer.size() + bytes.size > binExpectedBytes) return
                    binBuffer.write(bytes)
                    received = binBuffer.size()
                }
                val pct = (received * 100L / binExpectedBytes).toInt()
                runOnUiThread { binTransferProgress?.text = "กำลังรับ $binFileName • $pct% ($received/$binExpectedBytes bytes)" }
            }
            "END" -> {
                val endCrc = p.getOrNull(2)?.toLongOrNull(16) ?: return
                var data = byteArrayOf()
                var expectedSize = 0
                var expectedCrc = 0L
                var name = "ECU_READ.BIN"
                synchronized(this) {
                    data = binBuffer.toByteArray(); expectedSize = binExpectedBytes
                    expectedCrc = binExpectedCrc; name = binFileName
                    binExpectedBytes = 0
                }
                val crc = CRC32().apply { update(data) }.value
                if (data.size != expectedSize || crc != expectedCrc || crc != endCrc) {
                    runOnUiThread {
                        binTransferProgress?.text = "รับไฟล์ไม่สมบูรณ์ / CRC ERROR"
                        status.text = "● BIN TRANSFER ERROR"; status.setTextColor(Color.RED)
                    }
                    return
                }
                pendingBin = data
                runOnUiThread {
                    binTransferProgress?.text = "รับครบ 100% • ตรวจสอบ CRC ผ่าน • กำลังบันทึก"
                    val safeName = name.substringAfterLast('/').replace(Regex("[^A-Za-z0-9._-]"), "_")
                    val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE); type = "application/octet-stream"
                        putExtra(Intent.EXTRA_TITLE, if (safeName.endsWith(".BIN", true)) safeName else "$safeName.BIN")
                    }
                    startActivityForResult(intent, 78)
                }
            }
            "PUT_READY", "PUT_ACK", "PUT_DONE", "PUT_ERROR", "PUT_ABORTED" -> {
                synchronized(uploadMonitor) {
                    uploadReply = line
                    uploadMonitor.notifyAll()
                }
                if (p.getOrNull(1) == "PUT_ACK") {
                    val ack = p.getOrNull(2)?.toLongOrNull() ?: 0L
                    runOnUiThread { binUploadProgress?.text = "กำลังส่ง BIN ไปยัง ESP32 • ยืนยันแล้ว $ack bytes" }
                }
            }
        }
    }

    private fun getDisplayName(uri: android.net.Uri): String {
        var name = "UPLOAD.BIN"
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (index >= 0 && cursor.moveToFirst()) name = cursor.getString(index) ?: name
        }
        return name
    }

    private fun sendUploadLine(line: String) {
        val s = socket ?: throw IllegalStateException("Bluetooth disconnected")
        synchronized(outputLock) {
            s.outputStream.write((line + "\r\n").toByteArray(Charsets.UTF_8))
            s.outputStream.flush()
        }
    }

    private fun waitUploadReply(timeoutMs: Long, accept: (String) -> Boolean): String {
        val deadline = System.currentTimeMillis() + timeoutMs
        synchronized(uploadMonitor) {
            while (true) {
                val current = uploadReply
                if (current != null) {
                    uploadReply = null
                    if (current.contains(",PUT_ERROR,")) throw IllegalStateException(current.substringAfter(",PUT_ERROR,"))
                    if (accept(current)) return current
                }
                val remaining = deadline - System.currentTimeMillis()
                if (remaining <= 0) throw IllegalStateException("หมดเวลารอการยืนยันจาก ESP32")
                uploadMonitor.wait(remaining)
            }
        }
    }

    private fun uploadBinToBoard(uri: android.net.Uri) {
        var sessionStarted = false
        try {
            val nameRaw = getDisplayName(uri)
            val safeName = nameRaw.substringAfterLast('/').replace(Regex("[^A-Za-z0-9._-]"), "_")
            require(safeName.endsWith(".BIN", true)) { "กรุณาเลือกไฟล์นามสกุล .BIN" }
            val finalName = safeName
            require(finalName.length < 40 && !finalName.contains("..")) { "ชื่อไฟล์ไม่ถูกต้อง" }
            val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
                ?: throw IllegalStateException("เปิดไฟล์ไม่ได้")
            require(bytes.isNotEmpty() && bytes.size <= 512 * 1024) { "ไฟล์ต้องมีขนาด 1–512 KB" }
            val crc = CRC32().apply { update(bytes) }.value
            runOnUiThread { binUploadProgress?.text = "กำลังส่ง $finalName • ${bytes.size} bytes • 0%" }

            synchronized(uploadMonitor) { uploadReply = null }
            sessionStarted = true
            sendUploadLine("NATTWUT_BIN,PUT_BEGIN,$finalName,${bytes.size},${java.lang.Long.toHexString(crc).uppercase()}")
            waitUploadReply(10000) { it.startsWith("NATTWUT_BIN,PUT_READY,") }

            var offset = 0
            while (offset < bytes.size) {
                val count = minOf(48, bytes.size - offset)
                val chunk = bytes.copyOfRange(offset, offset + count)
                val encoded = Base64.encodeToString(chunk, Base64.NO_WRAP)
                synchronized(uploadMonitor) { uploadReply = null }
                sendUploadLine("NATTWUT_BIN,PUT_DATA,$offset,$encoded")
                val ack = waitUploadReply(10000) { it.startsWith("NATTWUT_BIN,PUT_ACK,") }
                val ackBytes = ack.substringAfterLast(',').toIntOrNull() ?: -1
                if (ackBytes != offset + count) throw IllegalStateException("ESP32 ยืนยันจำนวนข้อมูลไม่ตรงกัน")
                offset += count
                val pct = offset * 100 / bytes.size
                runOnUiThread { binUploadProgress?.text = "กำลังส่ง $finalName • $pct% ($offset/${bytes.size} bytes)" }
            }

            synchronized(uploadMonitor) { uploadReply = null }
            sendUploadLine("NATTWUT_BIN,PUT_END,${java.lang.Long.toHexString(crc).uppercase()}")
            val done = waitUploadReply(15000) { it.startsWith("NATTWUT_BIN,PUT_DONE,") }
            sessionStarted = false
            runOnUiThread {
                binUploadProgress?.text = "บันทึก $finalName ลง Flash สำเร็จ • ${bytes.size} bytes"
                toast("ส่ง BIN เข้า ESP32 สำเร็จ เปิด Page 5 เพื่อตรวจสอบไฟล์")
            }
        } catch (e: Exception) {
            if (sessionStarted) try { sendUploadLine("NATTWUT_BIN,PUT_ABORT") } catch (_: Exception) { }
            runOnUiThread {
                binUploadProgress?.text = "ส่ง BIN ไม่สำเร็จ: ${e.message}"
                toast("อัปโหลด BIN ไม่สำเร็จ: ${e.message}")
            }
        }
    }

    private fun updateDashboardValues() {
        fun walk(v: View) {
            if (v is TextView && v.tag is String && (v.tag as String).startsWith("value:")) {
                val key = (v.tag as String).substringAfter("value:")
                v.text = telemetry[key] ?: "--"
            }
            if (v is android.view.ViewGroup) for (i in 0 until v.childCount) walk(v.getChildAt(i))
        }
        walk(body)
    }

    private var pendingCsv: String? = null
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 77 && resultCode == RESULT_OK && data?.data != null) {
            try {
                contentResolver.openOutputStream(data.data!!)?.bufferedWriter()?.use { it.write(pendingCsv ?: "") }
                toast("ส่งออก CSV สำเร็จ")
            } catch (e: Exception) { toast("บันทึกไฟล์ไม่สำเร็จ: ${e.message}") }
        }
        if (requestCode == 79) {
            if (resultCode == RESULT_OK && data?.data != null) {
                val uri = data.data!!
                binUploadProgress?.text = "กำลังเตรียมไฟล์ BIN..."
                thread { uploadBinToBoard(uri) }
            } else {
                binUploadProgress?.text = "ยกเลิกการเลือกไฟล์"
            }
        }
        if (requestCode == 78) {
            if (resultCode == RESULT_OK && data?.data != null) {
                try {
                    val bytes = pendingBin ?: throw IllegalStateException("ไม่มีข้อมูล BIN")
                    contentResolver.openOutputStream(data.data!!)?.use { it.write(bytes); it.flush() }
                    pendingBin = null
                    binTransferProgress?.text = "บันทึก BIN ลงมือถือสำเร็จ • ${bytes.size} bytes"
                    toast("บันทึกไฟล์ BIN ลงมือถือสำเร็จ")
                } catch (e: Exception) {
                    binTransferProgress?.text = "บันทึก BIN ไม่สำเร็จ: ${e.message}"
                    toast("บันทึก BIN ไม่สำเร็จ: ${e.message}")
                }
            } else {
                pendingBin = null
                binTransferProgress?.text = "ยกเลิกการบันทึกไฟล์ BIN"
            }
        }
    }

    private fun disconnect() {
        try { readerThread?.interrupt(); socket?.close() } catch (_: Exception) { }
        socket = null
        status.text = "● DISCONNECTED"; status.setTextColor(Color.RED)
        connectBtn.text = "CONNECT"; connectBtn.isEnabled = true
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    override fun onDestroy() { disconnect(); super.onDestroy() }

    inner class LiveGraph(context: android.content.Context) : View(context) {
        var metric = "RPM"
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            canvas.drawColor(panel)
            paint.color = muted; paint.strokeWidth = 1f; paint.style = Paint.Style.STROKE
            for (i in 1..4) canvas.drawLine(20f, height * i / 5f, width - 12f, height * i / 5f, paint)
            val vals = synchronized(histories) { histories[metric]?.toList().orEmpty() }
            if (vals.size > 1) {
                val maxV = max(1000f, vals.maxOrNull() ?: 1000f)
                paint.color = cyan; paint.strokeWidth = 3f
                for (i in 1 until vals.size) {
                    val x1 = 20f + (width - 40f) * (i - 1) / (vals.size - 1)
                    val x2 = 20f + (width - 40f) * i / (vals.size - 1)
                    val y1 = height - 15f - (height - 30f) * vals[i - 1] / maxV
                    val y2 = height - 15f - (height - 30f) * vals[i] / maxV
                    canvas.drawLine(x1, y1, x2, y2, paint)
                }
            } else {
                paint.style = Paint.Style.FILL; paint.color = muted; paint.textSize = 13f
                canvas.drawText("Waiting for $metric telemetry…", 24f, height / 2f, paint)
            }
        }
    }
}
