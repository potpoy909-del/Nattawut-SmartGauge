# Nattawut SmartGauge Android V2 — Stage 2.1

แอป Android Kotlin สำหรับ Bluetooth Classic SPP (RFCOMM) และ firmware ESP32 ที่ส่ง CSV v1

## สร้าง APK ด้วยมือถือ
ดู `BUILD_ON_ANDROID_TH.md` — ใช้ GitHub Actions สร้าง APK บนคลาวด์ ไม่ต้องใช้คอมพิวเตอร์

## รับไฟล์ BIN จาก ECU ผ่าน Bluetooth SPP (ใหม่ใน 2.2)
- เมื่อ SmartGauge อ่าน BIN จาก ECU สำเร็จและมีมือถือเชื่อมต่ออยู่ เฟิร์มแวร์จะส่งไฟล์ BIN ผ่าน Bluetooth Classic SPP อัตโนมัติ
- แอปรับข้อมูลแบบ Base64 เป็นชิ้น ตรวจสอบขนาดและ CRC32 ก่อนเปิดหน้าต่างเลือกตำแหน่งบันทึกไฟล์บนมือถือ (Downloads หรือโฟลเดอร์ที่เลือก)
- การรับไฟล์นี้เป็นการรับ BIN ที่อ่านได้จาก ECU เท่านั้น ไม่ได้เพิ่มคำสั่งเขียน/แฟลช ECU จากมือถือ
- ต้องอัปโหลดเฟิร์มแวร์ `SmartGauge_Honda330_Bluetooth_BIN.ino` ที่แนบในโครงการนี้ลง ESP32-CYD ด้วย จึงจะมีการส่งไฟล์ BIN

## โปรโตคอล
`NATTWUT,1,RPM,TPS,ECT,IAT,BAT,O2,AFR,SPEED,INJ,IGN,MAP,STFT,LTFT`

ส่งทุก 250 ms เมื่อมี client เชื่อมต่อ `NA` คือไม่มีข้อมูลที่ยืนยันแล้ว แอปจะแสดง `--` โดยไม่สร้างค่าจำลอง

## หน้าที่มี
- Dashboard: 13 ช่อง telemetry
- Graph: เลือก RPM/TPS/ECT/BAT/SPEED และแสดงประวัติที่ได้รับจริง
- Logger: บันทึก packet ที่รับจริงและส่งออก CSV
- DTC/MAP/Control: ปิดไว้จนกว่าจะมี API ฝั่ง ESP32 ที่ผ่านการยืนยัน

## ข้อจำกัด
ต้องเป็น ESP32 ที่รองรับ Bluetooth Classic SPP (ESP32 ดั้งเดิม/CYD บางรุ่น) ไม่รองรับ ESP32-S2/S3/C3 ผ่าน SPP แบบนี้ แอปและ firmware ต้องทดสอบกับบอร์ดจริงก่อนใช้งานบนรถ

## Firmware ที่แนบ
ไฟล์ `firmware/Nattawut_SmartGauge_Bluetooth_Test.ino` คือไฟล์ Arduino ที่ผู้ใช้ส่งมาและใช้ชื่อ Bluetooth `Nattawut ECU` โปรดตรวจสอบรุ่นบอร์ด/ขา ECU ให้ตรงกับการต่อสายจริงก่อนอัปโหลด
