# Nattawut SmartGauge V3.9.0 — Page Redesign

รุ่นนี้ปรับโครงสร้างหน้าจอ Android ใหม่เป็นรายเมนู ไม่ใช่เพียงเปลี่ยนสี:
- Dashboard: Race Deck / instrument layout
- Graph: Oscilloscope workspace
- DTC: Diagnostic terminal
- ECU: BIN File Vault
- MAP: Calibration workbench (เลือกไฟล์ได้ แต่ยังไม่เขียน ECU)
- Control: Tool Matrix
- GPS: Track Mode
- Bluetooth: Link Station
- Images: Flash Gallery (คงคำสั่ง IMG เดิม)
- Logger: Black Box
- Settings: Control Room

เมนูหลักอยู่ด้านล่างและใช้สัญลักษณ์ไอคอน ข้อมูลยังใช้ telemetry จริงผ่าน Bluetooth Classic SPP เท่านั้น

ข้อจำกัด: ยังไม่ได้ Build APK ในสภาพแวดล้อมนี้ เนื่องจากไม่มี Android SDK/Gradle; โปรเจกต์นี้เป็น source project สำหรับ Build ใน Android Studio/GitHub Actions.
