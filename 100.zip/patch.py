from pathlib import Path
p=Path('/mnt/data/work_sg/Nattawut_SmartGauge_V3_1_MultiImage/Nattawut_SmartGauge_V3_1_MultiImage.ino')
s=p.read_text()
old='''const char* simFiles[] = {
    "1.bin", "2.bin", "3.bin", "4.bin", "5.bin",
    "6.bin", "7.bin", "8.bin", "9.bin", "10.bin",
    "11.bin", "12.bin", "13.bin", "14.bin"
};
const int totalSimFiles = 14;
int selectedFileIndex = 0; 
int fileScrollOffset = 0;  
'''
new='''// Real BIN inventory: only files physically present in LittleFS are shown.
// LittleFS is shared with boot images; never format it from the remap page.
static const uint8_t ECU_BIN_MAX_FILES = 24;
static const uint8_t ECU_BIN_NAME_LEN = 64;
static char ecuBinFiles[ECU_BIN_MAX_FILES][ECU_BIN_NAME_LEN];
static size_t ecuBinSizes[ECU_BIN_MAX_FILES];
static int totalBinFiles = 0;
int selectedFileIndex = 0;
int fileScrollOffset = 0;
static bool scanEcuBinFiles();
static bool isBinFilename(const char *name);
'''
assert old in s
s=s.replace(old,new)
# Replace touch logic page 5
start=s.index('    else if (currentPage == 5) { ', s.index('void handleTouch'))
end=s.index('    else if (currentPage == 6) {', start)
newtouch='''    else if (currentPage == 5) {
        // Tap one of the real files in the list to select it.
        if (x >= 2 && x <= 216 && y >= 25 && y <= 185) {
            int clickedRow = (y - 29) / 31;
            if (clickedRow >= 0 && clickedRow < 5) {
                int targetIndex = fileScrollOffset + clickedRow;
                if (targetIndex >= 0 && targetIndex < totalBinFiles && targetIndex != selectedFileIndex) {
                    selectedFileIndex = targetIndex;
                    updateEcuFileListSelection();
                }
            }
        }
        // Only the two agreed ECU REMAP actions are shown. Both remain safely
        // gated until the exact K58-T81 ROM protocol and checksum are verified.
        if (x >= 218 && x <= 320) {
            if (y >= 25 && y < 104) {
                ecuActiveBtn = 1;
                startEcuBinRead();
            } else if (y >= 105 && y <= 185) {
                ecuActiveBtn = 2;
                drawEcuActionButtons();
                startEcuFlashing(totalBinFiles > 0 ? ecuBinFiles[selectedFileIndex] : "");
            }
        }
    }
'''
s=s[:start]+newtouch+s[end:]
# Replace entire ECU page funcs block up to image preview
start=s.index('void drawEcuFlashPage() {')
end=s.index('// Draw a compact 160x120 preview', start)
newblock=r'''static bool isBinFilename(const char *name) {
    if (!name) return false;
    const size_t n = strlen(name);
    if (n < 5) return false;
    const char *ext = name + n - 4;
    return (ext[0] == '.' && (ext[1] == 'b' || ext[1] == 'B') &&
            (ext[2] == 'i' || ext[2] == 'I') && (ext[3] == 'n' || ext[3] == 'N'));
}

static bool scanEcuBinFiles() {
    totalBinFiles = 0;
    if (!imageFsReady) return false;
    File root = LittleFS.open("/");
    if (!root || !root.isDirectory()) { if (root) root.close(); return false; }
    File entry = root.openNextFile();
    while (entry && totalBinFiles < ECU_BIN_MAX_FILES) {
        String fullName = String(entry.name());
        String baseName = fullName;
        int slash = baseName.lastIndexOf('/');
        if (slash >= 0) baseName = baseName.substring(slash + 1);
        if (!entry.isDirectory() && isBinFilename(baseName.c_str()) && entry.size() > 0) {
            baseName.toCharArray(ecuBinFiles[totalBinFiles], ECU_BIN_NAME_LEN);
            ecuBinSizes[totalBinFiles] = entry.size();
            ++totalBinFiles;
        }
        entry.close();
        entry = root.openNextFile();
    }
    if (entry) entry.close();
    root.close();
    if (selectedFileIndex >= totalBinFiles) selectedFileIndex = totalBinFiles > 0 ? totalBinFiles - 1 : 0;
    if (selectedFileIndex < 0) selectedFileIndex = 0;
    if (fileScrollOffset > max(0, totalBinFiles - 5)) fileScrollOffset = max(0, totalBinFiles - 5);
    return true;
}

void drawEcuFlashPage() {
    uint16_t bColor = getBorderThemeColor();
    drawHeader("ECU REMAP", "5/7");
    tft.drawRect(2, 25, 316, 158, bColor);
    tft.setTextSize(1);
    tft.setTextColor(0x07FF, ILI9341_BLACK);
    tft.setCursor(8, 28); tft.print("BIN FILES IN ESP32 FLASH");
    scanEcuBinFiles();
    redrawEcuFileListOnly();
    drawEcuActionButtons();
}

void redrawEcuFileListOnly() {
    uint16_t bColor = getBorderThemeColor();
    const int startY = 34;
    for (int row = 0; row < 5; ++row) {
        const int idx = fileScrollOffset + row;
        const int rowY = startY + row * 29;
        if (idx < totalBinFiles) {
            const bool selected = idx == selectedFileIndex;
            tft.fillRect(5, rowY - 4, 185, 25, selected ? 0x0841 : ILI9341_BLACK);
            if (selected) tft.drawRect(5, rowY - 4, 185, 25, bColor);
            tft.setTextColor(selected ? 0xFFE0 : 0xFFFF, selected ? 0x0841 : ILI9341_BLACK);
            tft.setCursor(9, rowY + 3); tft.print(selected ? "> " : "  ");
            tft.print(ecuBinFiles[idx]);
            tft.setTextColor(0x7BEF, selected ? 0x0841 : ILI9341_BLACK);
            tft.setCursor(145, rowY + 3);
            if (ecuBinSizes[idx] < 1024UL) { tft.print((unsigned long)ecuBinSizes[idx]); tft.print("B"); }
            else { tft.print((float)ecuBinSizes[idx] / 1024.0f, 1); tft.print("K"); }
        } else {
            tft.fillRect(5, rowY - 4, 185, 25, ILI9341_BLACK);
        }
    }
    if (totalBinFiles == 0) {
        tft.setTextColor(0xFFE0, ILI9341_BLACK);
        tft.setCursor(12, 91); tft.print(imageFsReady ? "NO .BIN FILES FOUND" : "LITTLEFS NOT READY");
        tft.setTextColor(0x7BEF, ILI9341_BLACK);
        tft.setCursor(12, 108); tft.print("Phone BIN transfer not enabled yet");
    }
    // Simple scroll indicator; selection is by tapping a visible file row.
    const int barX = 194, barY = 30, barH = 150;
    tft.fillRect(barX, barY, 17, barH, ILI9341_BLACK);
    if (totalBinFiles > 5) {
        int handleH = max(15, (barH * 5) / totalBinFiles);
        int maxScroll = totalBinFiles - 5;
        int handleY = barY + (fileScrollOffset * (barH - handleH)) / maxScroll;
        tft.fillRect(barX + 2, handleY, 13, handleH, bColor);
    }
    lastDrawnScrollOffset = fileScrollOffset;
    lastDrawnSelectedFile = selectedFileIndex;
}

void updateEcuFileListSelection() {
    int oldOffset = fileScrollOffset;
    if (selectedFileIndex < fileScrollOffset) fileScrollOffset = selectedFileIndex;
    else if (selectedFileIndex >= fileScrollOffset + 5) fileScrollOffset = selectedFileIndex - 4;
    if (fileScrollOffset != oldOffset) { redrawEcuFileListOnly(); return; }
    redrawEcuFileListOnly();
}

void drawEcuActionButtons() {
    const int x = 220, w = 98;
    tft.drawRect(x, 25, w, 78, ecuActiveBtn == 1 ? 0x07E0 : getBorderThemeColor());
    tft.fillRect(x + 1, 26, w - 2, 76, 0x0010);
    tft.setTextSize(1); tft.setTextColor(0xFFFF, 0x0010);
    tft.setCursor(x + 8, 53); tft.print("READ BIN /");
    tft.setCursor(x + 8, 67); tft.print("BACKUP");
    tft.drawRect(x, 105, w, 78, ecuActiveBtn == 2 ? 0x07E0 : getBorderThemeColor());
    tft.fillRect(x + 1, 106, w - 2, 76, 0x0010);
    tft.setCursor(x + 8, 135); tft.print("FLASH /");
    tft.setCursor(x + 8, 149); tft.print("REMAP");
}

void showEcuRemapGate(const char *heading, const char *line1, const char *line2) {
    const int px = 14, py = 45, pw = 292, ph = 112;
    tft.fillRect(px, py, pw, ph, 0x0010);
    tft.drawRect(px, py, pw, ph, getBorderThemeColor());
    tft.setTextSize(1); tft.setTextColor(0xFFE0, 0x0010);
    tft.setCursor(px + 12, py + 14); tft.print(heading);
    tft.setTextColor(ILI9341_WHITE, 0x0010);
    tft.setCursor(px + 12, py + 38); tft.print(line1);
    tft.setCursor(px + 12, py + 56); tft.print(line2);
    tft.setTextColor(0x7BEF, 0x0010);
    tft.setCursor(px + 12, py + 83); tft.print("No command sent. ECU unchanged.");
    delay(2200);
    drawEcuFlashPage();
}

void startEcuBinRead() {
    // K58-T81-specific security key, ROM read framing, exact size and checksum
    // have not yet been validated against this ECU through the ESP32 interface.
    showEcuRemapGate("READ BIN / BACKUP LOCKED",
                     "K58-T81 read protocol pending validation",
                     "Connect and capture a verified HondaECU read log");
}

void startEcuFlashing(const char* filename) {
    // Destructive operation remains blocked until a complete verified original
    // backup, ECU-specific checksum and recovery procedure are available.
    (void)filename;
    showEcuRemapGate("FLASH / REMAP LOCKED",
                     "Requires verified original BIN + checksum",
                     "K58-T81 write / recovery not validated yet");
}

'''
s=s[:start]+newblock+s[end:]
p.write_text(s)
