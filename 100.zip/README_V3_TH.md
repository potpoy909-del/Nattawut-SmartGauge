
## ECU REMAP / BIN manager (Stage 1 safety implementation)

- Page 5 now displays only real, non-empty `.BIN` files found in the ESP32 LittleFS root. The former placeholder list (`1.bin` through `14.bin`) has been removed.
- The page contains exactly two ECU actions: `READ BIN / BACKUP` and `FLASH / REMAP`.
- Both ECU actions are deliberately gated. The current Honda K58-T81 security access, ROM read/write framing, exact ROM size, checksum location/algorithm and recovery sequence have not yet been verified end-to-end through this ESP32 K-Line interface.
- The BIN inventory uses the existing LittleFS partition shared with boot-logo images. It never formats LittleFS. Keep free space in mind; the current partition is 0x1D0000 bytes (1.8125 MiB) before filesystem overhead and existing image files.
- No ECU write command is sent. Do not treat a file as a valid backup unless a future read completes at the expected size and passes the ECU-specific checksum validation.
- The Android app now has a dedicated REMAP navigation page with the same two gated actions. Bluetooth BIN transfer and real ECU ROM read/write remain future stages.

Research basis: the public AlexDev-TH/TunerPro-HondaECU project documents HondaECU 3.3-derived K-Line ROM workflows, Security Access, ROM-size/checksum validation, and recovery cautions. Its README explicitly warns that an incomplete ROM read must not be written back and that a failed/interrupted write can leave an ECU unable to start. This project is used as protocol research, not as a claim that K58-T81 has been validated here. See https://github.com/AlexDev-TH/TunerPro-HondaECU and https://github.com/roccofz1/HondaECU.
