# Nattawut SmartGauge V3.8.0

โปรเจกต์ Android สำหรับ Nattawut SmartGauge — ออกแบบหน้าจอทุกเมนูใหม่เป็นรายหน้าในแนว Dark Motorsport / ECU Workshop

## วิธี Build ผ่าน GitHub Actions
1. แตก ZIP นี้
2. อัปโหลดไฟล์และโฟลเดอร์ทั้งหมดไปไว้ที่ root ของ GitHub Repository
3. เปิดแท็บ Actions แล้วเลือก workflow `Build Nattawut SmartGauge APK`
4. รอ workflow ทำงานเสร็จ แล้วดาวน์โหลด Artifact `Nattawut-SmartGauge-V3.8.0-APK`

หรือเปิดโฟลเดอร์โปรเจกต์ด้วย Android Studio แล้วสั่ง Build APK ได้

รายละเอียดการเปลี่ยนแปลงอยู่ใน `CHANGELOG_V3_8_0_TH.md`

หมายเหตุ: แพ็กเกจนี้ยังไม่ได้ผ่านการ Build APK จริงในสภาพแวดล้อมที่จัดทำไฟล์ ต้องให้ Gradle/Android SDK บน GitHub Actions หรือ Android Studio ตรวจสอบอีกครั้ง
