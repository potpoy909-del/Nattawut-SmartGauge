# NATTAWUT SMARTGAUGE V3 — RAW ECU LOGGER (ระยะพัฒนาแรก)

โปรเจกต์ Android ใช้ Bluetooth Classic SPP เชื่อมต่อ ESP32 CYD ชื่อ `Nattawut ECU`

## สิ่งที่เพิ่มในรุ่นนี้
- แอปรับและเก็บทุกบรรทัดที่ได้รับจาก Bluetooth ขณะเปิด START LOGGING
- รองรับ packet `NATTWUT_KLINE,1,<millis>,TX|RX,<length>,<byte>,...` เพื่อเก็บธุรกรรม K-Line ทั้ง TX และ RX
- เก็บบรรทัดที่ไม่รู้จักไว้เป็น raw text ไม่ทิ้งเพียงเพราะ parser ยังไม่รู้จัก
- แสดงจำนวน K-Line TX/RX และส่งออก CSV ผ่าน Android document picker
- ค่า telemetry ที่ ECU ไม่ส่งแสดง `--` แทนการสมมติเป็นศูนย์
- ใช้ Firmware V8 เป็นฐาน โดยเพิ่มการส่ง raw TX/RX ที่จุด klineTransact()

## ข้อจำกัดที่ต้องทราบ
- เป็นการบันทึกธุรกรรมที่ ESP32 ส่ง/รับผ่าน K-Line UART ไม่ใช่ passive oscilloscope ของระดับสัญญาณไฟฟ้า
- ECU จะตอบสนองเฉพาะคำขอที่รองรับ; firmware ไม่ได้สแกนทุก service/table แบบสุ่ม
- DTC, MAP และ Remote Control ผ่านแอปยังไม่เปิด เพราะ Bluetooth command API ฝั่ง firmware ยังรองรับเพียง PING/STATUS; การเปิดคำสั่งโดยไม่ทดสอบอาจกระทบการสื่อสาร ECU
- ต้องทดสอบบนรถจริงเพื่อยืนยันการรับ TX/RX, checksum, timing และความครบถ้วน

## Build APK
ใช้ GitHub Actions workflow `.github/workflows/android-build.yml` เพื่อสร้าง debug APK แล้วดาวน์โหลดจาก Artifacts
