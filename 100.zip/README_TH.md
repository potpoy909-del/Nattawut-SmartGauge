# Nattawut SmartGauge — HondaECU 3.3.0 READ/WRITE integration

## ไฟล์ต้นทางที่ใช้
- Android project ใช้จาก `100.zip` ล่าสุด
- Firmware ใช้จาก `ไฟล์ที่ใช้อยู่.ino` ล่าสุดที่ผู้ใช้ส่ง ไม่ใช้สเก็ตช์เก่าที่ติดอยู่ใน ZIP
- ลำดับคำสั่ง READ/WRITE อ้างอิง `HondaECU.py` และ `flash.py` ของ HondaECU 3.3.0
- แนบไฟล์ลิขสิทธิ์ GPL-3.0 ของโปรเจกต์ต้นฉบับไว้ใน `LICENSE_HondaECU_GPL-3.0.txt`

## การเลือก ROM ที่หน้า 5
- แตะช่อง `SZ` มุมขวาบนเพื่อเลือกขนาด ROM ด้วยตนเอง: 8, 16, 24, 32, 40, 48, 56, 64, 72, 80, 88, 96, 104, 112, 120, 128, 160, 192, 224 หรือ 256, 320, 384, 448, 512 KB
- แตะช่อง `M0/M1` เพื่อสลับเทคนิคเขียนตาม HondaECU 3.3.0
  - M0 = normal write (`0x7D`)
  - M1 = recovery-style write (`0x7B`, ตามด้วย `72 00 F1` และ `27 00 9F 00`)
- ต้องเลือกขนาดและโหมดเอง ไม่มีการตรวจ ECU ID หรือเลือกโปรไฟล์ให้อัตโนมัติ
- WRITE ตรวจขนาดไฟล์ให้ตรงกับขนาด ROM ที่เลือก และตรวจ checksum ก่อนเริ่มส่งคำสั่งเขียน

## ลำดับ READ
1. K-Line break 70 ms และ recovery 130 ms
2. `FE 72` fast-init
3. `72 00 F0` session
4. คำสั่ง Boot Mode `27` สองชุด
5. อ่านด้วย `82 82 00` ครั้งละ 8 bytes ตามขนาดที่เลือก
6. บันทึก BIN ลง LittleFS แล้วใช้ปุ่ม DOWNLOAD ในแอปเพื่อดึงไฟล์ลงโทรศัพท์

## ลำดับ WRITE
1. ตรวจขนาด BIN และ checksum (checksum byte อยู่ที่ตำแหน่ง EOF - 8 ตาม `flash.py`)
2. เข้า session และเลือก M0/M1 ตามที่ผู้ใช้กำหนด
3. ส่ง pre-write commands และ poll สถานะพร้อมเขียน
4. ส่งข้อมูลเป็นบล็อก 128 bytes พร้อม checksum ทั้งสองแบบ
5. ส่ง ACK ทุก 2 บล็อก และส่ง post-write commands

Offset ที่ตั้งไว้: M1 ใช้ `0x8000` (ระบบป้องกันกรณี address เกิน 16-bit); M0 ขนาด 48 KB ใช้ `0x4000` ตามโปรไฟล์เดิมของโครงการ; M0 ขนาดอื่นใช้ค่าเริ่มต้น `0x0000` ของ `flash.py`

## ข้อจำกัดการตรวจสอบ
ตรวจโครงสร้างโค้ด, ลำดับคำสั่งเทียบกับซอร์ส HondaECU 3.3.0, checksum arithmetic และรูปแบบ write block แล้ว แต่สภาพแวดล้อมนี้ไม่มี Arduino-ESP32 toolchain และ Android SDK/Gradle จึงยังไม่ได้ compile firmware/APK และยังไม่ได้ทดสอบกับ ECU จริง ต้องยืนยันขนาด ROM, โหมด และ offset ของ ECU เป้าหมายก่อนเขียนจริง
