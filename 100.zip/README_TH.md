# Nattawut SmartGauge Android V3 — GPS Source Selection

แอป Android Kotlin สำหรับ Bluetooth Classic SPP (RFCOMM) และ firmware ESP32 ที่ส่ง CSV v1

## สร้าง APK ด้วยมือถือ
ดู `BUILD_ON_ANDROID_TH.md` — ใช้ GitHub Actions สร้าง APK บนคลาวด์ ไม่ต้องใช้คอมพิวเตอร์

## GPS สองแหล่ง
- `GPS_SOURCE,BOARD` เลือก GPS Module ที่ต่อกับ UART ของ ESP32 (ค่าเริ่มต้น)
- `GPS_SOURCE,PHONE` เลือก GPS ของโทรศัพท์ Android
- แอปส่ง `PHONE_SPEED,<kmh>` ผ่าน Bluetooth Classic SPP เมื่อได้รับค่าความเร็ว GPS จาก Android
- ต้องแฟลช firmware `.ino` ที่อัปเดตพร้อมกับติดตั้ง APK ที่สร้างจากโปรเจกต์นี้

## โปรโตคอล telemetry
`NATTWUT,1,RPM,TPS,ECT,IAT,BAT,O2,AFR,SPEED,INJ,IGN,MAP,STFT,LTFT`

ส่งทุก 250 ms เมื่อมี client เชื่อมต่อ `NA` คือไม่มีข้อมูลที่ยืนยันแล้ว แอปจะแสดง `--` โดยไม่สร้างค่าจำลอง

## หน้าที่มี
- Dashboard: 13 ช่อง telemetry
- GPS: เลือกแหล่งความเร็วระหว่าง GPS Module บนบอร์ดกับ GPS โทรศัพท์ พร้อมแสดงพิกัดโทรศัพท์เมื่อใช้โหมด PHONE
- Graph: เลือก RPM/TPS/ECT/BAT/SPEED และแสดงประวัติที่ได้รับจริง
- Logger: บันทึก packet ที่รับจริงและส่งออก CSV
- DTC/MAP/Control: ปิดไว้จนกว่าจะมี API ฝั่ง ESP32 ที่ผ่านการยืนยัน

## ข้อจำกัด
ต้องเป็น ESP32 ที่รองรับ Bluetooth Classic SPP (ESP32 ดั้งเดิม/CYD บางรุ่น) ไม่รองรับ ESP32-S2/S3/C3 ผ่าน SPP แบบนี้ แอปและ firmware ต้องทดสอบกับบอร์ดจริงก่อนใช้งานบนรถ

## Firmware ที่แนบ
ไฟล์ `firmware/Nattawut_SmartGauge_V8_Base.ino` เป็น V8 baseline ที่เพิ่มคำสั่งเลือก GPS แล้ว โดยยังใช้ Bluetooth `Nattawut ECU` และ UART GPS mapping เดิม (RX=GPIO3, TX=GPIO1) โปรดตรวจสอบการต่อสายและรุ่นบอร์ดให้ตรงก่อนอัปโหลด
