# NATTAWUT SMARTGAUGE V3.6 — Android app source

โปรเจกต์ Android Kotlin สำหรับเชื่อมต่อ ESP32 ผ่าน Bluetooth Classic SPP โดยยึดโครงสร้างจาก `100.zip` และใช้ GPIO mapping เดิมของเฟิร์มแวร์ ไม่แก้ไขขาเชื่อมต่อในงานพัฒนาแอปนี้

## ฟังก์ชันในแอป

- **Dashboard:** แสดง RPM และ telemetry 13 ค่า โดยค่าที่ไม่มีข้อมูลจริงแสดง `--`
- **Graph:** กราฟข้อมูลที่ได้รับจริง เลือก RPM / TPS / ECT / IAT / BAT / SPEED / MAP / AFR / O2
- **DTC:** ส่ง `DTC_READ` และ `DTC_CLEAR` ผ่าน Bluetooth และแสดงผลตอบกลับจากบอร์ด (ต้องใช้ firmware ที่รองรับคำสั่งนี้)
- **GPS:** เลือก GPS Module บนบอร์ด หรือ GPS ของโทรศัพท์ Android และส่งความเร็วโทรศัพท์ผ่าน SPP
- **Images:** จัดการภาพบูตบน ESP32 ผ่าน `NATTWUT_IMG` (ต้องใช้ firmware ที่มี image manager)
- **RAW Logger:** บันทึก packet ที่ได้รับจริงและส่งออก CSV
- **MAP workspace:** เลือกไฟล์จากโทรศัพท์ ตรวจชื่อ ขนาด และ CRC32 ในเครื่อง โดยไม่เขียนไฟล์เข้า ECU
- **ECU status:** ส่งคำสั่ง `STATUS` เพื่อดูสถานะ K-Line / ECU ที่บอร์ดรายงาน

## ข้อจำกัดความปลอดภัย

- แอปนี้ไม่ส่งคำสั่งเขียน ROM, remap หรือ flash ECU
- การอ่าน/เขียน BIN เข้า ECU ใช้เครื่องมือบนบอร์ดหน้าที่ 5 ตามเฟิร์มแวร์และ SD Card ไม่ใช่การถ่ายโอนไฟล์ LittleFS ผ่านแอป
- DTC และ Image Manager ต้องใช้ firmware ที่เปิด protocol ตรงกัน หาก firmware ไม่รองรับ แอปจะไม่สามารถทำให้คำสั่งนั้นทำงานได้เอง
- Bluetooth เป็น Classic SPP ต้องใช้ ESP32 รุ่นที่รองรับ (ESP32 ดั้งเดิม/CYD ที่รองรับ SPP)

## สร้าง APK ด้วย GitHub Actions จากมือถือ

1. แตกไฟล์ ZIP นี้ แล้วอัปโหลด **ไฟล์และโฟลเดอร์ทั้งหมดภายใน ZIP** ไปไว้ที่ root ของ GitHub repository หรืออัปโหลด ZIP นี้ไว้ที่ root ก็ได้
2. เปิดแท็บ **Actions** แล้วเลือก **Build Nattawut SmartGauge APK**
3. กด **Run workflow** (หรือรอ workflow ทำงานหลัง commit)
4. เมื่อสถานะ Success ให้เปิดงานล่าสุด เลื่อนลงไปที่ **Artifacts** แล้วดาวน์โหลด `Nattawut-SmartGauge-V3.6-APK`
5. แตก Artifact และติดตั้ง APK บน Android

Workflow ตรวจได้ทั้งโปรเจกต์ที่วางไว้ที่ root และ ZIP ที่อยู่ที่ root โดยค้นหา `app/build.gradle` อัตโนมัติ

## Build configuration

- Android Gradle Plugin: 8.6.1
- Gradle: 8.7
- JDK: 17
- compileSdk: 35
- minSdk: 23
- targetSdk: 34


## V3.6.1 — รักษาระบบเดิมและพัฒนาต่อ

- ใช้เฟิร์มแวร์ SmartGauge รุ่น Page 5 SD BIN ล่าสุดที่มีเครื่องมือ READ BIN / WRITE BIN บนบอร์ด
- คงการเชื่อมต่อเดิม: K-Line RX GPIO35, K-Line TX GPIO22, GPS RX GPIO27
- คงระบบ Bluetooth Classic SPP, GPS, DTC, กราฟ, Logger และตัวจัดการภาพ Flash
- ไม่มีการเพิ่มสวิตช์ล็อก ECU หรือปิดเมนูเดิมในแอป
- การอ่าน/เขียน BIN จาก ECU ยังคงสั่งจากหน้า 5 บนบอร์ดตามเฟิร์มแวร์เดิม


## โครงสร้างไฟล์สำหรับ Build
แตก ZIP แล้วใช้โฟลเดอร์ที่มี `settings.gradle`, `build.gradle`, `app/` และ `.github/` อยู่ในระดับเดียวกันเป็นโฟลเดอร์โปรเจกต์หลัก ห้ามเปิดโฟลเดอร์ชั้นนอกที่ครอบโปรเจกต์อีกชั้น
