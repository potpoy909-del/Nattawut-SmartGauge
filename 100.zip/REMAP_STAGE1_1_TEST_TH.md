# Nattawut SmartGauge — REMAP Stage 1.1 test

## สิ่งที่ทดสอบได้ในรุ่นนี้
1. Build APK และอัปโหลด firmware ลง ESP32 CYD
2. ต่อ K-Line module กับ ECU และต่อ Bluetooth จากแอป
3. เปิดหน้า REMAP แล้วกด REFRESH ECU STATUS
4. ตรวจว่าแสดง KLINE_INIT_OK/NOT_READY และ ECU_RESPONSE_RECENT/NO_RECENT_ECU_RESPONSE ตามการตอบสนองจริง

## ข้อจำกัด
- MODEL_NOT_IDENTIFIED หมายถึงยังไม่มีการยืนยันรหัสรุ่นจาก ECU ROM-identification service
- READ_LOCKED และ WRITE_LOCKED เป็นสถานะตั้งใจล็อกไว้ ไม่ใช่ข้อผิดพลาดของแอป
- READ BIN / WRITE BIN ยังไม่ทำงานกับ ECU จริงในชุดนี้
- ห้ามทดลองคำสั่ง erase/program หรือใช้ไฟล์ BIN ที่ไม่ทราบรุ่นกับ ECU ที่ติดรถ
- การทดสอบนี้เป็นเพียงการตรวจ K-Line init/response แบบไม่ทำลายข้อมูล

## ข้อควรทำ
เก็บภาพหน้าจอหน้า REMAP หลัง REFRESH และ RAW Logger log จากการต่อ ECU จริง เพื่อยืนยันว่าการสื่อสารมี response สดและไม่ใช่เพียง Bluetooth connected
