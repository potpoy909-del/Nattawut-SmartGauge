# Nattawut SmartGauge — ECU REMAP Stage 1

## สิ่งที่แก้ไขในชุดนี้

1. ลบรายการ BIN จำลอง 1.bin ถึง 14.bin ออกจากหน้า ECU REMAP
2. หน้า ESP32 อ่านรายการ `.bin` จาก LittleFS จริงเท่านั้น และแสดงขนาดไฟล์
3. หน้า ESP32 มีเพียงสองปุ่มตามที่ตกลง: `READ BIN / BACKUP` และ `FLASH / REMAP`
4. เพิ่มหน้า `REMAP` ในเมนูแอป Android และมีสองปุ่มเดียวกัน
5. ปุ่มทั้งสองยังถูกล็อกอย่างปลอดภัย เพราะยังไม่มีการยืนยันโปรโตคอลอ่าน/เขียน ROM เฉพาะ K58-T81 ผ่านฮาร์ดแวร์ ESP32 ชุดนี้
6. ไม่สั่ง `LittleFS.format()` และไม่เปลี่ยน partition table เพื่อป้องกันภาพโลโก้/พื้นหลังเดิมสูญหาย

## ข้อจำกัดที่ยังไม่เปิด

- ยังไม่อ่าน BIN จาก ECU จริง
- ยังไม่ส่ง BIN ผ่าน Bluetooth ไป/กลับ
- ยังไม่เขียน BIN ลง ECU
- ยังไม่รับรอง Start Address 0x8000, ขนาด 64KB หรือ Checksum Address 0 สำหรับ K58-T81 จนกว่าจะตรวจสอบกับไฟล์อ่านจริงและข้อมูล ECU ที่ตรงรุ่น

## เกณฑ์ก่อนเปิด READ BIN

- ยืนยัน Security Access และสถานะ ECU หลังเข้าโหมด secure
- อ่านครบช่วง ROM โดยมี offset/length ที่ตรวจสอบได้
- ยืนยันขนาด ROM ที่แท้จริงของ K58-T81
- ตรวจ checksum ด้วยอัลกอริทึมและตำแหน่งที่ยืนยันกับรุ่นนี้
- เก็บ BIN ต้นฉบับลง LittleFS และส่งสำเนาไปมือถือ พร้อม SHA-256/CRC และตรวจขนาดหลังส่ง

## เกณฑ์ก่อนเปิด FLASH / REMAP

- มี Original BIN ที่อ่านจาก ECU เดิมและตรวจสอบผ่าน
- ไฟล์ที่จะเขียนมีขนาดและ checksum ผ่าน
- ยืนยันคำสั่ง erase/program/block/status/retry และสถานะ recovery กับ K58-T81
- มีแหล่งจ่ายไฟและขั้นตอนกู้คืนที่เหมาะสม รวมถึงทดสอบบน ECU สำรอง/bench ก่อน

แหล่งอ้างอิงการศึกษากระบวนการ: https://github.com/AlexDev-TH/TunerPro-HondaECU (HondaECU 3.3-derived; GPL-3.0) และ https://github.com/roccofz1/HondaECU. การอ้างอิงนี้ไม่ใช่การยืนยันว่ารุ่น K58-T81 อยู่ในตารางรองรับของ upstream หรือว่าโค้ดบน ESP32 ผ่านการทดสอบกับ ECU จริงแล้ว

## REMAP Stage 1.1 — live ECU link status (non-destructive)

- เพิ่มปุ่ม `REFRESH ECU STATUS` ในหน้า REMAP ของ Android และส่งคำสั่ง `REMAP_STATUS` ไป ESP32
- ESP32 ตอบ `NATTWUT_STATUS,2` โดยแยก K-Line init และการได้รับ ECU response ภายใน 3 วินาที
- แสดง `MODEL_NOT_IDENTIFIED`, `READ_LOCKED`, `WRITE_LOCKED` อย่างชัดเจน ไม่ตีความ Bluetooth connected เป็น ECU ready
- ปุ่ม READ BIN / WRITE BIN ยังเป็น safety gate และไม่ส่งคำสั่ง ROM read, erase หรือ program ใด ๆ
- การเปลี่ยนแปลงนี้ยังไม่ใช่การอ่าน/เขียน BIN จาก ECU และยังไม่ได้ทดสอบบนรถจริง ต้องอัปโหลด firmware และ build/install APK ก่อนทดสอบเฉพาะสถานะการสื่อสารแบบไม่ทำลายข้อมูล
