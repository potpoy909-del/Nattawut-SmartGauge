# Nattawut SmartGauge V3.8.0 — Page-by-page redesign

## แนวทางออกแบบ
- รื้อองค์ประกอบหน้าจอรายเมนูใหม่ ไม่ใช่เปลี่ยนเฉพาะสีจาก V3.7.0
- ใช้ภาษาภาพ Dark Motorsport / Workshop โดยให้แต่ละหน้ามี mood และโครงสร้างต่างกัน
- เพิ่มแผงข้อมูลเด่น, metric tiles, action tiles, command areas, section hierarchy และ animation เปิดหน้าแบบสั้น
- คงเมนูด้านล่าง, Bluetooth Classic SPP, telemetry, GPS source, DTC commands, BIN tools เดิม, MAP file inspector, Flash image workflow และ CSV logger

## หน้าที่ปรับรูปแบบ
- Dashboard: Engine Cockpit พร้อม RPM gauge, speed strip, sensor matrix และ quick tools
- Graph: Data Lab พร้อม channel selector, live plot และ channel snapshot
- Logger: Black Box พร้อม session state, record/export controls และรายการเฟรมล่าสุด
- DTC: Fault Finder พร้อม fault summary, scan/clear actions และ ECU response report
- ECU: Device Link พร้อมสถานะอุปกรณ์, packet metrics และทางลัดทดสอบ STATUS
- MAP: File Inspector พร้อม import, integrity check และรายละเอียดการตรวจไฟล์
- Workshop Hub: เปลี่ยนเป็น action launcher แยกตามเครื่องมือ
- GPS: Track Mode พร้อม speed display และเลือกแหล่ง Board/Phone
- Images: Flash Studio พร้อม workflow preview/select/transfer/verify (ใช้ระบบเดิม)
- Bluetooth: Link Station พร้อมสถานะ link, RX metrics และ PING/STATUS
- Settings: System Tuning พร้อม accent palette และ session controls

## ข้อจำกัดที่ระบุชัดเจน
- ไม่เพิ่มปุ่มแฟลช ECU หรือเขียน MAP ที่ยังไม่มี protocol/firmware รองรับ
- ไม่อ้างว่าฟังก์ชัน ECU BIN ในแอปทำงานแทนหน้า 5 บนบอร์ด
- ไม่เปลี่ยนการกำหนดขา GPIO ของบอร์ด และไม่เปลี่ยน firmware ในแพ็กเกจนี้
- ยังไม่ได้ยืนยัน Android Gradle build หรือทดสอบบนโทรศัพท์จริงในสภาพแวดล้อมนี้
