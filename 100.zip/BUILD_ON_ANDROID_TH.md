# วิธีสร้างแอป Nattawut SmartGauge V3.6.2

## สร้าง APK ผ่าน GitHub Actions (แนะนำ)

1. แตกไฟล์ ZIP นี้ก่อน
2. เปิด GitHub Repository ของคุณ
3. อัปโหลด **ไฟล์และโฟลเดอร์ทั้งหมดที่อยู่ภายใน ZIP** ไปไว้ที่ root ของ Repository โดยตรง (ต้องเห็น `app/`, `gradle/`, `.github/`, `build.gradle` และ `settings.gradle` อยู่ระดับเดียวกัน ห้ามอัปโหลดโฟลเดอร์ชั้นนอกที่ครอบไฟล์เหล่านี้)
4. Commit การเปลี่ยนแปลง
5. เปิดแท็บ **Actions** แล้วเลือก `Build Nattawut SmartGauge APK`
6. รอให้รายการ Build เป็นสีเขียว `Success`
7. เปิดงานล่าสุด เลื่อนลงไปที่ **Artifacts** แล้วดาวน์โหลด `Nattawut-SmartGauge-V3.6.2-APK`
8. แตกไฟล์ Artifact แล้วติดตั้ง `Nattawut-SmartGauge-V3.6.2-debug.apk`

## สำคัญ

- ต้องอัปโหลดเนื้อหาภายใน ZIP ไปที่ root ของ Repository ไม่ใช่อัปโหลด ZIP เป็นไฟล์ และไม่ใช่อัปโหลดโฟลเดอร์ที่ครอบโปรเจกต์
- โฟลเดอร์ `.github/workflows` ต้องอยู่ที่ root ของ Repository เพื่อให้ GitHub ตรวจพบ workflow
- โปรเจกต์ใช้ JDK 17, Gradle 8.7, Android Gradle Plugin 8.6.1 และ compileSdk 35
- ถ้า Actions แสดง `Failed` อย่าติดตั้ง APK จากงานนั้น ให้เปิด `Build debug APK` และส่งข้อความ error สีแดงมา

## เปิดใน Android Studio

เปิดโฟลเดอร์โปรเจกต์ที่มี `settings.gradle` และ `app/` อยู่ระดับเดียวกัน จากนั้นให้ Android Studio Sync Gradle ก่อนสั่ง Build APK
