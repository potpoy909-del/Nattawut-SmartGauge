# วิธีเปิดโปรเจกต์ Android และ Firmware

## Android app
1. แตก ZIP นี้ลงโฟลเดอร์ใหม่
2. เปิดโฟลเดอร์รากของโปรเจกต์ใน Android Studio
3. รอ Gradle Sync และติดตั้ง Android SDK/Build Tools ตามที่โปรเจกต์ร้องขอ
4. เลือก Build > Build APK(s)
5. ติดตั้ง APK และตรวจการเชื่อมต่อ Bluetooth กับ ESP32 ก่อนทดสอบรับส่ง BIN

หน้า ECU ในแอปทำหน้าที่เลือกไฟล์ BIN, ส่งไฟล์ไป ESP32, แสดงรายการไฟล์ใน LittleFS และดาวน์โหลดไฟล์กลับโทรศัพท์ แอปไม่ได้ส่งคำสั่งเขียน ROM เข้า ECU โดยตรง การสั่ง READ/WRITE ECU ทำจากหน้า 5 บน ESP32

## ESP32-CYD firmware
1. เปิด `Nattawut_SmartGauge_V3_9.ino` ด้วย Arduino IDE หรือ ArduinoDroid
2. เลือกบอร์ด ESP32-CYD/ESP32 ที่ตรงกับบอร์ดจริง และตั้ง Flash Size / Partition Scheme ให้ตรงกับ `partitions.csv`
3. Compile ก่อนทุกครั้ง หากมี error ให้หยุดและตรวจไลบรารี/รุ่น ESP32 core ก่อนอัปโหลด
4. อัปโหลด firmware และทดสอบการทำงานพื้นฐานก่อนเชื่อม ECU

## คำเตือน
- ห้ามเลือก ROM size, write mode หรือ offset โดยเดา
- ตรวจว่า BIN เป็นไฟล์ของ ECU เป้าหมายและ checksum ผ่านก่อน WRITE
- ระหว่างเขียนห้ามปิดกุญแจหรือถอดสายสื่อสาร/ไฟเลี้ยง
- แพ็กเกจนี้ยังไม่ได้ compile ในสภาพแวดล้อมที่สร้างไฟล์ และยังไม่มีผลทดสอบ READ/WRITE กับ ECU จริง
