# วิธีสร้าง APK ด้วยโทรศัพท์ Android อย่างเดียว

ไม่ต้องติดตั้ง Android Studio ในโทรศัพท์ ใช้ GitHub Actions สร้าง APK บนคลาวด์

## A. อัปโหลดโปรเจกต์
1. ดาวน์โหลด `Nattawut_SmartGauge_GPS_Source_v3_1.zip` แล้วเก็บไว้ใน Download ของมือถือ
2. เปิด GitHub repository ที่คุณสร้างไว้
3. กด **Add file > Upload files** แล้วเลือก ZIP นี้
4. กด **Commit changes**

## B. เพิ่ม workflow ให้ GitHub สร้าง APK
1. ที่หน้า repository กด **Add file > Create new file**
2. ตั้งชื่อไฟล์เป็น `.github/workflows/android-build.yml` (พิมพ์ทั้ง path)
3. วางเนื้อหาจากไฟล์ `.github/workflows/android-build.yml` ที่อยู่ในโปรเจกต์ ZIP หรือใช้เนื้อหาด้านล่าง
4. กด **Commit changes**

```yaml
name: Build Nattawut SmartGauge APK
on:
  workflow_dispatch:
  push:
    branches: ["**"]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'
      - uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: '8.7'
      - name: Build APK
        shell: bash
        run: |
          set -euo pipefail
          mkdir -p source
          unzip -q Nattawut_SmartGauge_GPS_Source_v3_1.zip -d source
          cd source
          gradle --no-daemon assembleDebug
          mkdir -p "$GITHUB_WORKSPACE/out"
          cp app/build/outputs/apk/debug/app-debug.apk "$GITHUB_WORKSPACE/out/app-debug.apk"
      - uses: actions/upload-artifact@v4
        with:
          name: Nattawut-SmartGauge-debug-apk
          path: out/app-debug.apk
          if-no-files-found: error
```

## C. ดาวน์โหลด APK
1. เปิดแท็บ **Actions** ใน repository
2. เปิดงานชื่อ **Build Nattawut SmartGauge APK** ที่ทำงานล่าสุด
3. รอจนสถานะเป็นสีเขียว **Success**
4. เลื่อนลงไปที่ **Artifacts** แล้วดาวน์โหลด `Nattawut-SmartGauge-debug-apk`
5. แตกไฟล์ Artifact แล้วแตะ `app-debug.apk` เพื่อติดตั้ง

## D. ทดสอบ GPS สองแหล่ง
1. แฟลชไฟล์ `firmware/Nattawut_SmartGauge_V8_Base.ino` จาก ZIP ลง ESP32 ก่อนทดสอบการสลับแหล่ง GPS
2. จับคู่ Bluetooth กับ `Nattawut ECU` แล้วเชื่อมต่อจากแอป
3. เปิดหน้า GPS แล้วเลือก `GPS MODULE บนบอร์ด (UART)` หรือ `GPS จากโทรศัพท์ Android`
4. โหมดโทรศัพท์ต้องอนุญาต **Precise location / ตำแหน่งที่แม่นยำ** และเปิด Location ของ Android
5. ทดสอบขณะจอดรถก่อนเสมอ

## ข้อควรทราบ
- ต้องใช้ ESP32 รุ่นที่รองรับ Bluetooth Classic SPP
- Firmware ยังคงใช้การกำหนดขา GPS เดิมในไฟล์: RX=GPIO3, TX=GPIO1 โปรดตรวจสอบว่าตรงกับการต่อสายของบอร์ดคุณก่อนแฟลช
- การเพิ่ม GPS source ยังต้องทดสอบกับ GPS Module, สาย UART และโทรศัพท์จริงก่อนนำไปใช้งานบนรถ
- อย่าทดสอบขณะขับขี่
