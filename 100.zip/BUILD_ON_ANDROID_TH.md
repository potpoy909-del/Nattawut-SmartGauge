# สร้าง APK ด้วย Android + GitHub Actions

โปรเจกต์ V3.6 ใช้ GitHub Actions สร้าง APK บนคลาวด์ ไม่ต้องติดตั้ง Android Studio ในโทรศัพท์

## วิธีที่ง่ายที่สุด

1. แตกไฟล์ `Nattawut_SmartGauge_V3_6_APP_DEVELOPMENT.zip`
2. เปิด GitHub repository แล้วอัปโหลดไฟล์และโฟลเดอร์ทั้งหมดภายใน ZIP ไปที่ root ของ repository จากนั้น Commit
3. เปิดแท็บ **Actions**
4. เลือก **Build Nattawut SmartGauge APK** แล้วกด **Run workflow** หากยังไม่เริ่มเอง
5. รอให้ workflow เป็นสีเขียว **Success**
6. เปิดงานล่าสุด เลื่อนลงไปที่ **Artifacts** แล้วดาวน์โหลด `Nattawut-SmartGauge-V3.6-APK`
7. แตกไฟล์ Artifact แล้วติดตั้ง `Nattawut-SmartGauge-V3.6-debug.apk`

## หากต้องการอัปโหลด ZIP โดยไม่แตกไฟล์

อัปโหลด `Nattawut_SmartGauge_V3_6_APP_DEVELOPMENT.zip` ไว้ที่ root ของ repository ได้เช่นกัน Workflow จะค้นหา ZIP และหา `app/build.gradle` ภายในให้อัตโนมัติ

## สภาพแวดล้อมที่ใช้สร้าง

- JDK 17
- Gradle 8.7
- Android Gradle Plugin 8.6.1
- compileSdk 35 / targetSdk 34 / minSdk 23

## หาก Build ไม่ผ่าน

เปิดงาน Build ล่าสุดในแท็บ Actions แล้วดูขั้นตอน **Build debug APK** จากนั้นคัดลอกข้อความ error สีแดงทั้งหมดมาให้ตรวจแก้ อย่าดาวน์โหลด APK จากงานที่ขึ้น Failed
