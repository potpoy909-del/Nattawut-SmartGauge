# วิธีสร้างแอป Nattawut SmartGauge V3.3 (แก้โครงสร้าง ZIP)

## สำคัญ
ไฟล์ ZIP นี้จัดโครงสร้างใหม่ให้ `settings.gradle`, `build.gradle`, `app/` และ `.github/` อยู่ที่ระดับรากของโปรเจกต์แล้ว ไม่ต้องเข้าโฟลเดอร์ซ้อนก่อนสั่ง Build

## สร้าง APK ผ่าน GitHub Actions (แนะนำ)
1. แตก ZIP นี้ในเครื่อง
2. สร้างหรือเปิด GitHub repository ของโปรเจกต์
3. อัปโหลดไฟล์และโฟลเดอร์ทั้งหมดภายใน ZIP ไปไว้ที่ระดับรากของ repository (อย่าอัปโหลดให้มีโฟลเดอร์ Nattawut_SmartGauge_V3_3 ครอบอีกชั้น)
4. ตรวจว่าเห็น `app/`, `build.gradle`, `settings.gradle` และ `.github/workflows/android-build.yml` ที่หน้าแรกของ repository
5. เปิดแท็บ Actions
6. เลือก workflow `Build Nattawut SmartGauge APK`
7. กด Run workflow หรือ push commit ใหม่เพื่อเริ่ม build
8. เมื่อสำเร็จ เปิดรายการ workflow run แล้วดาวน์โหลด Artifact ชื่อ `Nattawut-SmartGauge-debug-apk`
9. แตก Artifact จะได้ `app-debug.apk` สำหรับติดตั้งทดสอบ

## สร้างด้วย Android Studio
1. แตก ZIP
2. เลือก Open แล้วเลือกโฟลเดอร์โปรเจกต์ที่มี `settings.gradle` อยู่โดยตรง
3. ใช้ JDK 17 และ Gradle 8.7 / Android Gradle Plugin 8.6.1
4. รอ Gradle Sync แล้วเลือก Build > Build Bundle(s) / APK(s) > Build APK(s)

## หาก Build ไม่ผ่าน
ส่งภาพหน้าจอหรือคัดลอกข้อความจากส่วน `What went wrong` และ error แรกที่ขึ้นต้นด้วย `e:` หรือ `FAILURE:` มาให้ตรวจ อย่าส่งเฉพาะภาพหน้าจอหน้าแอป

หมายเหตุ: การจัด ZIP และ workflow ให้ถูกโครงสร้างไม่ได้ยืนยันว่าซอร์สคอมไพล์ผ่านแล้ว ต้องรอผล Build จริงจาก GitHub Actions หรือ Android Studio


## ESP32 firmware build (GitHub Actions)
1. Open **Actions** in the repository.
2. Select **Build Nattawut SmartGauge ESP32 Firmware**.
3. Press **Run workflow** and wait for the compile/partition-size check.
4. Use the custom 4MB `partitions.csv` included in this project when flashing the board.

The workflow compiles the firmware only; it does not flash the board or verify electrical wiring/ECU communication.
