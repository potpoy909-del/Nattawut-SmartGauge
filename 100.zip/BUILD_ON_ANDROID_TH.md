# Nattawut SmartGauge V3.1 — ESP32-CYD 4MB + Android

## Included features
- Existing Android SmartGauge app, Bluetooth Classic SPP telemetry and ECU/GPS pages retained.
- GPS module TX -> ESP32-CYD GPIO27; GPS UART 9600 baud; GPS_TX_PIN = -1 (GPS RX is not connected).
- Android gallery multi-select, 320x240 RGB565 preview/conversion, Bluetooth SPP upload with per-chunk ACK, CRC32, progress and error reporting.
- ESP32 LittleFS image list/select/delete and persistent boot-logo selection. No microSD is used for image storage.

## Explicit 4MB partition design
Use the supplied `partitions.csv` only with the user's stated 4MB (32Mbit) ESP32-CYD Flash:

| Partition | Offset | Size |
|---|---:|---:|
| NVS | 0x9000 | 0x5000 (20 KiB) |
| OTA metadata | 0xE000 | 0x2000 (8 KiB) |
| Factory application | 0x10000 | 0x1F0000 (1.9375 MiB) |
| LittleFS (`spiffs` label) | 0x200000 | 0x1D0000 (1.8125 MiB) |
| Unallocated reserve | 0x3D0000 | 0x30000 (192 KiB) |

The LittleFS partition is deliberately labelled `spiffs`, because Arduino-ESP32 `LittleFS.begin(false)` looks for that data partition label by default. Do not change the label unless the firmware is changed to mount a different partition.

Each image is 320x240 RGB565 = 153,600 bytes (150 KiB). Eight stored image files use 1,228,800 bytes (1.171875 MiB). A new image is first received as a temporary file, requiring another 153,600 bytes during upload. Eight stored images plus one in-progress image therefore use 1,382,400 bytes, below the 1,900,544-byte raw LittleFS partition size. This leaves 518,144 raw bytes for filesystem metadata/overhead and other files. The actual usable capacity is reported by the board; LittleFS overhead means the raw arithmetic is not a promise of exact usable bytes. The firmware refuses an upload when actual free space is insufficient.

The factory app partition is 1.9375 MiB. The compiled firmware must fit within it; the build must be checked before flashing. This custom layout has no second OTA application slot.

## Arduino IDE build/flash
1. Open `Nattawut_SmartGauge_V3_1_MultiImage/Nattawut_SmartGauge_V3_1_MultiImage.ino`. Keep `partitions.csv` beside the sketch.
2. Select an ESP32-CYD-compatible ESP32 board definition (commonly ESP32 Dev Module), Flash Size **4MB**, and Partition Scheme **Custom**. If the IDE/core version does not offer Custom, configure the same CSV as the selected custom partition table using that core's documented method; do not select an unrelated default scheme.
3. Compile first and confirm the app binary fits the 1.9375 MiB factory partition. If it does not, stop and revise the partition map before flashing.
4. Flash the firmware and its partition table. Changing partition layout may make existing flash files inaccessible. Do not erase all flash unless intentionally wiping all saved settings/data.
5. Pair the ESP32 Bluetooth device named `Nattawut ECU`, open the app's IMAGES page, and refresh the image list.
6. If the board reports `FS_NOT_READY`, use **INITIALIZE EMPTY FLASH STORAGE** only after confirming there is no LittleFS data to preserve. This formats only the LittleFS partition.
7. Select multiple photos, send them, then press **USE AT BOOT** on the desired image. Power-cycle the board to verify persistence.

## Notes / limitations
- Images are fitted to 320x240 by center-crop to fill the display; preview shows the converted frame.
- Eight slots are a software maximum. The board's reported free bytes are authoritative.
- A selected image is shown on the startup splash. The compiled-in boot logo remains the fallback if LittleFS is unavailable or the saved image is invalid.
- Bluetooth Classic SPP requires a Bluetooth Classic-capable ESP32 variant; do not substitute an ESP32-C3/S3 board without verifying radio support and adapting the design.
- This 4MB partition layout is for the user's stated 4MB CYD only. Verify the exact module/board and Flash Size setting before flashing.

## Validation status
- Source inspection and static consistency checks: performed for Android/firmware command names, image dimensions, CRC32 scheme, GPS pins/baud, and partition arithmetic.
- Android APK build: not run (Gradle/Android SDK unavailable in this environment).
- ESP32 firmware compile/size check: not run (Arduino-ESP32 toolchain unavailable).
- Hardware tests (SPP transfer, LittleFS, logo persistence, GPS, ECU): not run. Do not treat this package as hardware-validated until those tests pass.
