# Nattawut SmartGauge V3.9.0

## การออกแบบหน้าจอใหม่
- Dashboard: Race Deck แบบหน้าปัดรถแข่ง
- Graph: Oscilloscope สำหรับดูสัญญาณแต่ละช่อง
- DTC: Diagnostic Bay แยกสถานะและทะเบียนรหัสเสีย
- ECU: BIN File Vault สำหรับเลือก ส่ง แสดงรายการ และดาวน์โหลด BIN ผ่าน API เดิม
- MAP: Calibration Workbench สำหรับเลือกไฟล์ในเครื่อง (ยังไม่เขียน ECU)
- Control: Tool Matrix รวมทางลัดเครื่องมือ
- GPS: Track Mode เลือก GPS จากบอร์ดหรือโทรศัพท์
- Bluetooth: Link Station สำหรับเชื่อมต่อ SPP และตรวจสถานะ
- Images: Flash Gallery คงคำสั่งอัปโหลด/เลือก/ลบภาพเดิม
- Logger: Black Box บันทึกสตรีมและส่งออก CSV
- Settings: Control Room สำหรับตั้งค่าสีและดูข้อมูลระบบ

## ข้อกำหนด
- Android Gradle Plugin 8.6.1 / Kotlin 2.0.20 / JDK 17 / compileSdk 35
- เปิดโปรเจกต์จากโฟลเดอร์นี้โดยตรงใน Android Studio หรืออัปโหลดเนื้อหาทั้งหมดไปที่ root ของ GitHub repository เพื่อใช้ GitHub Actions
- ไม่ได้รวม gradlew/gradle-wrapper.jar; GitHub Actions ใช้ Gradle 8.7 ที่ติดตั้งใน workflow

## การรักษาฮาร์ดแวร์เดิม
เฟิร์มแวร์ที่แนบมาคือไฟล์ล่าสุดที่ผู้ใช้ให้ไว้ ไม่ได้แก้ pin mapping: K-Line RX GPIO35, K-Line TX GPIO22, GPS RX GPIO27.

## ข้อจำกัดการตรวจสอบ
ZIP ผ่านการตรวจสอบโครงสร้างและแตกไฟล์ได้ และตรวจ source Kotlin ด้วย parser check เบื้องต้นแล้ว แต่ยังไม่ได้ Build APK จริงในสภาพแวดล้อมนี้ เนื่องจากไม่มี Android SDK/Gradle.
