# Nattawut SmartGauge — V3.9 Android + latest user firmware

## Project base (do not replace with older versions)
- Android source: the `100.zip` project supplied in this conversation.
- Firmware source: the latest `ไฟล์ที่ใช้อยู่.ino` supplied in this conversation, copied to `Nattawut_SmartGauge_V3_9.ino` and updated only for the agreed BIN workflow.
- Older V3.1/V3.3 firmware folders and sketches are intentionally excluded.

## Agreed BIN workflow
- Android retains the V3.9 page layout and existing navigation.
- Choose a BIN file on the phone; the app displays its actual filename and actual byte/KB size.
- SEND BIN transfers the selected file to ESP32 LittleFS using the existing `NATTWUT_BIN` protocol and CRC32 acknowledgement.
- LIST FILES lists BIN files physically stored on ESP32; DOWNLOAD retrieves a selected file and verifies CRC32 before asking where to save it on the phone.
- ESP32 Page 5 retains its existing seven-page UI and button positions.
- The user explicitly selects the ROM size by tapping the `SIZE` field at the top-right of Page 5. No profile is preselected and no profile is inferred from BIN length.
- WRITE BIN compares the actual stored file size with the user-selected ROM profile and stops before issuing ECU write commands if they differ.
- 64 KB is marked Write Only; READ BIN is blocked for this profile. 48 KB and 56 KB remain marked read-capable according to the supplied profile definitions.
- READ BIN stores the resulting file in LittleFS. The user separately uses the Android DOWNLOAD action to transfer it to the phone.

## Build
- Open this folder as the Android Gradle project in Android Studio, or push the project root to GitHub and use the included Android build workflow.
- The archive does not include `gradlew` or `gradle-wrapper.jar`; the supplied GitHub Actions workflow installs Gradle 8.7.
- Android Gradle Plugin / Kotlin / JDK / SDK versions remain as defined by the supplied `100.zip` project.

## Validation limits
- Source edits and static consistency checks only.
- No APK was built in this environment because Android SDK/Gradle are unavailable.
- Firmware was not compiled with Arduino-ESP32 toolchain.
- ECU READ/WRITE was not tested on a physical ECU. Protocol success and flash safety must be confirmed on hardware before use.
