Nattawut ECU BIN READ / SEND integration
Base Android project: user-provided 100.zip
Firmware: Nattawut_SmartGauge_BIN_Bidirectional_V3.3.ino from Library

Added to Android app:
- BIN FILES page
- manually select BIN from phone and upload to ESP32 LittleFS
- list BIN files stored on ESP32
- choose a stored BIN and receive it to phone
- verify received size and CRC32 before Android save dialog
- progress and transfer status

Firmware behavior already present in supplied V3.3 firmware:
- READ BIN stores the ECU dump in LittleFS as ECU_DUMP_<size>KB_<sequence>.BIN
- if Bluetooth is connected during READ, firmware also attempts an automatic send
- app can separately request LIST and GET to transfer a saved BIN later

Important:
- Phone-to-board file transfer is not ECU flashing.
- Actual ECU ROM read protocol is present in the firmware source but has NOT been compiled or tested against a real ECU in this environment.
- The firmware chooses the 64 KB read profile by default; confirm the target ECU/profile and READ permission before attempting a real ECU read.
- This package does not establish that ECU read/flash works on hardware.
