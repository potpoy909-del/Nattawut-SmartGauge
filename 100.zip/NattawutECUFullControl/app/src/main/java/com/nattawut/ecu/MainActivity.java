package com.nattawut.ecu;

import android.Manifest;
import android.app.*;
import android.bluetooth.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.*;
import android.view.*;
import android.widget.*;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.app.ActivityCompat;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.UUID;

public class MainActivity extends Activity {
    private static final UUID SPP = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private BluetoothAdapter adapter; private BluetoothSocket socket; private InputStream in; private OutputStream out;
    private TextView connection, rpm, tps, ect, iat, batt, o2, afr, speed, inj, ecuStatus, log;
    private Button connectBtn; private volatile boolean reading=false; private final Handler ui=new Handler(Looper.getMainLooper());
    private final ActivityResultLauncher<String[]> permissions=registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), r->{});
    private final ActivityResultLauncher<String[]> imagePicker=registerForActivityResult(new ActivityResultContracts.OpenDocument(), uri->{ if(uri!=null) showImageTransferNotReady(uri); });

    @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(Color.rgb(7,24,39)); getWindow().setNavigationBarColor(Color.rgb(7,24,39));
        if(Build.VERSION.SDK_INT>=31) permissions.launch(new String[]{Manifest.permission.BLUETOOTH_CONNECT});
        BluetoothManager bm=(BluetoothManager)getSystemService(BLUETOOTH_SERVICE); adapter=bm.getAdapter(); buildUi(); }

    private void buildUi(){
        ScrollView scroll=new ScrollView(this); LinearLayout root=new LinearLayout(this); root.setOrientation(1); root.setPadding(18,18,18,28); root.setBackgroundColor(Color.rgb(7,20,34)); scroll.addView(root); setContentView(scroll);
        TextView title=text("NATTAWUT ECU",26,Color.WHITE); root.addView(title); root.addView(text("FULL CONTROL  •  ANDROID / BLUETOOTH CLASSIC",11,0xff35dfff));
        connection=text("DISCONNECTED",14,0xffffb74d); root.addView(connection);
        connectBtn=button("CONNECT TO NATTAWUT ECU"); root.addView(connectBtn); connectBtn.setOnClickListener(v->connectPaired());
        root.addView(section("LIVE ECU DATA  •  TELEMETRY v1"));
        LinearLayout grid=new LinearLayout(this); grid.setOrientation(1); root.addView(grid);
        rpm=valueRow(grid,"RPM"); tps=valueRow(grid,"TPS (%)"); ect=valueRow(grid,"ECT (°C)"); iat=valueRow(grid,"IAT (°C)"); batt=valueRow(grid,"BATTERY (V)"); o2=valueRow(grid,"O2 (V)"); afr=valueRow(grid,"AFR"); speed=valueRow(grid,"SPEED (km/h)"); inj=valueRow(grid,"INJECTOR (ms)");
        root.addView(section("DEVICE CONTROL"));
        addButton(root,"PING DEVICE",()->send("PING")); addButton(root,"READ ECU STATUS",()->send("STATUS"));
        addButton(root,"USE GPS SPEED",()->send("SPEED_SOURCE,GPS")); addButton(root,"USE PHONE SPEED",()->send("SPEED_SOURCE,PHONE"));
        root.addView(section("LOGO & BACKGROUND MANAGER"));
        addButton(root,"CHOOSE IMAGE FROM PHONE",()->imagePicker.launch(new String[]{"image/*"}));
        root.addView(text("Image selection UI is included. Image transfer is disabled until the matching ESP32 file-transfer receiver is installed.",12,0xffffcc80));
        root.addView(section("DEVICE MESSAGES")); ecuStatus=text("ECU status: waiting",13,0xffb7d7e8); root.addView(ecuStatus); log=text("",11,0xff8daabd); root.addView(log);
    }
    private TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setPadding(0,7,0,7);return t;}
    private TextView section(String s){TextView t=text(s,14,0xff35dfff);t.setPadding(0,20,0,8);return t;}
    private Button button(String s){Button b=new Button(this);b.setText(s);return b;}
    private void addButton(LinearLayout root,String s,Runnable r){Button b=button(s);root.addView(b);b.setOnClickListener(v->r.run());}
    private TextView valueRow(LinearLayout parent,String name){TextView t=text(name+"     --",18,Color.WHITE); parent.addView(t);return t;}
    private void connectPaired(){
        if(adapter==null){connection.setText("Bluetooth not supported");return;}
        if(Build.VERSION.SDK_INT>=31 && ActivityCompat.checkSelfPermission(this,Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED){permissions.launch(new String[]{Manifest.permission.BLUETOOTH_CONNECT});return;}
        try { BluetoothDevice target=null; for(BluetoothDevice d:adapter.getBondedDevices()) if("Nattawut ECU".equals(d.getName())){target=d;break;}
            if(target==null){connection.setText("Pair 'Nattawut ECU' in Android Bluetooth settings first");return;}
            connection.setText("CONNECTING..."); final BluetoothDevice dev=target;
            new Thread(()->{try{BluetoothSocket s=dev.createRfcommSocketToServiceRecord(SPP);s.connect();socket=s;in=s.getInputStream();out=s.getOutputStream();reading=true;ui.post(()->connection.setText("CONNECTED • Nattawut ECU"));send("PING");readLoop();}catch(Exception e){ui.post(()->connection.setText("CONNECTION FAILED: "+e.getMessage()));closeSocket();}}).start();
        }catch(SecurityException e){connection.setText("Bluetooth permission required");}
    }
    private synchronized void send(String cmd){try{if(out!=null){out.write((cmd+"\r\n").getBytes(StandardCharsets.US_ASCII));out.flush();}}catch(Exception e){append("TX error: "+e.getMessage());}}
    private void readLoop(){ByteArrayOutputStream line=new ByteArrayOutputStream();byte[] buf=new byte[256];while(reading){try{int n=in.read(buf);if(n<0)break;for(int i=0;i<n;i++){int c=buf[i]&255;if(c=='\n'){String s=line.toString("US-ASCII").trim();line.reset();parseLine(s);}else if(c!='\r'&&line.size()<512)line.write(c);}}catch(Exception e){break;}}closeSocket();ui.post(()->connection.setText("DISCONNECTED"));}
    private void parseLine(String s){if(s.startsWith("NATTWUT,1,")){String[] p=s.split(",");if(p.length>=11)ui.post(()->{set(rpm,"RPM",p[2]);set(tps,"TPS (%)",p[3]);set(ect,"ECT (°C)",p[4]);set(iat,"IAT (°C)",p[5]);set(batt,"BATTERY (V)",p[6]);set(o2,"O2 (V)",p[7]);set(afr,"AFR",p[8]);set(speed,"SPEED (km/h)",p[9]);set(inj,"INJECTOR (ms)",p[10]);});}
        else if(s.startsWith("NATTWUT_STATUS,"))ui.post(()->ecuStatus.setText("ECU: "+s));else if(s.startsWith("NATTWUT_ACK,"))append(s);else append(s);}
    private void set(TextView t,String name,String v){t.setText(name+"     "+v);}
    private void append(String s){ui.post(()->{if(log!=null)log.setText((log.getText()+"\n"+s).toString());});}
    private void showImageTransferNotReady(Uri uri){append("Selected image: "+uri.getLastPathSegment());new AlertDialog.Builder(this).setTitle("Image transfer not installed").setMessage("The current ESP32 firmware accepts SPEED and STATUS commands only. Add the matching SD-card image receiver firmware before sending image bytes, to avoid corrupting the existing Bluetooth command stream.").setPositiveButton("OK",null).show();}
    private void closeSocket(){reading=false;try{if(in!=null)in.close();}catch(Exception ignored){}try{if(out!=null)out.close();}catch(Exception ignored){}try{if(socket!=null)socket.close();}catch(Exception ignored){}in=null;out=null;socket=null;}
    @Override protected void onDestroy(){closeSocket();super.onDestroy();}
}
