# Nattawut ECU Full Control (Android source prototype)

## สถานะ
นี่คือโปรเจกต์ต้นแบบ Android Studio (Java) สำหรับเชื่อมต่อ ESP32 ด้วย Bluetooth Classic SPP โดยอิงโปรโตคอลที่ตรวจพบในไฟล์ `Nattawut_SmartGauge_V8_CLOCK_BOTTOM_RIGHT_ALIGNED.ino`:

- ชื่ออุปกรณ์: `Nattawut ECU`
- UUID SPP: `00001101-0000-1000-8000-00805F9B34FB`
- คำสั่ง: `PING`, `STATUS`, `SPEED_SOURCE,GPS`, `SPEED_SOURCE,PHONE`
- Telemetry CSV: `NATTWUT,1,RPM,TPS,ECT,IAT,BAT,O2,AFR,SPEED,INJ,IGN,MAP,STFT,LTFT`
- ส่งข้อมูลประมาณ 10 ครั้ง/วินาที

## วิธีเปิด
1. เปิดโฟลเดอร์นี้ด้วย Android Studio รุ่นที่รองรับ Android Gradle Plugin 8.7.3
2. ให้ Android Studio ติดตั้ง Android SDK Platform 35 และ Gradle dependencies
3. Build > Build APK(s)
4. ก่อนเชื่อมต่อ ให้จับคู่ `Nattawut ECU` ใน Bluetooth Settings ของ Android

## ข้อจำกัดที่ต้องทราบ
- ไฟล์นี้เป็นซอร์สโปรเจกต์ ยังไม่ได้ build หรือทดสอบบนโทรศัพท์จริง และไม่มี APK ที่ผ่านการ build
- Firmware ปัจจุบันยังไม่มี image-transfer receiver; แอปจึงแสดงตัวเลือกภาพ แต่จะไม่ส่ง bytes เพื่อป้องกันการรบกวนคำสั่ง SPP เดิม
- Firmware telemetry ปัจจุบันส่ง IGN/MAP/STFT/LTFT เป็น 0 พร้อมคอมเมนต์ระบุว่ายังไม่มี decoder ที่ยืนยันแล้ว แอปจะแสดง 0 ตามข้อมูลที่ได้รับ ไม่ใช่ค่าที่วัดได้จริง
- การควบคุม ECU แบบเขียนค่า/แฟลช/รีแมปไม่ได้เปิดใช้งานในต้นแบบนี้

## ขั้นตอนถัดไป
ต้องเพิ่มโปรโตคอลเฟรมภาพแบบมี header, ขนาด, checksum และ ACK/NAK ที่ firmware ESP32 รับผ่าน SPP แล้วเขียนลง SD Card ทีละ chunk; จากนั้นจึงเพิ่มการส่งภาพจริงในแอป และเพิ่มคำสั่งควบคุมที่ firmware รองรับอย่างปลอดภัยทีละรายการ
