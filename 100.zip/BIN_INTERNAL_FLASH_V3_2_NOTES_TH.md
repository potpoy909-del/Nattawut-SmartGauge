# Nattawut SmartGauge V3.2 – BIN Internal Flash (LittleFS)

## สิ่งที่เพิ่มจาก 100.zip
- เพิ่มรับไฟล์ `.BIN` จาก Android ผ่าน Bluetooth Classic SPP
- บันทึกลง LittleFS partition เดียวกับระบบภาพบูต โดยไม่ใช้ SD Card
- ใช้ Base64 chunks ขนาด 48 bytes พร้อม ACK ทุก chunk และ CRC32 ก่อน finalize
- เขียนลง `/BIN_UPLOAD.TMP` ก่อน แล้ว rename เป็นชื่อจริงเมื่อขนาดและ CRC32 ถูกต้อง
- ป้องกันชื่อไฟล์ซ้ำและตรวจพื้นที่ว่างก่อนเริ่มรับไฟล์
- Page 5 อ่านรายการ `.BIN` จาก LittleFS และแสดงขนาดเป็น KB ใต้ชื่อไฟล์
- Footer เปลี่ยนตัวบอกสถานะจาก SD เป็น FS (เขียวเมื่อ LittleFS พร้อม)
- แอปเพิ่มหน้า MAP FILE MANAGER สำหรับเลือก/ส่ง BIN และดูรายการไฟล์/พื้นที่ LittleFS

## ข้อจำกัดที่ยังคงล็อกไว้ตาม 100.zip ต้นฉบับ
- V3.1 ต้นฉบับไม่มี ROM dump/read-to-BIN routine สำหรับดูด ROM ECU ลงไฟล์ BIN
- V3.1 ต้นฉบับระบุ ECU WRITE/FLASH/REMAP disabled และไม่มีคำสั่งเขียน ROM
- ในรุ่นนี้ปุ่ม FLASH/REMAP จึงยังคงแสดงสถานะ LOCKED ไม่ได้ส่งข้อมูลไป ECU
- การเพิ่มครั้งนี้เป็นระบบจัดเก็บ/รับส่งไฟล์ BIN ระหว่างมือถือกับ Flash ภายในบอร์ดเท่านั้น ไม่ใช่การยืนยันว่าอ่านหรือเขียน ECU ได้

## การทดสอบระบบจัดเก็บ
1. เปิดโปรเจกต์ Android และอัปโหลด firmware `.ino` ลง ESP32-CYD
2. เชื่อมต่อ Bluetooth Classic กับ `Nattawut ECU`
3. เปิด MAP FILE MANAGER ในแอป แล้วเลือก `UPLOAD BIN TO ESP32 FLASH`
4. เลือกไฟล์ `.BIN` (รองรับ 1 byte ถึง 512 KiB ในโปรโตคอลนี้)
5. รอข้อความ `CRC32 OK` แล้วกลับไป Page 5 เพื่อดูชื่อไฟล์และขนาด KB
6. กด `REFRESH BIN FILE LIST` ในแอปเพื่อตรวจชื่อไฟล์และพื้นที่ว่าง

## ข้อควรระวัง
- LittleFS เป็น partition ร่วมกับภาพบูต ดังนั้นพื้นที่ BIN ที่ใช้ได้คือพื้นที่ว่างจริงหลังหักภาพและ metadata แล้ว
- ห้ามใช้คำสั่ง Initialize/Format LittleFS หากยังต้องการเก็บภาพหรือ BIN เดิม เพราะเป็นการลบไฟล์ทั้ง partition
- การรับส่งนี้ใช้ Bluetooth Classic SPP และตรวจ CRC32 แต่ยังไม่ได้ทดสอบกับฮาร์ดแวร์จริงในสภาพแวดล้อมนี้
