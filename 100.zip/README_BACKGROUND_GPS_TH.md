# NATTAWUT SMARTGAUGE 3.1 – Phone GPS Background Service

รุ่นนี้ต่อยอดจาก Phone GPS SPEED FIXED SOURCE เดิม โดยเพิ่ม Android Foreground Service สำหรับอ่าน Phone GPS และส่ง `SPEED,<km/h>` ผ่าน Bluetooth SPP ไปยัง ESP32 ต่อเนื่องเมื่อผู้ใช้ออกจากหน้าแอปหรือปัดแอปออกจาก Recent Apps

## สิ่งที่เปลี่ยน
- เพิ่ม `SmartGaugeService.kt` เพื่อทำงาน GPS เบื้องหลังและแสดง notification ถาวร `NATTAWUT SMARTGAUGE RUNNING`
- แชร์ Bluetooth SPP socket ที่แอปเชื่อมต่ออยู่ให้ service ใช้ส่งความเร็ว โดยไม่เปิด Bluetooth connection ซ้ำ
- ย้ายการเริ่ม/หยุด Phone GPS ออกจากวงจร `onPause()` / `onDestroy()` ของ Activity
- ปุ่ม DISCONNECT ในแอปยังหยุด service และปิดการเชื่อมต่อได้ตามปกติ
- คงคำสั่งเดิม `SPEED_SOURCE,PHONE`, `SPEED_SOURCE,GPS`, `SPEED,<value>` และ `SPEED,NA`
- เพิ่ม Foreground Service permissions สำหรับ Android รุ่นใหม่ และเพิ่ม versionCode เป็น 5

## วิธีใช้
1. แตก ZIP แล้วนำไฟล์/โฟลเดอร์ทั้งหมดไปแทน source ใน GitHub repository เดิม โดยเก็บสำเนา backup ก่อน
2. เปิด GitHub Actions แล้วรอ workflow `Build Nattawut SmartGauge APK` ทำงานจนสำเร็จ
3. ดาวน์โหลด artifact `Nattawut-SmartGauge-debug-apk` และติดตั้ง APK ทับรุ่นเดิม
4. อนุญาต Bluetooth, Precise Location และ Notifications เมื่อแอปถาม
5. เชื่อมต่อ ESP32 แล้วเลือก PHONE GPS จากหน้า GPS รอให้มีความเร็วขึ้นทั้งมือถือและบอร์ด
6. ออกจากหน้าแอปหรือปัดแอปออกจาก Recent Apps ได้ โดย notification `NATTAWUT SMARTGAUGE RUNNING` ควรยังแสดงอยู่
7. หากต้องการหยุด ให้กลับเข้าแอปแล้วกด DISCONNECT BLUETOOTH

## ข้อจำกัดที่ควรรู้
- การปัดแอปออกจาก Recent Apps ไม่ควรหยุด foreground service แต่ Force stop, กดหยุดแอปจาก Settings, ปิด Bluetooth/GPS หรือระบบปฏิบัติการจำกัดการทำงาน อาจหยุดการส่งได้
- ต้องเริ่ม service ขณะหน้าแอปอยู่ด้านหน้าและได้รับสิทธิ์ Location แล้ว
- ZIP นี้เป็น source สำหรับ Build; ยังไม่ได้ยืนยันผล Build หรือทดสอบบนโทรศัพท์/บอร์ดจริงในสภาพแวดล้อมนี้
