# Changelog V3.7.0

## UI redesign
- New dark motorsport / ECU workshop visual language.
- Page-specific hero header for Dashboard, Graph, Logger, DTC, ECU, MAP, Tools, GPS, Images, Bluetooth and Settings.
- Hero header displays a live Bluetooth connection state.
- Updated buttons, panels, card borders, spacing and bottom navigation selection.
- Preserved existing page handlers, Bluetooth command strings, and firmware files.

## Important
This is a UI foundation pass. It does not add unsupported ECU write/flash commands. A real Android Gradle build and device test are still required.
