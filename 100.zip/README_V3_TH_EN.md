# NATTAWUT SMARTGAUGE V3 — Racing ECU UI

This project updates the Android app UI to follow the agreed Racing ECU design reference: Dashboard, Live Graph, DTC Diagnostics, ECU Information, MAP Manager, Remote Control, Bluetooth Manager, Settings, and RAW ECU Logger.

## Build APK

The repository workflow `.github/workflows/android-build.yml` builds `app-debug.apk` from this project. The Android project files (`settings.gradle`, `app/build.gradle`, etc.) are at the ZIP root.

## Important hardware/API status

- Bluetooth Classic SPP connection and existing telemetry CSV parser are retained.
- GPS source selection is added: `GPS_SOURCE,BOARD` uses the existing ESP32 UART GPS parser; `GPS_SOURCE,PHONE` accepts Android GPS speed with `PHONE_SPEED,<kmh>`.
- Android phone-GPS mode requires precise Location permission and an enabled phone GPS provider. It sends speed updates while the app is active and Bluetooth SPP is connected.
- ESP32 defaults to the existing board GPS source after boot. Phone speed expires after 3 seconds without updates; board GPS data also expires after 3 seconds without a valid RMC fix.
- Missing ECU values (`NA`) are shown as `--`, not fabricated as zero.
- RAW Logger stores complete text lines received over Bluetooth during a capture session and exports CSV. It can preserve the ESP32 RAW frame messages if the installed firmware emits them.
- This is not a passive electrical K-Line sniffer. Frames not forwarded by the ESP32 firmware cannot be recovered by the app.
- DTC read/clear, MAP transfer, and remote hardware controls are shown as planned/locked where the current Bluetooth firmware API does not expose a verified command. The app does not send invented ECU commands.
- ECU identity/VIN are not fabricated. The ECU page distinguishes user-supplied vehicle/ECU context from data actually read in the current session.

## Firmware

`firmware/Nattawut_SmartGauge_V8_Base.ino` is the supplied V8 baseline. Preserve a backup before flashing. Firmware/app GPS source-selection integration has been added but still requires compilation and physical testing with the actual GPS module, board wiring, Android phone, and Bluetooth link. GPS UART pins remain the existing sketch mapping (RX=GPIO3, TX=GPIO1); verify these against the board wiring before flashing. RAW frame streaming and remote DTC operations still require protocol-level verification and physical testing with the Honda Wave 110i S4 ECU.

## Version

Android versionName: `3.0-racing-ui` (UI update / integration stage; not a claim that every hardware feature is complete).
