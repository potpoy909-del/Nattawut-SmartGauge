NATTAWUT SMARTGAUGE - SPEED DISPLAY FIX

ไฟล์ที่แก้ไข:
1) Nattawut_SmartGauge_V8_SPEED_DISPLAY_FIXED.ino
   - จัดตำแหน่งตัวเลข SPEED กับหน่วย km/h แยกคอลัมน์ ไม่ให้ทับกัน
   - ล้างเฉพาะพื้นหลังเดิมจากภาพ dashboard ก่อนวาดใหม่ ไม่วาดกรอบ/กล่องสีดำเพิ่ม
   - คงระบบเลือก Phone GPS / ESP32 GPS และ Bluetooth เดิม

2) MainActivity.kt
   - ค่า SPEED เริ่มต้นเป็น 0 km/h แทน --
   - เมื่อยังไม่มี GPS fix, เปลี่ยนแหล่งความเร็ว หรือ Bluetooth หลุด จะแสดง 0
   - สถานะ WAITING FOR FIX ยังแยกจาก DATA RECEIVED สำหรับ ESP32 GPS
   - ช่องเซ็นเซอร์ ECU อื่นที่ยังไม่มีข้อมูลยังคงแสดง -- ตามเดิม

วิธีใช้:
- ไฟล์ .ino: เปิดแทนไฟล์ firmware เดิมใน ArduinoDroid/Arduino IDE แล้วอัปโหลดลง ESP32 CYD
- MainActivity.kt: ใช้แทนไฟล์ app/src/main/java/com/nattawut/ecu/MainActivity.kt ใน source project ก่อนสั่ง GitHub Actions Build
- อย่าลบไฟล์เก่าใน GitHub ก่อนสำรองไว้ แนะนำให้อัปโหลดทับไฟล์เดิมหรือเก็บสำเนา backup ก่อน

หมายเหตุ: ชุดนี้เป็นไฟล์ source ที่แก้แล้ว ยังไม่ได้สร้าง/ทดสอบ APK หรืออัปโหลด firmware ลงบอร์ดจริงในรอบนี้
